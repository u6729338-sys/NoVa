import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';

void main() => runApp(const NovaApp());

const cyan = Color(0xFF58C7FF);
const bg = Color(0xFF090D16);

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NOVA', debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: cyan, brightness: Brightness.dark)),
    home: const NovaHome(),
  );
}

class ChatMessage {
  ChatMessage(this.text, this.fromNova, {this.time});
  final String text;
  final bool fromNova;
  final DateTime? time;
}

class NovaHome extends StatefulWidget {
  const NovaHome({super.key});
  @override
  State<NovaHome> createState() => _NovaHomeState();
}

class _NovaHomeState extends State<NovaHome> {
  final _input = TextEditingController();
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  final _scroll = ScrollController();
  final List<ChatMessage> _messages = [ChatMessage('Hello, I’m NOVA. I can help with basic offline commands, notes, and tasks. Say “help” to see what I can do.', true)];
  final List<String> _notes = [];
  final List<Map<String, dynamic>> _tasks = [];
  bool _listening = false, _voiceInputEnabled = true, _voiceReplies = true, _privateMode = false;
  int _tab = 0;
  String _status = 'READY';

  @override
  void initState() { super.initState(); _loadSaved(); }
  @override
  void dispose() { _input.dispose(); _scroll.dispose(); _tts.stop(); super.dispose(); }

  Future<void> _loadSaved() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _notes.addAll(p.getStringList('nova_notes_v1') ?? []);
      final raw = p.getString('nova_tasks_v1');
      if (raw != null) { try { _tasks.addAll((jsonDecode(raw) as List).map((e) => Map<String,dynamic>.from(e))); } catch (_) {} }
      _voiceReplies = p.getBool('nova_voice_replies') ?? true;
      _voiceInputEnabled = p.getBool('nova_voice_input_enabled') ?? true;
    });
  }
  Future<void> _saveNotes() async { final p = await SharedPreferences.getInstance(); await p.setStringList('nova_notes_v1', _notes); }
  Future<void> _saveTasks() async { final p = await SharedPreferences.getInstance(); await p.setString('nova_tasks_v1', jsonEncode(_tasks)); }
  Future<void> _saveSettings() async { final p = await SharedPreferences.getInstance(); await p.setBool('nova_voice_replies', _voiceReplies); await p.setBool('nova_voice_input_enabled', _voiceInputEnabled); }

  Future<void> _speak(String text) async {
    if (!_voiceReplies || _privateMode) return;
    try { await _tts.setLanguage('en-IN'); await _tts.setSpeechRate(0.47); await _tts.speak(text); } catch (_) {}
  }
  Future<void> _listen() async {
    if (!_voiceInputEnabled) { _reply('Voice input is disabled. Turn it on in Settings to use the microphone.'); return; }
    if (_listening) { await _speech.stop(); if (mounted) setState(() { _listening = false; _status = 'READY'; }); return; }
    final available = await _speech.initialize(
      onStatus: (s) { if (s == 'done' || s == 'notListening') { if (mounted) setState(() { _listening = false; _status = 'READY'; }); } },
      onError: (_) { if (mounted) setState(() { _listening = false; _status = 'VOICE ERROR'; }); },
    );
    if (!available) { _reply('Speech recognition is unavailable. Check microphone permission and your phone’s speech recognition service.'); return; }
    setState(() { _listening = true; _status = 'LISTENING'; });
    await _speech.listen(localeId: 'en_IN', listenFor: const Duration(seconds: 30), pauseFor: const Duration(seconds: 3), onResult: (r) {
      _input.text = r.recognizedWords;
      if (r.finalResult) { final text = r.recognizedWords.trim(); if (mounted) setState(() { _listening = false; _status = 'READY'; }); if (text.isNotEmpty) _send(text); }
    });
  }
  void _reply(String text) { setState(() => _messages.add(ChatMessage(text, true, time: DateTime.now()))); _speak(text); _jumpToBottom(); }
  void _jumpToBottom() { WidgetsBinding.instance.addPostFrameCallback((_) { if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut); }); }

  Future<void> _handle(String input) async {
    final q = input.trim().toLowerCase();
    if (q.isEmpty) return;
    if (q == 'help' || q == 'commands' || q.contains('what can you do')) {
      _reply('Try: time, date, battery (not available yet), add note buy groceries, show notes, add task finish assignment, show tasks, clear chat, open Google, open YouTube, or privacy mode. Web links open only after confirmation.'); return;
    }
    if (q.contains('time')) { final n = DateTime.now(); final h = n.hour % 12 == 0 ? 12 : n.hour % 12; _reply('It is $h:${n.minute.toString().padLeft(2,'0')} ${n.hour >= 12 ? 'PM' : 'AM'}.'); return; }
    if (q.contains('date') || q == 'today' || q.contains('what day')) { final n = DateTime.now(); const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']; _reply('Today is ${days[n.weekday-1]}, ${n.day}/${n.month}/${n.year}.'); return; }
    if (q == 'show notes' || q == 'list notes' || q.contains('read my notes')) { _reply(_notes.isEmpty ? 'You have no saved notes yet. Say “add note” followed by your note.' : 'Your saved notes: ' + _notes.asMap().entries.map((e) => '${e.key+1}. ${e.value}').join('. ')); return; }
    if (q.startsWith('add note ') || q.startsWith('note ')) { final note = input.substring(input.toLowerCase().indexOf(q.startsWith('add note ') ? 'add note ' : 'note ') + (q.startsWith('add note ') ? 9 : 5)).trim(); if (note.isEmpty) { _reply('Tell me what note to save.'); return; } setState(() => _notes.add(note)); await _saveNotes(); _reply('Saved your note on this device.'); return; }
    if (q == 'show tasks' || q == 'list tasks' || q.contains('my tasks')) { final pending = _tasks.where((t) => t['done'] != true).toList(); _reply(pending.isEmpty ? 'No pending tasks. Say “add task” followed by a task.' : 'Pending tasks: ' + pending.asMap().entries.map((e) => '${e.key+1}. ${e.value['text']}').join('. ')); return; }
    if (q.startsWith('add task ')) { final task = input.substring(9).trim(); if (task.isEmpty) { _reply('Tell me what task to add.'); return; } setState(() => _tasks.add({'text': task, 'done': false})); await _saveTasks(); _reply('Task added. You can manage it in the Tasks tab.'); return; }
    if (q == 'privacy mode' || q == 'enable privacy' || q == 'private mode') { setState(() { _privateMode = !_privateMode; }); _reply(_privateMode ? 'Privacy mode is on. I will not speak replies aloud until you turn it off.' : 'Privacy mode is off.'); return; }
    if (q == 'clear chat') { setState(() { _messages.clear(); }); _reply('Chat cleared. Saved notes and tasks were kept.'); return; }
    if (q == 'who are you') { _reply('I’m NOVA, your personal assistant. This version has local notes and tasks, voice input, spoken responses, and basic commands. I do not yet have a connected online AI brain.'); return; }
    String? url;
    if (q == 'open google' || q == 'google') url = 'https://www.google.com';
    if (q == 'open youtube' || q == 'youtube') url = 'https://www.youtube.com';
    if (q == 'open maps' || q == 'open google maps') url = 'https://maps.google.com';
    if (url != null) { final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Open website?'), content: Text('NOVA wants to open $url in your browser.'), actions: [TextButton(onPressed: () => Navigator.pop(c,false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c,true), child: const Text('Open'))])); if (yes == true) { final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication); _reply(ok ? 'Opening it now.' : 'I could not open that website.'); } else { _reply('Cancelled.'); } return; }
    if (q.contains('hello') || q == 'hi' || q.startsWith('hi nova')) { _reply('Hello! What would you like to do?'); return; }
    _reply('I heard: “$input”. This version works mainly with local commands; a real online AI brain is the next major upgrade. Say “help” for supported commands.');
  }
  void _send([String? spoken]) { final text = (spoken ?? _input.text).trim(); if (text.isEmpty) return; setState(() { _messages.add(ChatMessage(text, false, time: DateTime.now())); _input.clear(); }); _jumpToBottom(); _handle(text); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: const Color(0xFF0D1422), title: const Row(children: [Icon(Icons.auto_awesome, color: cyan), SizedBox(width: 10), Text('NOVA', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2))]), actions: [Padding(padding: const EdgeInsets.only(right: 14), child: Center(child: Text(_privateMode ? 'PRIVATE' : _status, style: const TextStyle(fontSize: 10, color: cyan))))]),
    body: IndexedStack(index: _tab, children: [_chatPage(), _notesPage(), _tasksPage(), _settingsPage()]),
    bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (i) => setState(() => _tab = i), destinations: const [NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat), label: 'Chat'), NavigationDestination(icon: Icon(Icons.note_alt_outlined), selectedIcon: Icon(Icons.note_alt), label: 'Notes'), NavigationDestination(icon: Icon(Icons.check_circle_outline), selectedIcon: Icon(Icons.check_circle), label: 'Tasks'), NavigationDestination(icon: Icon(Icons.tune), label: 'Settings')]),
  );

  Widget _chatPage() => SafeArea(child: Column(children: [
    Container(margin: const EdgeInsets.fromLTRB(14, 12, 14, 8), padding: const EdgeInsets.all(14), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF142D47), Color(0xFF101827)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF2C6384))), child: Row(children: [const CircleAvatar(backgroundColor: Color(0xFF153A54), child: Icon(Icons.graphic_eq, color: cyan)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Personal assistant', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), SizedBox(height: 3), Text('Offline commands • Local notes • Tasks', style: TextStyle(fontSize: 11, color: Colors.white70))])), IconButton(onPressed: () => _reply('Try “help” to see supported commands.'), icon: const Icon(Icons.help_outline))])),
    Expanded(child: ListView.builder(controller: _scroll, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), itemCount: _messages.length, itemBuilder: (context, i) { final m = _messages[i]; return Align(alignment: m.fromNova ? Alignment.centerLeft : Alignment.centerRight, child: Container(constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .84), margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11), decoration: BoxDecoration(color: m.fromNova ? const Color(0xFF172538) : const Color(0xFF164B67), borderRadius: BorderRadius.circular(17), border: Border.all(color: m.fromNova ? const Color(0xFF263D55) : const Color(0xFF23789D))), child: Text(m.text, style: const TextStyle(fontSize: 14, height: 1.35)))); })),
    Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 10), child: Row(children: [IconButton.filled(onPressed: _listen, style: IconButton.styleFrom(backgroundColor: _listening ? Colors.redAccent : const Color(0xFF164B67)), icon: Icon(_listening ? Icons.stop : (_voiceInputEnabled ? Icons.mic : Icons.mic_off)), tooltip: _voiceInputEnabled ? 'Voice input' : 'Voice input disabled'), const SizedBox(width: 6), Expanded(child: TextField(controller: _input, onSubmitted: (_) => _send(), textInputAction: TextInputAction.send, decoration: InputDecoration(hintText: 'Message NOVA…', filled: true, fillColor: const Color(0xFF111A29), contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))), const SizedBox(width: 6), IconButton.filled(onPressed: _send, icon: const Icon(Icons.arrow_upward), tooltip: 'Send')]))
  ]));

  Widget _notesPage() => SafeArea(child: Column(children: [const ListTile(title: Text('Your notes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), subtitle: Text('Saved locally on this device')), Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [Expanded(child: TextField(controller: _noteInput, decoration: const InputDecoration(hintText: 'Write a note…', border: OutlineInputBorder()), onSubmitted: (_) => _addNote())), IconButton.filled(onPressed: _addNote, icon: const Icon(Icons.add))])), Expanded(child: _notes.isEmpty ? const Center(child: Text('No notes yet')) : ListView.builder(itemCount: _notes.length, itemBuilder: (c,i) => ListTile(leading: const Icon(Icons.sticky_note_2_outlined, color: cyan), title: Text(_notes[i]), trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { setState(() => _notes.removeAt(i)); await _saveNotes(); }))))]));
  final _noteInput = TextEditingController();
  Future<void> _addNote() async { final v = _noteInput.text.trim(); if (v.isEmpty) return; setState(() { _notes.add(v); _noteInput.clear(); }); await _saveNotes(); }

  Widget _tasksPage() => SafeArea(child: Column(children: [const ListTile(title: Text('Tasks', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), subtitle: Text('Tick off completed tasks')), Expanded(child: _tasks.isEmpty ? const Center(child: Text('No tasks yet. Add one in chat: “add task …”')) : ListView.builder(itemCount: _tasks.length, itemBuilder: (c,i) { final t = _tasks[i]; return CheckboxListTile(value: t['done'] == true, title: Text('${t['text']}', style: TextStyle(decoration: t['done'] == true ? TextDecoration.lineThrough : null)), onChanged: (v) async { setState(() => t['done'] = v ?? false); await _saveTasks(); }, secondary: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { setState(() => _tasks.removeAt(i)); await _saveTasks(); })); }))]));

  Widget _settingsPage() => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [const Text('Settings & privacy', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 8), SwitchListTile(secondary: const Icon(Icons.mic, color: cyan), title: const Text('Voice input'), subtitle: const Text('Allow or disable microphone-based speech recognition'), value: _voiceInputEnabled, onChanged: (v) async { if (!v && _listening) { await _speech.stop(); } setState(() { _voiceInputEnabled = v; _listening = false; _status = 'READY'; }); await _saveSettings(); }), SwitchListTile(secondary: const Icon(Icons.volume_up, color: cyan), title: const Text('Spoken replies'), subtitle: const Text('Allow or disable NOVA speaking replies aloud'), value: _voiceReplies, onChanged: (v) async { setState(() => _voiceReplies = v); await _saveSettings(); if (!v) await _tts.stop(); }), SwitchListTile(title: const Text('Privacy mode'), subtitle: const Text('Temporarily disables spoken replies'), value: _privateMode, onChanged: (v) { setState(() => _privateMode = v); if (v) _tts.stop(); }), const Divider(), const ListTile(leading: Icon(Icons.lock_outline, color: cyan), title: Text('Local storage'), subtitle: Text('Notes and tasks are stored on this device using app preferences. They are not encrypted by this app. Avoid saving passwords or highly sensitive information.')), const ListTile(leading: Icon(Icons.cloud_outlined, color: cyan), title: Text('Online AI'), subtitle: Text('Not connected yet. Next stage: a secure backend/API connection. Never put a secret API key directly inside a public app or GitHub repository.')), const SizedBox(height: 12), OutlinedButton.icon(onPressed: () async { final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Delete all local data?'), content: const Text('This permanently deletes NOVA notes and tasks stored by this app. Chat messages will also be cleared.'), actions: [TextButton(onPressed: () => Navigator.pop(c,false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c,true), child: const Text('Delete all'))])); if (ok == true) { setState(() { _notes.clear(); _tasks.clear(); _messages.clear(); }); final p = await SharedPreferences.getInstance(); await p.remove('nova_notes_v1'); await p.remove('nova_tasks_v1'); _reply('Local notes and tasks have been deleted.'); } }, icon: const Icon(Icons.delete_forever), label: const Text('Delete all local notes and tasks'))]));
}
