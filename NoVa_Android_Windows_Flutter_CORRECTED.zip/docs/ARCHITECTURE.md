# NOVA architecture

```text
Flutter UI
   │
   ├── NovaController
   │      ├── AiService ── OpenAI-compatible server / Ollama
   │      ├── VoiceService ── speech-to-text + TTS
   │      └── StorageService ── local preferences
   │
   └── Screens / widgets
```

## Why Flutter

One UI and one Dart codebase can target Android and Windows while still allowing native platform integrations later.

## Safety model

NOVA should separate:
1. conversation,
2. memory,
3. tool execution,
4. permissions.

Actions such as calling, messaging, deleting files, or controlling devices should require explicit user confirmation before execution.

## Next engineering layer

A future `ToolRegistry` should expose controlled actions:

- open app
- notes
- files
- calendar
- maps
- device status
- phone calls/messages

Each tool should declare its permission and whether confirmation is required.
