# NOVA roadmap

## V0.1 — included
- Android/Windows Flutter foundation
- Chat
- persistent history
- configurable AI backend
- voice input/output
- memory
- privacy setting

## V0.2
- Tool registry
- app launcher
- notes
- file search
- web search adapter
- better local model support

## V0.3
- secure phone ↔ PC pairing
- Windows companion service
- notifications
- device status

## V0.4
- wake word
- accounts/profiles
- encrypted secrets
- confirmation system for sensitive actions

## V1
- polished release builds
- automated Android APK/AAB and Windows installer pipelines
- diagnostics and crash reporting with privacy controls
