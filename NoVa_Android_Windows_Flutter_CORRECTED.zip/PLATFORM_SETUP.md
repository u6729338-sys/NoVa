# NoVa Android + Windows Platform Setup

This project contains the NoVa Dart/Flutter source plus starter `android/` and
`windows/` platform directories.

For the installed Flutter SDK, run from this project root:

```bash
flutter create --platforms=android,windows .
flutter pub get
flutter run -d windows
```

For Android:

```bash
flutter run -d android
```

Running `flutter create` with the installed SDK is preferred because it
generates platform files compatible with that exact Flutter version.
