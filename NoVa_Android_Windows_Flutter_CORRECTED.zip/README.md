# NOVA — Android + Windows

NOVA is a cross-platform personal AI assistant built with Flutter.

## Included in this ZIP

- Android + Windows Flutter application source
- NOVA chat UI
- Local conversation history
- Persistent memory using SharedPreferences
- Voice input with speech-to-text
- Text-to-speech
- Configurable OpenAI-compatible AI endpoint
- Offline fallback responses when no AI endpoint is configured
- Privacy mode
- Settings screen
- Clean architecture ready for future phone ↔ PC features

## Quick start

1. Install Flutter and enable Android/Windows desktop support.
2. Extract this project.
3. From the project folder run:

```bash
flutter create .
flutter pub get
flutter run -d windows
```

For Android:

```bash
flutter run
```

`flutter create .` is intentional: it generates the native Android/Windows runner files using the exact Flutter SDK installed on your machine, avoiding stale platform templates.

## AI setup

Open **Settings → AI connection** and enter an OpenAI-compatible endpoint.

Examples:
- Local Ollama: `http://127.0.0.1:11434/v1/chat/completions`
- Other OpenAI-compatible servers: use their chat-completions URL.

Set:
- API URL
- API key (optional for local servers)
- Model

NOVA sends only the current conversation and configured memory to the endpoint.

## Important

This project does not contain an API key. Do not put secrets into source control.

## Roadmap

- Wake word / always-listening mode with explicit permission
- Phone ↔ Windows pairing
- Calls and messages with confirmation
- App launching
- Files/notes/calendar tools
- Local LLM support
- User profiles and stronger encrypted storage
- GitHub Actions builds for APK and Windows installers
