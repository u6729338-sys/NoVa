import 'package:flutter/material.dart';
import '../core/nova_controller.dart';

class SettingsScreen extends StatefulWidget {
  final NovaController controller;
  const SettingsScreen({super.key, required this.controller});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController url;
  late final TextEditingController key;
  late final TextEditingController model;
  late final TextEditingController memory;

  NovaController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    url = TextEditingController(text: c.storage.apiUrl);
    key = TextEditingController(text: c.storage.apiKey);
    model = TextEditingController(text: c.storage.model);
    memory = TextEditingController(text: c.storage.memory);
  }

  @override
  void dispose() {
    url.dispose();
    key.dispose();
    model.dispose();
    memory.dispose();
    super.dispose();
  }

  Future<void> save() async {
    await c.saveConnection(
      url: url.text.trim(),
      key: key.text.trim(),
      model: model.text.trim(),
    );
    await c.saveMemory(memory.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('NOVA settings saved')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NOVA Settings')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const _SectionTitle('AI connection'),
          const SizedBox(height: 8),
          TextField(
            controller: url,
            decoration: const InputDecoration(
              labelText: 'API URL',
              hintText: 'http://127.0.0.1:11434/v1/chat/completions',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: model,
            decoration: const InputDecoration(
              labelText: 'Model',
              hintText: 'llama3.2',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: key,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'API key',
              hintText: 'Optional for local servers',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 26),
          const _SectionTitle('Memory'),
          const SizedBox(height: 8),
          TextField(
            controller: memory,
            minLines: 4,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: 'What NOVA should remember',
              hintText: 'Example: I prefer short, simple explanations.',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 26),
          const _SectionTitle('Privacy'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Privacy mode'),
            subtitle: const Text(
              'Keeps NOVA focused on local data and your configured server.',
            ),
            value: c.storage.privacyMode,
            onChanged: (v) => c.togglePrivacy(v),
          ),
          const SizedBox(height: 26),
          FilledButton.icon(
            onPressed: save,
            icon: const Icon(Icons.save_outlined),
            label: const Text('Save settings'),
          ),
          const SizedBox(height: 18),
          const Text(
            'NOVA never includes an API key in this project. Keep your credentials private.',
            style: TextStyle(color: Colors.white54),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Text(
        text,
        style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
      );
}
