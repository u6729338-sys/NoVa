import 'package:flutter/material.dart';
import '../core/nova_controller.dart';
import '../models/chat_message.dart';
import '../widgets/message_bubble.dart';

class HomeScreen extends StatefulWidget {
  final NovaController controller;
  const HomeScreen({super.key, required this.controller});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final input = TextEditingController();
  final scroll = ScrollController();

  NovaController get c => widget.controller;

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void send() {
    final text = input.text;
    input.clear();
    c.send(text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: const Row(
          children: [
            CircleAvatar(
              radius: 17,
              backgroundColor: Color(0xFF7C5CFF),
              child: Icon(Icons.auto_awesome, size: 19),
            ),
            SizedBox(width: 10),
            Text('NOVA', style: TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Clear chat',
            onPressed: c.busy ? null : c.clearChat,
            icon: const Icon(Icons.delete_outline),
          ),
          IconButton(
            tooltip: 'Settings',
            onPressed: () => Navigator.pushNamed(context, '/settings'),
            icon: const Icon(Icons.settings_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: !c.initialized
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: c.messages.isEmpty
                      ? _Welcome()
                      : ListView.builder(
                          controller: scroll,
                          padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
                          itemCount: c.messages.length,
                          itemBuilder: (_, i) =>
                              MessageBubble(message: c.messages[i]),
                        ),
                ),
                if (c.busy)
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Text('NOVA is thinking…',
                        style: TextStyle(color: Colors.white54)),
                  ),
                _Composer(
                  controller: input,
                  listening: c.listening,
                  busy: c.busy,
                  onSend: send,
                  onMic: () async {
                    if (c.listening) {
                      await c.stopListening();
                    } else {
                      await c.startListening((text) {
                        if (text.isNotEmpty) input.text = text;
                        if (mounted) setState(() {});
                      });
                    }
                  },
                ),
              ],
            ),
    );
  }
}

class _Welcome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.auto_awesome, size: 62, color: Color(0xFF8E73FF)),
              const SizedBox(height: 18),
              const Text(
                'Hey, I’m NOVA.',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              Text(
                'Your Android + Windows personal AI assistant.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 16),
              ),
              const SizedBox(height: 28),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: const [
                  _Tip('Ask a question'),
                  _Tip('Use the microphone'),
                  _Tip('Connect your AI server'),
                  _Tip('Save useful memory'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tip extends StatelessWidget {
  final String text;
  const _Tip(this.text);

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: const Icon(Icons.arrow_forward, size: 15),
      label: Text(text),
    );
  }
}

class _Composer extends StatelessWidget {
  final TextEditingController controller;
  final bool listening;
  final bool busy;
  final VoidCallback onSend;
  final VoidCallback onMic;

  const _Composer({
    required this.controller,
    required this.listening,
    required this.busy,
    required this.onSend,
    required this.onMic,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 14),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  minLines: 1,
                  maxLines: 5,
                  onSubmitted: (_) => onSend(),
                  decoration: InputDecoration(
                    hintText: listening ? 'Listening…' : 'Message NOVA…',
                    filled: true,
                    fillColor: const Color(0xFF12141D),
                    prefixIcon: IconButton(
                      onPressed: busy ? null : onMic,
                      icon: Icon(
                        listening ? Icons.mic : Icons.mic_none,
                        color: listening ? const Color(0xFF8E73FF) : null,
                      ),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: busy ? null : onSend,
                icon: const Icon(Icons.arrow_upward),
                style: IconButton.styleFrom(
                  minimumSize: const Size(52, 52),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
