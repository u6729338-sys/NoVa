import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final SpeechToText speech = SpeechToText();
  final FlutterTts tts = FlutterTts();

  Future<bool> initialize() => speech.initialize();

  Future<void> speak(String text) async {
    await tts.stop();
    await tts.setSpeechRate(0.48);
    await tts.speak(text);
  }

  Future<void> stopSpeaking() => tts.stop();

  Future<void> listen({
    required void Function(String text) onResult,
    required void Function(bool listening) onListening,
  }) async {
    final available = await initialize();
    if (!available) {
      onListening(false);
      return;
    }

    onListening(true);
    await speech.listen(
      onResult: (result) {
        onResult(result.recognizedWords);
        if (result.finalResult) onListening(false);
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> stopListening() async {
    await speech.stop();
  }

  void dispose() {
    speech.cancel();
    tts.stop();
  }
}
