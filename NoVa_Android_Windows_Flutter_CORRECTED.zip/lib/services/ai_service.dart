import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';
import 'storage_service.dart';

class AiService {
  final StorageService storage;
  AiService(this.storage);

  Future<String> reply(List<ChatMessage> history, String prompt) async {
    final url = storage.apiUrl.trim();
    if (url.isEmpty) return _offline(prompt);

    try {
      final messages = <Map<String, String>>[
        {
          'role': 'system',
          'content':
              'You are NOVA, a concise, helpful personal AI assistant. '
                  'Be practical and clear. Never claim to have performed an '
                  'action unless it actually happened.'
        },
        if (storage.memory.isNotEmpty)
          {'role': 'system', 'content': 'User memory:\\n${storage.memory}'},
        ...history.take(20).map(
              (m) => {
                'role': m.role == MessageRole.user ? 'user' : 'assistant',
                'content': m.text,
              },
            ),
        {'role': 'user', 'content': prompt},
      ];

      final headers = <String, String>{
        'Content-Type': 'application/json',
        if (storage.apiKey.isNotEmpty)
          'Authorization': 'Bearer ${storage.apiKey}',
      };

      final response = await http
          .post(
            Uri.parse(url),
            headers: headers,
            body: jsonEncode({
              'model': storage.model,
              'messages': messages,
              'temperature': 0.7,
            }),
          )
          .timeout(const Duration(seconds: 45));

      if (response.statusCode >= 200 && response.statusCode < 300) {
        final data = jsonDecode(response.body);
        final content =
            data['choices']?[0]?['message']?['content']?.toString();
        if (content != null && content.trim().isNotEmpty) return content.trim();
      }
      return 'I could not reach the AI server. Check the AI connection settings.';
    } catch (_) {
      return _offline(prompt);
    }
  }

  String _offline(String prompt) {
    final p = prompt.toLowerCase().trim();
    if (p == 'hi' || p == 'hello' || p.contains('hey nova')) {
      return 'Hey! I’m NOVA. I’m ready. Ask me something or configure an AI server in Settings.';
    }
    if (p.contains('who are you')) {
      return 'I’m NOVA, your cross-platform personal AI assistant.';
    }
    if (p.contains('help')) {
      return 'Try connecting an OpenAI-compatible AI endpoint in Settings. I can then handle normal chat and use your saved memory.';
    }
    return 'I’m in offline mode right now. Connect an AI endpoint in Settings to give me full AI capabilities.';
  }
}
