import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/chat_message.dart';

class StorageService {
  static const _messagesKey = 'nova.messages';
  static const _memoryKey = 'nova.memory';
  static const _apiUrlKey = 'nova.api_url';
  static const _apiKeyKey = 'nova.api_key';
  static const _modelKey = 'nova.model';
  static const _privacyKey = 'nova.privacy';

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  List<ChatMessage> loadMessages() {
    final raw = _prefs?.getString(_messagesKey);
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List;
      return list
          .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveMessages(List<ChatMessage> messages) async {
    await _prefs?.setString(
      _messagesKey,
      jsonEncode(messages.map((m) => m.toJson()).toList()),
    );
  }

  String get memory => _prefs?.getString(_memoryKey) ?? '';
  Future<void> setMemory(String value) async =>
      _prefs?.setString(_memoryKey, value);

  String get apiUrl =>
      _prefs?.getString(_apiUrlKey) ??
      'http://127.0.0.1:11434/v1/chat/completions';
  Future<void> setApiUrl(String value) async =>
      _prefs?.setString(_apiUrlKey, value);

  String get apiKey => _prefs?.getString(_apiKeyKey) ?? '';
  Future<void> setApiKey(String value) async =>
      _prefs?.setString(_apiKeyKey, value);

  String get model => _prefs?.getString(_modelKey) ?? 'llama3.2';
  Future<void> setModel(String value) async =>
      _prefs?.setString(_modelKey, value);

  bool get privacyMode => _prefs?.getBool(_privacyKey) ?? false;
  Future<void> setPrivacyMode(bool value) async =>
      _prefs?.setBool(_privacyKey, value);
}
