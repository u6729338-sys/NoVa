import 'package:flutter/foundation.dart';
import '../models/chat_message.dart';
import '../services/ai_service.dart';
import '../services/storage_service.dart';
import '../services/voice_service.dart';

class NovaController extends ChangeNotifier {
  final StorageService storage = StorageService();
  late final AiService ai;
  final VoiceService voice = VoiceService();

  List<ChatMessage> messages = [];
  bool initialized = false;
  bool busy = false;
  bool listening = false;

  Future<void> initialize() async {
    await storage.init();
    ai = AiService(storage);
    messages = storage.loadMessages();
    initialized = true;
    notifyListeners();
  }

  Future<void> send(String text) async {
    final prompt = text.trim();
    if (prompt.isEmpty || busy || !initialized) return;

    final user = ChatMessage(
      role: MessageRole.user,
      text: prompt,
      timestamp: DateTime.now(),
    );
    messages = [...messages, user];
    busy = true;
    notifyListeners();
    await storage.saveMessages(messages);

    final answer = await ai.reply(messages, prompt);
    messages = [
      ...messages,
      ChatMessage(
        role: MessageRole.assistant,
        text: answer,
        timestamp: DateTime.now(),
      ),
    ];
    busy = false;
    notifyListeners();
    await storage.saveMessages(messages);
  }

  Future<void> clearChat() async {
    messages = [];
    await storage.saveMessages(messages);
    notifyListeners();
  }

  Future<void> togglePrivacy(bool value) async {
    await storage.setPrivacyMode(value);
    notifyListeners();
  }

  Future<void> saveConnection({
    required String url,
    required String key,
    required String model,
  }) async {
    await storage.setApiUrl(url);
    await storage.setApiKey(key);
    await storage.setModel(model);
    notifyListeners();
  }

  Future<void> saveMemory(String memory) async {
    await storage.setMemory(memory);
    notifyListeners();
  }

  Future<void> startListening(void Function(String) onText) async {
    await voice.listen(
      onResult: onText,
      onListening: (value) {
        listening = value;
        notifyListeners();
      },
    );
  }

  Future<void> stopListening() => voice.stopListening();

  Future<void> speak(String text) => voice.speak(text);

  @override
  void dispose() {
    voice.dispose();
    super.dispose();
  }
}
