import 'package:flutter/material.dart';
import '../models/chat_message.dart';

class MessageBubble extends StatelessWidget {
  final ChatMessage message;
  const MessageBubble({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    final user = message.role == MessageRole.user;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 760),
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: user
              ? const Color(0xFF6E54E8)
              : const Color(0xFF171A25),
          borderRadius: BorderRadius.circular(18),
          border: user
              ? null
              : Border.all(color: Colors.white.withOpacity(.06)),
        ),
        child: Text(
          message.text,
          style: const TextStyle(fontSize: 15.5, height: 1.45),
        ),
      ),
    );
  }
}
