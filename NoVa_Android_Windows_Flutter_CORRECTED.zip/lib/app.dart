import 'package:flutter/material.dart';
import 'core/nova_controller.dart';
import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';

class NovaApp extends StatefulWidget {
  const NovaApp({super.key});

  @override
  State<NovaApp> createState() => _NovaAppState();
}

class _NovaAppState extends State<NovaApp> {
  final NovaController controller = NovaController();

  @override
  void initState() {
    super.initState();
    controller.initialize();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'NOVA',
          theme: ThemeData(
            brightness: Brightness.dark,
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF7C5CFF),
              brightness: Brightness.dark,
            ),
            scaffoldBackgroundColor: const Color(0xFF090A10),
            cardTheme: const CardThemeData(
              color: Color(0xFF12141D),
              elevation: 0,
              margin: EdgeInsets.zero,
            ),
          ),
          home: HomeScreen(controller: controller),
          routes: {
            '/settings': (_) => SettingsScreen(controller: controller),
          },
        );
      },
    );
  }
}
