#!/usr/bin/env bash
set -e

command -v flutter >/dev/null 2>&1 || {
  echo "Flutter was not found in PATH. Install Flutter first."
  exit 1
}

flutter create . --platforms=android,windows
flutter pub get

echo "NOVA is ready."
echo "Run Windows: flutter run -d windows"
echo "Run Android: flutter run"
