@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found in PATH. Install Flutter first.
  exit /b 1
)
flutter create . --platforms=android,windows
flutter pub get
echo.
echo NOVA is ready.
echo Run Windows: flutter run -d windows
echo Run Android: flutter run
