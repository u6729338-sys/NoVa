$ErrorActionPreference = "Stop"

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Host "Flutter was not found in PATH. Install Flutter first." -ForegroundColor Red
  exit 1
}

Write-Host "Generating native Android + Windows runner files..."
flutter create . --platforms=android,windows

$manifest = "android/app/src/main/AndroidManifest.xml"
if (Test-Path $manifest) {
  $text = Get-Content $manifest -Raw
  if ($text -notmatch "android.permission.RECORD_AUDIO") {
    $text = $text -replace '(<manifest[^>]*>)', '$1`r`n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>'
    Set-Content -Path $manifest -Value $text -NoNewline
  }
}

Write-Host "Installing Dart dependencies..."
flutter pub get

Write-Host ""
Write-Host "NOVA is ready."
Write-Host "Run Windows: flutter run -d windows"
Write-Host "Run Android: flutter run"
