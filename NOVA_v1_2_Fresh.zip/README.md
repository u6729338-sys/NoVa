# NOVA V2.1 Feature Pack

This is an expanded Flutter source starter with a working UI shell and a few device/local features. It is **not** the complete NOVA vision, and this ZIP has not been compiled or device-tested in this environment.

## Included in this source
- Animated orb home screen.
- Original selectable persona concepts.
- Local conversation UI and simple device text-to-speech.
- Speech recognition integration attempt using the device's available service.
- Multi-file picker that lists selected files.
- Paste-text study-note and presentation-outline generators.
- Saved preferences for persona, local-mode preference, voice toggle and privacy-mode toggle.
- Android and Windows intended Flutter target.

## Still requires real implementation/testing
- Online AI provider connection and secure backend.
- Offline LLM/model download, device capability detection and model management.
- Reading/extracting actual contents of PDFs, DOCX, PPTX and images/OCR.
- Exporting generated notes to PDF/DOCX and slides to PPTX.
- Real character art/animation, mouth sync and distinct character voice profiles.
- Wake word, alarms/reminders, app launching, maps, weather, calls/SMS/WhatsApp and permission flows.
- Encrypted persistent chat memory, separate accounts/profiles, data retention/summarization.
- Full native Android and Windows runner scaffolding.

## Build
Use a computer with Flutter installed. Generate platform folders if needed using `flutter create .`, then:
```bash
flutter pub get
flutter run
```
Android APK:
```bash
flutter build apk --release
```
Windows build must be run on Windows with the desktop toolchain enabled:
```bash
flutter config --enable-windows-desktop
flutter build windows --release
```

## Important security note
Never commit API keys or passwords into this repository. Use a backend secret store for online providers. The app must request explicit confirmation before any message, call, purchase, or other external action.
