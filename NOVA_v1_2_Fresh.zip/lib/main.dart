import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const NovaApp());

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NOVA', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF64D8FF), brightness: Brightness.dark), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFF080D18)),
    home: const NovaShell(),
  );
}

class NovaShell extends StatefulWidget {
  const NovaShell({super.key});
  @override
  State<NovaShell> createState() => _NovaShellState();
}

class _NovaShellState extends State<NovaShell> {
  int tab = 0;
  String persona = 'NOVA Orb';
  bool voiceEnabled = true, privacyMode = false, localMode = true;
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final prompt = TextEditingController();
  final sourceText = TextEditingController();
  final chat = <String>['NOVA: Welcome. I can help organize text into notes or a presentation outline. Online AI is not connected in this build.'];
  final pickedFiles = <PlatformFile>[];
  String generatedNotes = '', generatedSlides = '';
  late Future<void> loadPrefs;

  final personas = const ['NOVA Orb', 'Shonen Hero', 'Mystic Sage', 'Cyber Companion', 'Forest Guardian'];

  @override
  void initState() {
    super.initState();
    loadPrefs = _loadPrefs();
    tts.setLanguage('en-US');
  }
  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      persona = p.getString('persona') ?? persona;
      voiceEnabled = p.getBool('voiceEnabled') ?? true;
      privacyMode = p.getBool('privacyMode') ?? false;
      localMode = p.getBool('localMode') ?? true;
    });
  }
  Future<void> _savePrefs() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('persona', persona);
    await p.setBool('voiceEnabled', voiceEnabled);
    await p.setBool('privacyMode', privacyMode);
    await p.setBool('localMode', localMode);
  }
  @override
  void dispose() {
    prompt.dispose(); sourceText.dispose(); tts.stop(); super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_assistantPage(), _workspacePage(), _characterPage(), _settingsPage()];
    return FutureBuilder<void>(future: loadPrefs, builder: (context, snapshot) => Scaffold(
      appBar: AppBar(title: const Text('N O V A', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 3)), actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text('FEATURE PACK 2.1', style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.primary))))]),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.blur_circular), label: 'Assistant'),
        NavigationDestination(icon: Icon(Icons.auto_awesome_mosaic), label: 'Create'),
        NavigationDestination(icon: Icon(Icons.face_retouching_natural), label: 'Characters'),
        NavigationDestination(icon: Icon(Icons.tune), label: 'Settings'),
      ]),
    ));
  }

  Widget _assistantPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const SizedBox(height: 4), Center(child: AnimatedOrb()), const SizedBox(height: 10),
    Center(child: Text(persona, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19))),
    const Center(child: Text('Personal assistant • local interface', style: TextStyle(color: Colors.white60))),
    const SizedBox(height: 18),
    Row(children: [
      Expanded(child: _status(Icons.offline_bolt, 'LOCAL MODE', localMode ? 'Selected' : 'Not selected')),
      const SizedBox(width: 10), Expanded(child: _status(Icons.cloud_outlined, 'ONLINE AI', 'Needs provider setup')),
    ]),
    const SizedBox(height: 18),
    const Text('CONVERSATION', style: TextStyle(letterSpacing: 2, fontSize: 11, color: Colors.white60)),
    Container(height: 210, margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF101A2A), borderRadius: BorderRadius.circular(16)),
      child: ListView(children: chat.map((m) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(m, style: const TextStyle(height: 1.35)))).toList())),
    const SizedBox(height: 10),
    Row(children: [
      Expanded(child: TextField(controller: prompt, minLines: 1, maxLines: 3, decoration: InputDecoration(hintText: 'Ask NOVA or paste a task…', filled: true, fillColor: const Color(0xFF121C2D), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)))),
      IconButton.filled(onPressed: _sendPrompt, icon: const Icon(Icons.arrow_upward)),
      IconButton(onPressed: _listen, icon: const Icon(Icons.mic_none)),
    ]),
    const SizedBox(height: 8),
    const Text('Voice input uses your device speech service when available. The app does not have a wake word or connected AI provider yet.', style: TextStyle(fontSize: 11, color: Colors.white54)),
  ]);

  Widget _workspacePage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('FILE → NOTES → PRESENTATION', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
    const SizedBox(height: 8),
    const Text('Choose files to keep a working list, or paste extracted text below. This build generates notes and slide outlines from pasted text; automatic PDF/DOCX/PPTX extraction is not connected yet.', style: TextStyle(color: Colors.white70, height: 1.4)),
    const SizedBox(height: 14),
    FilledButton.icon(onPressed: _pickFiles, icon: const Icon(Icons.upload_file), label: const Text('Choose multiple files')),
    if (pickedFiles.isNotEmpty) ...[
      const SizedBox(height: 8),
      ...pickedFiles.map((f) => ListTile(dense: true, leading: const Icon(Icons.description_outlined), title: Text(f.name), subtitle: Text(f.size < 1024 ? '${f.size} bytes' : '${(f.size/1024).toStringAsFixed(1)} KB'))),
    ],
    const SizedBox(height: 12),
    TextField(controller: sourceText, minLines: 6, maxLines: 14, decoration: InputDecoration(hintText: 'Paste chapter, lecture, article, or notes here…', filled: true, fillColor: const Color(0xFF121C2D), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
    const SizedBox(height: 12),
    Wrap(spacing: 8, runSpacing: 8, children: [
      FilledButton.icon(onPressed: _makeNotes, icon: const Icon(Icons.notes), label: const Text('Generate easy notes')),
      OutlinedButton.icon(onPressed: _makeSlides, icon: const Icon(Icons.slideshow), label: const Text('Make slide outline')),
      OutlinedButton.icon(onPressed: _clearWorkspace, icon: const Icon(Icons.delete_outline), label: const Text('Clear')),
    ]),
    if (generatedNotes.isNotEmpty) ...[
      const SizedBox(height: 18), const Text('GENERATED STUDY NOTES', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      _outputCard(generatedNotes),
      OutlinedButton.icon(onPressed: () => _speak(generatedNotes), icon: const Icon(Icons.volume_up), label: const Text('Read notes aloud')),
    ],
    if (generatedSlides.isNotEmpty) ...[
      const SizedBox(height: 18), const Text('PRESENTATION OUTLINE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      _outputCard(generatedSlides),
    ],
    const SizedBox(height: 12),
    const Text('Note: this is a lightweight local text organizer, not an LLM. The generated content is based on sentence splitting and may miss meaning; verify important study material.', style: TextStyle(color: Colors.white54, fontSize: 11)),
  ]);

  Widget _characterPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('CHARACTER STUDIO', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6), const Text('Pick a persona. These are original concepts, not copies of specific anime characters. Voice style and advanced character animation need additional assets/services.', style: TextStyle(color: Colors.white70, height: 1.4)),
    const SizedBox(height: 12),
    ...personas.map((name) => Card(child: RadioListTile<String>(value: name, groupValue: persona, title: Text(name), subtitle: Text(name == 'NOVA Orb' ? 'Animated glowing orb' : 'Original anime-inspired persona'), secondary: const Icon(Icons.auto_awesome), onChanged: (v) async { setState(() => persona = v ?? persona); await _savePrefs(); }))),
    const SizedBox(height: 12),
    const Text('Future character pack: animated avatars, mouth movement synced to speech, individual voice profiles, expressions, and downloadable art packs.', style: TextStyle(color: Colors.white54, fontSize: 12)),
  ]);

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('SETTINGS & PRIVACY', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    SwitchListTile(value: localMode, title: const Text('Prefer local/offline mode'), subtitle: const Text('Preference only; no local language model is bundled.'), onChanged: (v) async { setState(() => localMode = v); await _savePrefs(); }),
    SwitchListTile(value: voiceEnabled, title: const Text('Enable spoken responses'), subtitle: const Text('Uses device text-to-speech when supported.'), onChanged: (v) async { setState(() => voiceEnabled = v); if (!v) await tts.stop(); await _savePrefs(); }),
    SwitchListTile(value: privacyMode, title: const Text('Privacy mode'), subtitle: const Text('Clears conversation from this screen when turned on.'), onChanged: (v) async { setState(() { privacyMode = v; if (v) chat.clear(); }); await _savePrefs(); }),
    const Divider(),
    const ListTile(leading: Icon(Icons.cloud), title: Text('Online AI'), subtitle: Text('Requires secure backend and provider credentials. Do not put API keys in app source or GitHub.')),
    const ListTile(leading: Icon(Icons.lock_outline), title: Text('Memory and profiles'), subtitle: Text('Only simple settings are saved locally. Encrypted long-term memory and multi-user profiles are not implemented.')),
    const ListTile(leading: Icon(Icons.devices), title: Text('Android + Windows'), subtitle: Text('Source is Flutter. Android/Windows native project scaffolding and build tests must be generated/run with Flutter tooling.')),
  ]);

  Widget _status(IconData icon, String title, String sub) => Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: const Color(0xFF121C2D), borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white10)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF64D8FF)), const SizedBox(height: 8), Text(title, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)), const SizedBox(height: 4), Text(sub, style: const TextStyle(fontSize: 11, color: Colors.white60))]));
  Widget _outputCard(String text) => Container(width: double.infinity, margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF111B2A), borderRadius: BorderRadius.circular(14)), child: SelectableText(text, style: const TextStyle(height: 1.45)));

  Future<void> _sendPrompt() async {
    final s = prompt.text.trim(); if (s.isEmpty) return;
    setState(() { chat.add('YOU: $s'); chat.add('NOVA: I received your request. The online AI/local model connection is not configured yet. You can use Create to turn pasted source text into basic notes or a slide outline.'); });
    prompt.clear();
    if (voiceEnabled) await _speak('I received your request. The AI connection is not configured yet.');
  }
  Future<void> _listen() async {
    final ok = await speech.initialize();
    if (!ok || !mounted) { _message('Speech recognition is unavailable on this device.'); return; }
    await speech.listen(onResult: (r) { if (r.finalResult && mounted) setState(() => prompt.text = r.recognizedWords); });
  }
  Future<void> _speak(String text) async { if (!voiceEnabled) return; try { await tts.stop(); await tts.speak(text.length > 3500 ? text.substring(0, 3500) : text); } catch (_) { _message('Text-to-speech is not available on this device.'); } }
  Future<void> _pickFiles() async {
    try { final r = await FilePicker.platform.pickFiles(allowMultiple: true, withData: false); if (r != null) setState(() { pickedFiles..clear()..addAll(r.files); }); }
    catch (e) { _message('Could not open file picker: $e'); }
  }
  void _makeNotes() {
    final raw = sourceText.text.trim(); if (raw.isEmpty) { _message('Paste some text first.'); return; }
    final sentences = raw.replaceAll(RegExp(r'\s+'), ' ').split(RegExp(r'(?<=[.!?])\s+')).where((s) => s.trim().isNotEmpty).toList();
    final key = sentences.take(12).map((s) => '• ${s.trim()}').join('\n');
    final words = raw.split(RegExp(r'\s+')).length;
    setState(() => generatedNotes = 'TITLE: Study Notes\n\nOVERVIEW\nThis source contains about $words words and ${sentences.length} sentence(s).\n\nKEY POINTS\n$key\n\nREVISION TIP\nReview the key points, underline unfamiliar terms, and compare this summary with the original source.');
  }
  void _makeSlides() {
    final raw = sourceText.text.trim(); if (raw.isEmpty) { _message('Paste some text first.'); return; }
    final sentences = raw.replaceAll(RegExp(r'\s+'), ' ').split(RegExp(r'(?<=[.!?])\s+')).where((s) => s.trim().isNotEmpty).toList();
    final out = StringBuffer('SLIDE 1 — TITLE\n${sentences.first}\n\n');
    final chunks = <List<String>>[];
    for (var i = 1; i < sentences.length; i += 3) { chunks.add(sentences.skip(i).take(3).toList()); }
    var n = 2;
    for (final chunk in chunks.take(8)) { out.writeln('SLIDE $n — KEY IDEAS'); for (final s in chunk) { out.writeln('• $s'); } out.writeln(); n++; }
    out.writeln('FINAL SLIDE — SUMMARY\n• Recap the main ideas\n• Add one example or diagram\n• End with a question for discussion');
    setState(() => generatedSlides = out.toString());
  }
  void _clearWorkspace() { setState(() { sourceText.clear(); generatedNotes = ''; generatedSlides = ''; pickedFiles.clear(); }); }
  void _message(String m) { if (!mounted) return; showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('NOVA'), content: Text(m), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))])); }
}

class AnimatedOrb extends StatefulWidget {
  const AnimatedOrb({super.key});
  @override
  State<AnimatedOrb> createState() => _AnimatedOrbState();
}
class _AnimatedOrbState extends State<AnimatedOrb> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
  @override
  void dispose() { c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: c, builder: (context, child) {
    final pulse = 1 + .045 * math.sin(c.value * math.pi * 2);
    return Transform.scale(scale: pulse, child: Container(width: 150, height: 150, decoration: BoxDecoration(shape: BoxShape.circle, gradient: const RadialGradient(colors: [Color(0xFFE0FBFF), Color(0xFF65D9FF), Color(0xFF1875C7), Color(0x001875C7)], stops: [0, .18, .55, 1]), boxShadow: [BoxShadow(color: const Color(0xFF35BFF5).withOpacity(.35), blurRadius: 34, spreadRadius: 4)]), child: const Icon(Icons.blur_circular, size: 58, color: Colors.white)));
  });
}
