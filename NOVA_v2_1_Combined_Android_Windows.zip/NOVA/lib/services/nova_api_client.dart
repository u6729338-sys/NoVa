import 'dart:convert';

import 'package:http/http.dart' as http;

class NovaApiException implements Exception {
  const NovaApiException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Communicates with a NOVA-owned backend. Provider API keys must never be
/// placed in this mobile/desktop client.
class NovaApiClient {
  NovaApiClient({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  Map<String, String> _headers(String token) => <String, String>{
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        if (token.trim().isNotEmpty) 'Authorization': 'Bearer ${token.trim()}',
      };

  Uri _endpoint(String baseUrl, String suffix) {
    final cleaned = baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.tryParse(cleaned);
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      throw const NovaApiException('Enter a valid NOVA backend URL.');
    }
    final host = uri.host.toLowerCase();
    final isLocal = host == 'localhost' ||
        host == '127.0.0.1' ||
        host == '::1' ||
        host == '10.0.2.2'; // Android emulator loopback bridge.
    if (uri.scheme != 'https' && !(uri.scheme == 'http' && isLocal)) {
      throw const NovaApiException(
        'Use HTTPS for remote servers. Plain HTTP is allowed only for localhost development.',
      );
    }
    return Uri.parse('$cleaned$suffix');
  }

  Future<String> chat({
    required String baseUrl,
    required String clientToken,
    required List<Map<String, String>> messages,
  }) async {
    final uri = _endpoint(baseUrl, '/api/chat');
    late final http.Response response;
    try {
      response = await _client
          .post(
            uri,
            headers: _headers(clientToken),
            body: jsonEncode(<String, dynamic>{'messages': messages}),
          )
          .timeout(const Duration(seconds: 70));
    } on NovaApiException {
      rethrow;
    } catch (_) {
      throw const NovaApiException(
        'Could not reach the NOVA backend. Check the URL, server, and network connection.',
      );
    }

    if (response.statusCode == 401) {
      throw const NovaApiException(
        'The NOVA backend rejected the client token. Check it in Settings.',
      );
    }
    if (response.statusCode == 503) {
      throw const NovaApiException(
        'The backend is running, but its AI provider is not configured. Check backend/.env.',
      );
    }
    if (response.statusCode == 429) {
      throw const NovaApiException(
        'The AI provider rate limit was reached. Wait a moment and try again.',
      );
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw NovaApiException(
        'The backend returned HTTP ${response.statusCode}. Check backend logs for details.',
      );
    }

    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map && decoded['reply'] is String) {
        final reply = (decoded['reply'] as String).trim();
        if (reply.isNotEmpty) return reply;
      }
    } catch (_) {
      // The generic error below intentionally avoids echoing arbitrary server data.
    }
    throw const NovaApiException('The backend returned an invalid response.');
  }

  Future<Map<String, dynamic>> health({
    required String baseUrl,
    required String clientToken,
  }) async {
    final uri = _endpoint(baseUrl, '/api/health');
    late final http.Response response;
    try {
      response = await _client
          .get(uri, headers: _headers(clientToken))
          .timeout(const Duration(seconds: 12));
    } catch (_) {
      throw const NovaApiException(
        'Could not reach the NOVA backend. Verify its URL and that the server is running.',
      );
    }
    if (response.statusCode == 401) {
      throw const NovaApiException('The backend rejected the client token.');
    }
    if (response.statusCode != 200) {
      throw NovaApiException('Backend health check failed (HTTP ${response.statusCode}).');
    }
    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } catch (_) {}
    throw const NovaApiException('The backend health response was invalid.');
  }

  void close() => _client.close();
}
