enum NovaIntentType {
  help,
  time,
  date,
  addNote,
  showNotes,
  addTask,
  showTasks,
  searchWeb,
  weather,
  togglePrivacy,
  openGoogle,
  openYouTube,
  openMaps,
  none,
}

class NovaIntent {
  const NovaIntent(this.type, {this.argument = ''});

  final NovaIntentType type;
  final String argument;
}

/// Small, deterministic command parser. It deliberately handles only local,
/// predictable commands. Unknown requests go to the configured AI backend.
class LocalIntentParser {
  const LocalIntentParser._();

  static NovaIntent parse(String input) {
    final text = input.trim();
    final q = text.toLowerCase();
    if (q.isEmpty) return const NovaIntent(NovaIntentType.none);

    if (q == 'help' || q == 'commands' || q.contains('what can you do')) {
      return const NovaIntent(NovaIntentType.help);
    }

    // Named destinations must be detected before the generic Google search.
    if (q == 'open google' || q == 'google') {
      return const NovaIntent(NovaIntentType.openGoogle);
    }
    if (q == 'open youtube' || q == 'youtube') {
      return const NovaIntent(NovaIntentType.openYouTube);
    }
    if (q == 'open maps' || q == 'open google maps' || q == 'maps') {
      return const NovaIntent(NovaIntentType.openMaps);
    }

    if (q.startsWith('search web for ')) {
      return NovaIntent(NovaIntentType.searchWeb,
          argument: text.substring('search web for '.length).trim());
    }
    if (q.startsWith('search for ')) {
      return NovaIntent(NovaIntentType.searchWeb,
          argument: text.substring('search for '.length).trim());
    }
    if (q.startsWith('google ')) {
      return NovaIntent(NovaIntentType.searchWeb,
          argument: text.substring('google '.length).trim());
    }

    if (q == 'weather' || q.startsWith('weather in ')) {
      return NovaIntent(
        NovaIntentType.weather,
        argument: q == 'weather' ? '' : text.substring('weather in '.length).trim(),
      );
    }

    if (q == 'time' || q == 'time now' || q.contains('what time') || q == 'tell me the time') {
      return const NovaIntent(NovaIntentType.time);
    }
    if (q == 'today' || q.contains('what date') || q.contains('what day') || q == 'date' || q.contains('today\'s date')) {
      return const NovaIntent(NovaIntentType.date);
    }

    if (q == 'show notes' || q == 'list notes' || q == 'read my notes') {
      return const NovaIntent(NovaIntentType.showNotes);
    }
    if (q.startsWith('add note ')) {
      return NovaIntent(NovaIntentType.addNote,
          argument: text.substring('add note '.length).trim());
    }
    if (q.startsWith('note ')) {
      return NovaIntent(NovaIntentType.addNote,
          argument: text.substring('note '.length).trim());
    }

    if (q == 'show tasks' || q == 'list tasks' || q == 'my tasks') {
      return const NovaIntent(NovaIntentType.showTasks);
    }
    if (q.startsWith('add task ')) {
      return NovaIntent(NovaIntentType.addTask,
          argument: text.substring('add task '.length).trim());
    }

    if (q == 'enable privacy' || q == 'private mode' || q == 'privacy on') {
      return const NovaIntent(NovaIntentType.togglePrivacy, argument: 'on');
    }
    if (q == 'disable privacy' || q == 'privacy off') {
      return const NovaIntent(NovaIntentType.togglePrivacy, argument: 'off');
    }
    if (q == 'privacy mode' || q == 'toggle privacy') {
      return const NovaIntent(NovaIntentType.togglePrivacy);
    }

    return const NovaIntent(NovaIntentType.none);
  }
}
