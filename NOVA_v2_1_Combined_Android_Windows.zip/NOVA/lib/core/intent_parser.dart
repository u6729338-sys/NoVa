enum NovaIntentType {
  help,
  time,
  date,
  addNote,
  showNotes,
  addTask,
  showTasks,
  searchWeb,
  weather,
  togglePrivacy,
  openGoogle,
  openYouTube,
  openMaps,
  openGmail,
  openCalendar,
  openDrive,
  openTranslate,
  openSpotify,
  openWhatsApp,
  openChatGPT,
  openGitHub,
  openNews,
  searchShopping,
  calculate,
  countTasks,
  clearChat,
  searchNotes,
  randomNumber,
  coinFlip,
  rollDice,
  celsiusToFahrenheit,
  fahrenheitToCelsius,
  kmToMiles,
  milesToKm,
  kgToPounds,
  poundsToKg,
  cmToInches,
  inchesToCm,
  percentage,
  countWords,
  countCharacters,
  uppercaseText,
  lowercaseText,
  reverseText,
  breathingExercise,
  studyPlan,
  summarizeNotes,
  none,
}

class NovaIntent {
  const NovaIntent(this.type, {this.argument = ''});

  final NovaIntentType type;
  final String argument;
}

/// Small, deterministic command parser. It deliberately handles only local,
/// predictable commands. Unknown requests go to the configured AI backend.
class LocalIntentParser {
  const LocalIntentParser._();

  static NovaIntent parse(String input) {
    final text = input.trim();
    final q = text.toLowerCase();
    if (q.isEmpty) return const NovaIntent(NovaIntentType.none);

    if (q == 'help' || q == 'commands' || q.contains('what can you do')) {
      return const NovaIntent(NovaIntentType.help);
    }

    // Offline utility commands added for v2.5.
    if (q == 'flip a coin' || q == 'coin flip' || q == 'flip coin') return const NovaIntent(NovaIntentType.coinFlip);
    if (q == 'roll a dice' || q == 'roll dice' || q == 'roll a die') return const NovaIntent(NovaIntentType.rollDice);
    if (q == 'random number' || q == 'pick a random number') return const NovaIntent(NovaIntentType.randomNumber, argument: '1 100');
    if (q.startsWith('random number ')) return NovaIntent(NovaIntentType.randomNumber, argument: text.substring('random number '.length).trim());
    if (q.startsWith('c to f ') || q.startsWith('celsius to fahrenheit ')) return NovaIntent(NovaIntentType.celsiusToFahrenheit, argument: text.substring(q.startsWith('c to f ') ? 7 : 22).trim());
    if (q.startsWith('f to c ') || q.startsWith('fahrenheit to celsius ')) return NovaIntent(NovaIntentType.fahrenheitToCelsius, argument: text.substring(q.startsWith('f to c ') ? 7 : 22).trim());
    if (q.startsWith('km to miles ')) return NovaIntent(NovaIntentType.kmToMiles, argument: text.substring(12).trim());
    if (q.startsWith('miles to km ')) return NovaIntent(NovaIntentType.milesToKm, argument: text.substring(12).trim());
    if (q.startsWith('kg to pounds ')) return NovaIntent(NovaIntentType.kgToPounds, argument: text.substring(13).trim());
    if (q.startsWith('pounds to kg ')) return NovaIntent(NovaIntentType.poundsToKg, argument: text.substring(13).trim());
    if (q.startsWith('cm to inches ')) return NovaIntent(NovaIntentType.cmToInches, argument: text.substring(13).trim());
    if (q.startsWith('inches to cm ')) return NovaIntent(NovaIntentType.inchesToCm, argument: text.substring(13).trim());
    if (q.startsWith('percentage ')) return NovaIntent(NovaIntentType.percentage, argument: text.substring(11).trim());
    if (q.startsWith('count words ')) return NovaIntent(NovaIntentType.countWords, argument: text.substring(12));
    if (q.startsWith('count characters ')) return NovaIntent(NovaIntentType.countCharacters, argument: text.substring(17));
    if (q.startsWith('uppercase ')) return NovaIntent(NovaIntentType.uppercaseText, argument: text.substring(10));
    if (q.startsWith('lowercase ')) return NovaIntent(NovaIntentType.lowercaseText, argument: text.substring(10));
    if (q.startsWith('reverse text ')) return NovaIntent(NovaIntentType.reverseText, argument: text.substring(13));
    if (q == 'breathing exercise' || q == 'help me relax') return const NovaIntent(NovaIntentType.breathingExercise);
    if (q == 'make a study plan' || q == 'study plan') return const NovaIntent(NovaIntentType.studyPlan);
    if (q == 'summarize my notes' || q == 'summary of my notes') return const NovaIntent(NovaIntentType.summarizeNotes);


    // Named destinations must be detected before the generic Google search.
    if (q == 'open google' || q == 'google') {
      return const NovaIntent(NovaIntentType.openGoogle);
    }
    if (q == 'open youtube' || q == 'youtube') {
      return const NovaIntent(NovaIntentType.openYouTube);
    }
    if (q == 'open maps' || q == 'open google maps' || q == 'maps') {
      return const NovaIntent(NovaIntentType.openMaps);
    }

    // Common destinations; all external launches still require user confirmation.
    if (q == 'open gmail' || q == 'gmail') return const NovaIntent(NovaIntentType.openGmail);
    if (q == 'open calendar' || q == 'calendar' || q == 'open google calendar') return const NovaIntent(NovaIntentType.openCalendar);
    if (q == 'open drive' || q == 'google drive' || q == 'open google drive') return const NovaIntent(NovaIntentType.openDrive);
    if (q == 'open translate' || q == 'google translate' || q == 'translate') return const NovaIntent(NovaIntentType.openTranslate);
    if (q == 'open spotify' || q == 'spotify') return const NovaIntent(NovaIntentType.openSpotify);
    if (q == 'open whatsapp' || q == 'whatsapp') return const NovaIntent(NovaIntentType.openWhatsApp);
    if (q == 'open chatgpt' || q == 'chatgpt') return const NovaIntent(NovaIntentType.openChatGPT);
    if (q == 'open github' || q == 'github') return const NovaIntent(NovaIntentType.openGitHub);
    if (q == 'open news' || q == 'news') return const NovaIntent(NovaIntentType.openNews);
    if (q == 'shopping' || q == 'search shopping' || q.startsWith('shop for ')) {
      final term = q.startsWith('shop for ') ? text.substring('shop for '.length).trim() : '';
      return NovaIntent(NovaIntentType.searchShopping, argument: term);
    }
    if (q.startsWith('calculate ') || q.startsWith('calc ')) {
      final prefix = q.startsWith('calculate ') ? 'calculate ' : 'calc ';
      return NovaIntent(NovaIntentType.calculate, argument: text.substring(prefix.length).trim());
    }
    if (q == 'count tasks' || q == 'how many tasks' || q == 'task count') return const NovaIntent(NovaIntentType.countTasks);
    if (q == 'clear chat' || q == 'clear conversation') return const NovaIntent(NovaIntentType.clearChat);
    if (q.startsWith('search notes for ')) return NovaIntent(NovaIntentType.searchNotes, argument: text.substring('search notes for '.length).trim());

    if (q.startsWith('search web for ')) {
      return NovaIntent(NovaIntentType.searchWeb,
          argument: text.substring('search web for '.length).trim());
    }
    if (q.startsWith('search for ')) {
      return NovaIntent(NovaIntentType.searchWeb,
          argument: text.substring('search for '.length).trim());
    }
    if (q.startsWith('google ')) {
      return NovaIntent(NovaIntentType.searchWeb,
          argument: text.substring('google '.length).trim());
    }

    if (q == 'weather' || q.startsWith('weather in ')) {
      return NovaIntent(
        NovaIntentType.weather,
        argument: q == 'weather' ? '' : text.substring('weather in '.length).trim(),
      );
    }

    if (q == 'time' || q == 'time now' || q.contains('what time') || q == 'tell me the time') {
      return const NovaIntent(NovaIntentType.time);
    }
    if (q == 'today' || q.contains('what date') || q.contains('what day') || q == 'date' || q.contains('today\'s date')) {
      return const NovaIntent(NovaIntentType.date);
    }

    if (q == 'show notes' || q == 'list notes' || q == 'read my notes') {
      return const NovaIntent(NovaIntentType.showNotes);
    }
    if (q.startsWith('add note ')) {
      return NovaIntent(NovaIntentType.addNote,
          argument: text.substring('add note '.length).trim());
    }
    if (q.startsWith('note ')) {
      return NovaIntent(NovaIntentType.addNote,
          argument: text.substring('note '.length).trim());
    }

    if (q == 'show tasks' || q == 'list tasks' || q == 'my tasks') {
      return const NovaIntent(NovaIntentType.showTasks);
    }
    if (q.startsWith('add task ')) {
      return NovaIntent(NovaIntentType.addTask,
          argument: text.substring('add task '.length).trim());
    }

    if (q == 'enable privacy' || q == 'private mode' || q == 'privacy on') {
      return const NovaIntent(NovaIntentType.togglePrivacy, argument: 'on');
    }
    if (q == 'disable privacy' || q == 'privacy off') {
      return const NovaIntent(NovaIntentType.togglePrivacy, argument: 'off');
    }
    if (q == 'privacy mode' || q == 'toggle privacy') {
      return const NovaIntent(NovaIntentType.togglePrivacy);
    }

    return const NovaIntent(NovaIntentType.none);
  }
}
