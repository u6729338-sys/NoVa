/// Provider-independent AI brain contract for NOVA.
/// A real offline generative model must be supplied by a compatible local runtime;
/// this interface deliberately does not pretend deterministic commands are an LLM.
enum NovaBrainMode { online, offline, privateOnly }

class NovaBrainRequest {
  const NovaBrainRequest({required this.text, this.context = const [], this.memories = const [], this.privateMode = false});
  final String text;
  final List<Map<String, String>> context;
  final List<String> memories;
  final bool privateMode;
}

class NovaBrainReply {
  const NovaBrainReply({required this.text, required this.mode, this.modelLabel = 'local-command-core'});
  final String text;
  final NovaBrainMode mode;
  final String modelLabel;
}

abstract interface class NovaBrainProvider {
  String get id;
  bool get isAvailable;
  Future<NovaBrainReply> answer(NovaBrainRequest request);
}

/// Safe offline fallback for status/help-style requests. Not a generative model.
class NovaLocalBrain implements NovaBrainProvider {
  const NovaLocalBrain();
  @override String get id => 'local-command-core';
  @override bool get isAvailable => true;
  @override Future<NovaBrainReply> answer(NovaBrainRequest request) async {
    final q = request.text.trim().toLowerCase();
    final answer = q.isEmpty
        ? 'Tell me what you need help with.'
        : (q == 'who are you' || q == 'what are you')
            ? 'I am NOVA. My local command core is available. General reasoning requires a configured online provider or an installed local language model.'
            : (q == 'help' || q == 'what can you do')
                ? 'I can handle supported local commands, notes and tasks. Configure an online AI backend for general conversation. A local generative model is not bundled in this build.'
                : 'I am offline and do not have a local generative model configured for that request. I have not sent your message online.';
    return NovaBrainReply(text: answer, mode: request.privateMode ? NovaBrainMode.privateOnly : NovaBrainMode.offline);
  }
}
