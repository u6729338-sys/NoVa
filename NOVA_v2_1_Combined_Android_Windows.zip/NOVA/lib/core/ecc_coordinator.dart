/// ECC-inspired safe tool coordinator. Tools must be explicitly registered.
enum EccActionRisk { readOnly, reversible, consequential }
enum EccRunState { planned, needsConfirmation, running, succeeded, failed, denied }

class EccToolResult {
  const EccToolResult({required this.success, required this.summary, this.data});
  final bool success;
  final String summary;
  final Object? data;
}

abstract interface class EccTool {
  String get id;
  EccActionRisk get risk;
  Future<EccToolResult> run(Map<String, Object?> arguments);
}

class EccExecution {
  const EccExecution({required this.toolId, required this.state, required this.message, this.result});
  final String toolId;
  final EccRunState state;
  final String message;
  final EccToolResult? result;
}

class EccCoordinator {
  final Map<String, EccTool> _tools = <String, EccTool>{};
  void register(EccTool tool) {
    if (tool.id.trim().isEmpty || tool.id.contains('..') || tool.id.contains('/')) {
      throw ArgumentError.value(tool.id, 'tool.id', 'Use a simple allowlisted identifier.');
    }
    _tools[tool.id] = tool;
  }
  List<String> get availableTools => List<String>.unmodifiable(_tools.keys);
  Future<EccExecution> execute(String toolId, Map<String, Object?> arguments, {bool confirmed = false}) async {
    final tool = _tools[toolId];
    if (tool == null) return EccExecution(toolId: toolId, state: EccRunState.denied, message: 'Tool is not registered in the allowlist.');
    if (tool.risk == EccActionRisk.consequential && !confirmed) {
      return EccExecution(toolId: toolId, state: EccRunState.needsConfirmation, message: 'User confirmation is required before this action.');
    }
    try {
      final result = await tool.run(Map<String, Object?>.unmodifiable(arguments));
      return EccExecution(toolId: toolId, state: result.success ? EccRunState.succeeded : EccRunState.failed, message: result.summary, result: result);
    } catch (_) {
      return EccExecution(toolId: toolId, state: EccRunState.failed, message: 'Tool failed. No success is claimed.');
    }
  }
}
