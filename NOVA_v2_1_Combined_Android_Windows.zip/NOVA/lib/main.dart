import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

import 'core/intent_parser.dart';
import 'services/nova_api_client.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NovaApp());
}

const novaCyan = Color(0xFF58C7FF);
const novaBackground = Color(0xFF090D16);
const _secureStorage = FlutterSecureStorage();

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NOVA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: novaBackground,
          colorScheme: ColorScheme.fromSeed(
            seedColor: novaCyan,
            brightness: Brightness.dark,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF0D1422),
            foregroundColor: Colors.white,
          ),
        ),
        home: const NovaHome(),
      );
}

class NovaMessage {
  const NovaMessage({required this.text, required this.fromNova, required this.time});
  final String text;
  final bool fromNova;
  final DateTime time;

  Map<String, String> toApiMap() => <String, String>{
        'role': fromNova ? 'assistant' : 'user',
        'content': text,
      };
}

class NovaHome extends StatefulWidget {
  const NovaHome({super.key});

  @override
  State<NovaHome> createState() => _NovaHomeState();
}

class _NovaHomeState extends State<NovaHome> {
  final _input = TextEditingController();
  final _noteInput = TextEditingController();
  final _taskInput = TextEditingController();
  final _backendInput = TextEditingController();
  final _tokenInput = TextEditingController();
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  final _scroll = ScrollController();
  final _api = NovaApiClient();

  final List<NovaMessage> _messages = <NovaMessage>[
    NovaMessage(
      text: 'Hello, I’m NOVA. I can manage local notes and tasks, respond to basic commands, and connect to your own AI backend when configured. Say “help” to see local commands.',
      fromNova: true,
      time: DateTime.now(),
    ),
  ];
  final List<String> _notes = <String>[];
  final List<Map<String, dynamic>> _tasks = <Map<String, dynamic>>[];

  String _backendUrl = '';
  String _clientToken = '';
  String _status = 'LOCAL READY';
  int _tab = 0;
  bool _listening = false;
  bool _thinking = false;
  bool _voiceInputEnabled = true;
  bool _voiceReplies = true;
  bool _privateMode = false;
  bool _savingConnection = false;

  @override
  void initState() {
    super.initState();
    _loadSaved();
    _configureSpeechOutput();
  }

  @override
  void dispose() {
    _input.dispose();
    _noteInput.dispose();
    _taskInput.dispose();
    _backendInput.dispose();
    _tokenInput.dispose();
    _scroll.dispose();
    _tts.stop();
    _api.close();
    super.dispose();
  }

  Future<void> _configureSpeechOutput() async {
    try {
      await _tts.setLanguage('en-IN');
      await _tts.setSpeechRate(0.47);
    } catch (_) {}
  }

  Future<void> _loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final token = await _secureStorage.read(key: 'nova_backend_client_token');
    if (!mounted) return;
    setState(() {
      _notes.addAll(prefs.getStringList('nova_notes_v2') ?? <String>[]);
      final rawTasks = prefs.getString('nova_tasks_v2');
      if (rawTasks != null) {
        try {
          final decoded = jsonDecode(rawTasks) as List<dynamic>;
          _tasks.addAll(decoded.map((e) => Map<String, dynamic>.from(e as Map)));
        } catch (_) {
          // Ignore damaged older task state; it must not prevent startup.
        }
      }
      _backendUrl = prefs.getString('nova_backend_url') ?? '';
      _clientToken = token ?? '';
      _backendInput.text = _backendUrl;
      _tokenInput.text = _clientToken;
      _voiceReplies = prefs.getBool('nova_voice_replies') ?? true;
      _voiceInputEnabled = prefs.getBool('nova_voice_input_enabled') ?? true;
      _privateMode = prefs.getBool('nova_private_mode') ?? false;
      _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
    });
  }

  Future<void> _saveNotes() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('nova_notes_v2', _notes);
  }

  Future<void> _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('nova_tasks_v2', jsonEncode(_tasks));
  }

  Future<void> _saveVoiceSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('nova_voice_replies', _voiceReplies);
    await prefs.setBool('nova_voice_input_enabled', _voiceInputEnabled);
    await prefs.setBool('nova_private_mode', _privateMode);
  }

  Future<void> _speak(String text) async {
    if (!_voiceReplies || _privateMode) return;
    try {
      await _tts.speak(text);
    } catch (_) {
      // Some desktop and Android installations do not have a working TTS voice.
    }
  }

  void _reply(String text) {
    if (!mounted) return;
    setState(() {
      _messages.add(NovaMessage(text: text, fromNova: true, time: DateTime.now()));
      _thinking = false;
      _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
    });
    _jumpToBottom();
    _speak(text);
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _listen() async {
    if (!_voiceInputEnabled) {
      _reply('Voice input is disabled. Turn it on in Settings to use the microphone.');
      return;
    }
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() { _listening = false; _status = _privateMode ? 'PRIVATE' : 'LOCAL READY'; });
      return;
    }

    bool available;
    try {
      available = await _speech.initialize(
        onStatus: (value) {
          if ((value == 'done' || value == 'notListening') && mounted) {
            setState(() {
              _listening = false;
              if (!_thinking) _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
            });
          }
        },
        onError: (_) {
          if (mounted) setState(() { _listening = false; _status = 'VOICE ERROR'; });
        },
      );
    } catch (_) {
      available = false;
    }

    if (!available) {
      _reply('Speech recognition is unavailable. Check microphone permission and the speech service on this device. Speech recognition may use your operating system’s own service.');
      return;
    }
    if (mounted) setState(() { _listening = true; _status = 'LISTENING'; });
    try {
      await _speech.listen(
        localeId: 'en_IN',
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 3),
        onResult: (result) {
          _input.text = result.recognizedWords;
          if (result.finalResult) {
            final recognized = result.recognizedWords.trim();
            if (mounted) setState(() { _listening = false; });
            if (recognized.isNotEmpty) _sendText(recognized);
          }
        },
      );
    } catch (_) {
      if (mounted) setState(() { _listening = false; _status = 'VOICE ERROR'; });
    }
  }

  void _send() => _sendText(_input.text);

  Future<void> _sendText(String value) async {
    final text = value.trim();
    if (text.isEmpty || _thinking) return;
    setState(() {
      _messages.add(NovaMessage(text: text, fromNova: false, time: DateTime.now()));
      _input.clear();
      _thinking = true;
      _status = _privateMode ? 'PRIVATE' : 'THINKING';
    });
    _jumpToBottom();
    await _process(text);
  }

  Future<void> _process(String text) async {
    final intent = LocalIntentParser.parse(text);
    if (intent.type != NovaIntentType.none) {
      await _runLocalIntent(intent);
      return;
    }

    if (_privateMode) {
      _reply('Privacy mode is on. I did not send this message to online AI. Turn privacy mode off to use your configured backend.');
      return;
    }
    if (_backendUrl.trim().isEmpty) {
      _reply('This request needs an AI brain that is not configured yet. Local notes, tasks, time/date, and browser shortcuts work now. In Settings, connect a NOVA backend. Provider API keys belong on the backend—not inside this app.');
      return;
    }

    final history = _messages
        .where((message) => message.text.trim().isNotEmpty)
        .toList(growable: false);
    final apiMessages = history.length > 16 ? history.sublist(history.length - 16) : history;

    try {
      final answer = await _api.chat(
        baseUrl: _backendUrl,
        clientToken: _clientToken,
        messages: apiMessages.map((message) => message.toApiMap()).toList(),
      );
      _reply(answer);
    } on NovaApiException catch (error) {
      _reply(error.message);
    } catch (_) {
      _reply('The online AI request failed. Check your backend and provider settings. Local commands remain available.');
    }
  }

  Future<void> _runLocalIntent(NovaIntent intent) async {
    switch (intent.type) {
      case NovaIntentType.help:
        _reply('Local commands: “time”, “date”, “add note …”, “show notes”, “add task …”, “show tasks”, “search web for …”, “weather in …”, “open Google”, “open YouTube”, “open Maps”, and “privacy mode”. Other questions use your configured AI backend.');
        return;
      case NovaIntentType.time:
        final now = DateTime.now();
        final hour = now.hour % 12 == 0 ? 12 : now.hour % 12;
        final minute = now.minute.toString().padLeft(2, '0');
        _reply('It is $hour:$minute ${now.hour >= 12 ? 'PM' : 'AM'}.');
        return;
      case NovaIntentType.date:
        final now = DateTime.now();
        const days = <String>['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        _reply('Today is ${days[now.weekday - 1]}, ${now.day}/${now.month}/${now.year}.');
        return;
      case NovaIntentType.addNote:
        if (intent.argument.isEmpty) {
          _reply('Tell me what note to save. You can say “add note buy groceries”.');
          return;
        }
        setState(() => _notes.add(intent.argument));
        await _saveNotes();
        _reply('Saved your note on this device.');
        return;
      case NovaIntentType.showNotes:
        _reply(_notes.isEmpty
            ? 'You have no saved notes yet. Say “add note” followed by your note.'
            : 'Your saved notes: ${_notes.asMap().entries.map((entry) => '${entry.key + 1}. ${entry.value}').join('. ')}');
        return;
      case NovaIntentType.addTask:
        if (intent.argument.isEmpty) {
          _reply('Tell me what task to add. You can say “add task finish my assignment”.');
          return;
        }
        setState(() => _tasks.add(<String, dynamic>{'text': intent.argument, 'done': false}));
        await _saveTasks();
        _reply('Task added. You can mark it complete in the Tasks tab.');
        return;
      case NovaIntentType.showTasks:
        final pending = _tasks.where((task) => task['done'] != true).toList();
        _reply(pending.isEmpty
            ? 'No pending tasks. Say “add task” followed by a task.'
            : 'Pending tasks: ${pending.asMap().entries.map((entry) => '${entry.key + 1}. ${entry.value['text']}').join('. ')}');
        return;
      case NovaIntentType.searchWeb:
        if (intent.argument.isEmpty) {
          _reply('Tell me what you want to search for.');
          return;
        }
        await _openUrlConfirmed(
          Uri.https('www.google.com', '/search', <String, String>{'q': intent.argument}),
          'search for: ${intent.argument}',
        );
        return;
      case NovaIntentType.weather:
        final place = intent.argument.trim();
        final query = place.isEmpty ? 'weather today' : 'weather in $place';
        await _openUrlConfirmed(
          Uri.https('www.google.com', '/search', <String, String>{'q': query}),
          query,
        );
        return;
      case NovaIntentType.togglePrivacy:
        final turnOn = intent.argument == 'on' ? true : intent.argument == 'off' ? false : !_privateMode;
        await _setPrivateMode(turnOn);
        _reply(_privateMode
            ? 'Privacy mode is on. Online AI requests and spoken replies are blocked.'
            : 'Privacy mode is off. Online AI is available when your backend is configured.');
        return;
      case NovaIntentType.openGoogle:
        await _openUrlConfirmed(Uri.https('www.google.com', '/'), 'Google');
        return;
      case NovaIntentType.openYouTube:
        await _openUrlConfirmed(Uri.https('www.youtube.com', '/'), 'YouTube');
        return;
      case NovaIntentType.openMaps:
        await _openUrlConfirmed(Uri.https('maps.google.com', '/'), 'Google Maps');
        return;
      case NovaIntentType.none:
        return;
    }
  }

  Future<void> _openUrlConfirmed(Uri uri, String description) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Open external website?'),
        content: Text('NOVA wants to open your browser to $description.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Open')),
        ],
      ),
    );
    if (!mounted) return;
    if (approved != true) {
      _reply('Cancelled.');
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      _reply(opened ? 'Opening $description.' : 'I could not open that website.');
    } catch (_) {
      _reply('I could not open that website.');
    }
  }

  Future<void> _setPrivateMode(bool enabled) async {
    if (!mounted) return;
    setState(() {
      _privateMode = enabled;
      if (enabled) _status = 'PRIVATE';
    });
    if (enabled) await _tts.stop();
    await _saveVoiceSettings();
  }

  Future<void> _saveConnection() async {
    if (_savingConnection) return;
    final url = _backendInput.text.trim().replaceFirst(RegExp(r'/+$'), '');
    if (url.isNotEmpty && Uri.tryParse(url) == null) {
      _showSnack('That backend URL is not valid.');
      return;
    }
    setState(() => _savingConnection = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('nova_backend_url', url);
      await _secureStorage.write(key: 'nova_backend_client_token', value: _tokenInput.text.trim());
      if (!mounted) return;
      setState(() {
        _backendUrl = url;
        _clientToken = _tokenInput.text.trim();
        _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
      });
      _showSnack(url.isEmpty ? 'Backend disconnected. Local features still work.' : 'Backend connection settings saved.');
    } catch (_) {
      _showSnack('Could not securely save your connection settings.');
    } finally {
      if (mounted) setState(() => _savingConnection = false);
    }
  }

  Future<void> _testConnection() async {
    final url = _backendInput.text.trim();
    final token = _tokenInput.text.trim();
    if (url.isEmpty) {
      _showSnack('Enter your backend URL first.');
      return;
    }
    _showSnack('Testing NOVA backend…');
    try {
      final health = await _api.health(baseUrl: url, clientToken: token);
      final ready = health['ai_configured'] == true;
      _showSnack(ready
          ? 'Backend reachable; AI provider configured.'
          : 'Backend reachable, but the AI provider is not configured yet.');
    } on NovaApiException catch (error) {
      _showSnack(error.message);
    } catch (_) {
      _showSnack('Connection test failed. Verify the URL and server.');
    }
  }

  void _showSnack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _addNoteFromField() async {
    final text = _noteInput.text.trim();
    if (text.isEmpty) return;
    setState(() { _notes.add(text); _noteInput.clear(); });
    await _saveNotes();
  }

  Future<void> _addTaskFromField() async {
    final text = _taskInput.text.trim();
    if (text.isEmpty) return;
    setState(() { _tasks.add(<String, dynamic>{'text': text, 'done': false}); _taskInput.clear(); });
    await _saveTasks();
  }

  String get _modeLabel => _privateMode
      ? 'PRIVATE'
      : (_thinking ? 'THINKING' : (_backendUrl.isEmpty ? 'LOCAL MODE' : 'AI BACKEND SET'));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Row(
            children: <Widget>[
              Icon(Icons.auto_awesome, color: novaCyan),
              SizedBox(width: 10),
              Text('NOVA', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
            ],
          ),
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: Center(child: Text(_status, style: const TextStyle(fontSize: 10, color: novaCyan))),
            ),
          ],
        ),
        body: IndexedStack(
          index: _tab,
          children: <Widget>[_chatPage(), _notesPage(), _tasksPage(), _globalViewPage(), _settingsPage()],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (index) => setState(() => _tab = index),
          destinations: const <NavigationDestination>[
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat), label: 'Chat'),
            NavigationDestination(icon: Icon(Icons.note_alt_outlined), selectedIcon: Icon(Icons.note_alt), label: 'Notes'),
            NavigationDestination(icon: Icon(Icons.check_circle_outline), selectedIcon: Icon(Icons.check_circle), label: 'Tasks'),
            NavigationDestination(icon: Icon(Icons.public), selectedIcon: Icon(Icons.public), label: 'Global View'),
            NavigationDestination(icon: Icon(Icons.tune), selectedIcon: Icon(Icons.tune), label: 'Settings'),
          ],
        ),
      );

  Widget _chatPage() => SafeArea(
        child: Column(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.fromLTRB(14, 12, 14, 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: <Color>[Color(0xFF142D47), Color(0xFF101827)]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF2C6384)),
              ),
              child: Row(
                children: <Widget>[
                  const CircleAvatar(backgroundColor: Color(0xFF153A54), child: Icon(Icons.graphic_eq, color: novaCyan)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                      const Text('Personal assistant', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 3),
                      Text('$_modeLabel • Local notes • Tasks', style: const TextStyle(fontSize: 11, color: Colors.white70)),
                    ]),
                  ),
                  IconButton(onPressed: () => _reply('Say “help” for supported local commands. Configure a private backend in Settings for general AI chat.'), icon: const Icon(Icons.help_outline)),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                itemCount: _messages.length + (_thinking ? 1 : 0),
                itemBuilder: (context, index) {
                  if (_thinking && index == _messages.length) {
                    return const Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(padding: EdgeInsets.all(12), child: Text('NOVA is working…', style: TextStyle(color: novaCyan))),
                    );
                  }
                  final message = _messages[index];
                  return Align(
                    alignment: message.fromNova ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .84),
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                      decoration: BoxDecoration(
                        color: message.fromNova ? const Color(0xFF172538) : const Color(0xFF164B67),
                        borderRadius: BorderRadius.circular(17),
                        border: Border.all(color: message.fromNova ? const Color(0xFF263D55) : const Color(0xFF23789D)),
                      ),
                      child: Text(message.text, style: const TextStyle(fontSize: 14, height: 1.38)),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
              child: Row(
                children: <Widget>[
                  IconButton.filled(
                    onPressed: _listen,
                    style: IconButton.styleFrom(backgroundColor: _listening ? Colors.redAccent : const Color(0xFF164B67)),
                    icon: Icon(_listening ? Icons.stop : (_voiceInputEnabled ? Icons.mic : Icons.mic_off)),
                    tooltip: _voiceInputEnabled ? 'Voice input' : 'Voice input disabled',
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      onSubmitted: (_) => _send(),
                      textInputAction: TextInputAction.send,
                      minLines: 1,
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: 'Message NOVA…',
                        filled: true,
                        fillColor: const Color(0xFF111A29),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(onPressed: _thinking ? null : _send, icon: const Icon(Icons.arrow_upward), tooltip: 'Send'),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _notesPage() => SafeArea(
        child: Column(
          children: <Widget>[
            const ListTile(
              title: Text('Your notes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Stored locally on this device'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _noteInput,
                    decoration: const InputDecoration(hintText: 'Write a note…', border: OutlineInputBorder()),
                    onSubmitted: (_) => _addNoteFromField(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _addNoteFromField, icon: const Icon(Icons.add)),
              ]),
            ),
            Expanded(
              child: _notes.isEmpty
                  ? const Center(child: Text('No notes yet.'))
                  : ListView.builder(
                      itemCount: _notes.length,
                      itemBuilder: (context, index) => ListTile(
                        leading: const Icon(Icons.sticky_note_2_outlined, color: novaCyan),
                        title: Text(_notes[index]),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async { setState(() => _notes.removeAt(index)); await _saveNotes(); },
                        ),
                      ),
                    ),
            ),
          ],
        ),
      );

  Widget _tasksPage() => SafeArea(
        child: Column(
          children: <Widget>[
            const ListTile(
              title: Text('Tasks', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Add a task, then tick it off when complete'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _taskInput,
                    decoration: const InputDecoration(hintText: 'New task…', border: OutlineInputBorder()),
                    onSubmitted: (_) => _addTaskFromField(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _addTaskFromField, icon: const Icon(Icons.add)),
              ]),
            ),
            Expanded(
              child: _tasks.isEmpty
                  ? const Center(child: Text('No tasks yet.'))
                  : ListView.builder(
                      itemCount: _tasks.length,
                      itemBuilder: (context, index) {
                        final task = _tasks[index];
                        final done = task['done'] == true;
                        return CheckboxListTile(
                          value: done,
                          title: Text(
                            '${task['text']}',
                            style: TextStyle(decoration: done ? TextDecoration.lineThrough : null),
                          ),
                          onChanged: (value) async {
                            setState(() => task['done'] = value ?? false);
                            await _saveTasks();
                          },
                          secondary: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async { setState(() => _tasks.removeAt(index)); await _saveTasks(); },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      );

  Widget _globalViewPage() => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            const Text('NOVA Global View', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('A planned dashboard for public information and cameras you are explicitly authorized to access.'),
            const SizedBox(height: 18),
            _featureCard(
              icon: Icons.public,
              title: 'Global data map',
              body: 'Not connected yet. Future integrations can display selected public data sources with source labels and timestamps.',
            ),
            const SizedBox(height: 12),
            _featureCard(
              icon: Icons.videocam_outlined,
              title: 'Authorized camera connections',
              body: 'No cameras are scanned or connected by this build. The planned CCTV connector will use your own NVR/camera credentials and explicit permissions.',
            ),
            const SizedBox(height: 12),
            _featureCard(
              icon: Icons.verified_user_outlined,
              title: 'Privacy and audit trail',
              body: 'Camera access must be authenticated, limited to permitted feeds, and logged. NOVA will not bypass passwords or search for private camera streams.',
            ),
          ],
        ),
      );

  Widget _featureCard({required IconData icon, required String title, required String body}) => Card(
        color: const Color(0xFF111A29),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Icon(icon, color: novaCyan, size: 28),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 6),
              Text(body, style: const TextStyle(height: 1.4, color: Colors.white70)),
            ])),
          ]),
        ),
      );

  Widget _settingsPage() => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            const Text('Settings & privacy', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.mic, color: novaCyan),
              title: const Text('Voice input'),
              subtitle: const Text('Use the device speech recognition service'),
              value: _voiceInputEnabled,
              onChanged: (enabled) async {
                if (!enabled && _listening) await _speech.stop();
                setState(() { _voiceInputEnabled = enabled; _listening = false; });
                await _saveVoiceSettings();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.volume_up, color: novaCyan),
              title: const Text('Spoken replies'),
              subtitle: const Text('Speak NOVA responses aloud'),
              value: _voiceReplies,
              onChanged: (enabled) async {
                setState(() => _voiceReplies = enabled);
                if (!enabled) await _tts.stop();
                await _saveVoiceSettings();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.shield_outlined, color: novaCyan),
              title: const Text('Privacy mode'),
              subtitle: const Text('Blocks online AI requests and spoken replies'),
              value: _privateMode,
              onChanged: _setPrivateMode,
            ),
            const Divider(height: 30),
            const Text('Connect an AI backend', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'NOVA sends chat to your own backend. Keep provider API keys on the server, never in the Android app or GitHub.',
              style: TextStyle(color: Colors.white70, height: 1.35),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _backendInput,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'Backend URL',
                hintText: 'https://your-private-server.example',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.cloud_outlined),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _tokenInput,
              obscureText: true,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'NOVA backend client token (optional for local-only use)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.key_outlined),
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'This is the token for your NOVA server—not your OpenAI/Gemini provider API key. Remote servers should use HTTPS.',
              style: TextStyle(fontSize: 12, color: Colors.white60, height: 1.35),
            ),
            const SizedBox(height: 12),
            Row(children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  onPressed: _savingConnection ? null : _saveConnection,
                  icon: const Icon(Icons.save_outlined),
                  label: Text(_savingConnection ? 'Saving…' : 'Save connection'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _testConnection,
                  icon: const Icon(Icons.network_check),
                  label: const Text('Test backend'),
                ),
              ),
            ]),
            const SizedBox(height: 22),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.storage_outlined, color: novaCyan),
              title: Text('Local storage'),
              subtitle: Text('Notes and tasks are stored with app preferences. They are not encrypted by this app. Do not save passwords or highly sensitive information.'),
            ),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.policy_outlined, color: novaCyan),
              title: Text('Online AI and privacy'),
              subtitle: Text('When privacy mode is off, recent chat messages may be sent to your configured backend. Your backend provider may process them. Device speech recognition may also use OS services.'),
            ),
            OutlinedButton.icon(
              onPressed: _confirmClearData,
              icon: const Icon(Icons.delete_forever_outlined),
              label: const Text('Delete all local notes and tasks'),
            ),
            const SizedBox(height: 12),
            const Text(
              'Build status: this package is a source-first foundation. Full local-model inference, autonomous tool execution, web research, notifications, and camera feeds are not yet implemented.',
              style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
            ),
          ],
        ),
      );

  Future<void> _confirmClearData() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete local data?'),
        content: const Text('This permanently deletes NOVA notes and tasks saved on this device. Chat history is kept only in memory and will also be cleared.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete all')),
        ],
      ),
    );
    if (approved != true) return;
    setState(() { _notes.clear(); _tasks.clear(); _messages.clear(); });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('nova_notes_v2');
    await prefs.remove('nova_tasks_v2');
    if (mounted) _showSnack('Local notes and tasks deleted.');
  }
}
