from pathlib import Path
import re

manifest = Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    text = manifest.read_text(encoding="utf-8")
    permissions = (
        '    <uses-permission android:name="android.permission.INTERNET" />',
        '    <uses-permission android:name="android.permission.RECORD_AUDIO" />',
    )
    for permission in permissions:
        if permission not in text:
            text = re.sub(r"(<application\b)", lambda match: permission + "\n" + match.group(1), text, count=1)
    manifest.write_text(text, encoding="utf-8")
else:
    raise SystemExit("AndroidManifest.xml is missing. Run flutter create --platforms=android first.")

# flutter_secure_storage 11.x requires Android API level 23 or newer.
for gradle_path in (Path("android/app/build.gradle.kts"), Path("android/app/build.gradle")):
    if not gradle_path.exists():
        continue
    text = gradle_path.read_text(encoding="utf-8")
    if gradle_path.name.endswith(".kts"):
        text = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 23", text)
        text = re.sub(r"minSdk\s*=\s*\d+", "minSdk = 23", text)
    else:
        text = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 23", text)
        text = re.sub(r"minSdkVersion\s+\d+", "minSdkVersion 23", text)
    gradle_path.write_text(text, encoding="utf-8")
    break
print("Android microphone/network permissions and minimum SDK checked.")
