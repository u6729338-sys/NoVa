#!/usr/bin/env bash
set -euo pipefail
command -v flutter >/dev/null 2>&1 || { echo "Flutter was not found on PATH." >&2; exit 1; }
flutter create --platforms=android,windows --project-name nova .
python3 scripts/ensure_android_permissions.py
flutter pub get
echo "NOVA platform folders and dependencies are ready."
