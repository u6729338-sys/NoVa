$ErrorActionPreference = "Stop"
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw "Flutter was not found on PATH. Install Flutter first: https://docs.flutter.dev/get-started/install/windows/desktop"
}
flutter create --platforms=android,windows --project-name nova .
if ($LASTEXITCODE -ne 0) { throw "flutter create failed" }
python scripts/ensure_android_permissions.py
if ($LASTEXITCODE -ne 0) { throw "Android setup failed" }
flutter pub get
if ($LASTEXITCODE -ne 0) { throw "flutter pub get failed" }
Write-Host "NOVA platform folders and dependencies are ready."
