# NOVA × ECC Implementation Roadmap

This is a proposal, not a claim that these features are already implemented.

## Stage 0 — Repository audit
- Inspect the real Flutter source tree and `pubspec.yaml`.
- Confirm Android and Windows targets, entry points, state management, storage, and existing features.
- Establish a feature inventory: implemented, partial, planned, broken.
- Keep the current working version safe; use a branch and pull request.

## Stage 1 — Development quality
- Add formatting and static-analysis checks.
- Add unit tests for core logic and storage.
- Add a pull-request checklist and clear feature status documentation.
- Adopt ECC-inspired research → plan → implement → test → review → verify workflow.

## Stage 2 — App foundations
- Centralize settings and error reporting.
- Define typed interfaces for AI providers and local tools.
- Add user-controlled memory and account-scoped storage.
- Keep API secrets out of app binaries.

## Stage 3 — Agent MVP
- Implement task planner, tool registry, permission gate, approval UI, execution history, and failure handling.
- Start with notes, reminders, authorized file search, and web search.
- Add tests for denied permissions, tool failures, duplicate requests, and cancelled approvals.

## Stage 4 — Voice and model routing
- Add speech input/output with explicit platform constraints.
- Add online/offline routing only where a real local model and runtime are available.
- Add cloud cost controls and privacy settings.

## Stage 5 — Platform hardening
- Test Android and Windows independently.
- Verify data isolation, deletion, backup/restore, permissions, and update behaviour.
- Run dependency and secret scans.
- Release only features whose acceptance tests pass.

## Definition of done
A feature is done only when its UI, real behaviour, error states, permissions, tests, and documentation are present. A button or mock response alone does not count.
