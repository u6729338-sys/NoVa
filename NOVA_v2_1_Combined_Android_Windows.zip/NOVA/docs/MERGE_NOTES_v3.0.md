# NOVA v3.0 Merge Notes

The ECC integration pack was merged into the v2.6 project as documentation and a manual CI workflow. ECC is a development toolkit, not a Flutter runtime package, so its ideas are represented as process guidance and architecture proposals rather than falsely advertised as app features.

## Included
- All v2.6 app source and retained feature foundations.
- ECC-inspired development workflow and security checklist.
- Proposed permission-aware agent architecture.
- Staged implementation roadmap.
- Manual Flutter quality workflow.
- Version metadata and README/changelog updated to 3.0.

## Next engineering steps
1. Upload the contents of this `NOVA/` folder to the repository root on a separate branch.
2. Run the Android/Windows build workflow.
3. Run the manual quality workflow.
4. Fix any build or analysis failures before replacing the currently installed app.
5. Implement real agent tools incrementally, each with permission checks, error handling, tests, and acceptance criteria.
