# Merge notes — NOVA v2.1 combined package

This package combines the NOVA v2.0 core source with the Android/Windows CI build approach from `NOVA_Build_Fix_Android_Windows.zip`.

## Merge decisions
- Kept v2.0 `lib/main.dart`, `pubspec.yaml`, API client, intent parser, backend, tests, documentation, and scripts because these are the more complete source versions.
- Integrated the build-fix workflow logic into `.github/workflows/build.yml` and kept one workflow to avoid duplicate CI runs.
- The workflow generates Android/Windows platform scaffolding, checks Android microphone/network permissions and minimum SDK, runs Flutter tests, and builds downloadable artifacts.
- The build-fix ZIP's older/smaller `lib/main.dart` and reduced `pubspec.yaml` were deliberately not used because they would remove v2.0 features and secure backend integration.

## Verification status
This archive was assembled by combining source files and inspecting the ZIP contents. It has **not** been compiled with Flutter in this environment, and no GitHub Actions run has verified the APK or Windows build. The first GitHub Actions run is the real build test. Static analysis is reported but configured not to block packaging; tests and compilation still can fail.

## Not a finished JARVIS
This remains an early foundation. It does not yet include a local offline LLM, always-on wake word, full phone/desktop control, or operational global camera view. Do not put provider API keys in the Flutter app or commit `backend/.env`.
