# NOVA In-App Agent Architecture

## Purpose
Provide a path for NOVA to progress from chat-only behaviour toward reliable, permission-aware task execution on Android and Windows.

## Proposed components
1. **Conversation interface** — text and voice interaction.
2. **Model router** — chooses an available local or cloud model according to capability, user settings, connectivity, and cost limits.
3. **Task planner** — converts a request into a short list of explicit steps.
4. **Tool registry** — exposes only approved, typed tools such as notes, reminders, file search, and web search.
5. **Permission gate** — checks platform permissions and NOVA's own authorization rules before each action.
6. **Approval manager** — asks the user to approve consequential actions such as sending messages, deleting files, publishing content, or spending money.
7. **Execution engine** — runs one approved tool at a time and records the outcome.
8. **Memory service** — stores user-approved preferences and useful project context with inspect/edit/delete controls.
9. **Audit log** — records action, timestamp, result, and approval status without unnecessarily logging sensitive content.
10. **Recovery handler** — reports failures clearly and retries only safe, idempotent actions.

## Example task flow
Request: "Find my economics notes and make a revision plan."

1. Parse intent and identify relevant workspace.
2. Search only permitted folders.
3. Show the files selected and ask a clarifying question if ambiguous.
4. Summarise relevant material.
5. Draft the revision plan.
6. Save only after the user approves, or use an explicit save preference.
7. Report the actual result and any limitations.

## Safety boundaries
- Tools must be allowlisted and use typed arguments; the model must not generate unrestricted shell commands for direct execution.
- Ask for confirmation before external or irreversible actions.
- Use least-privilege OS permissions and explain why a permission is needed.
- Keep each account's memories, documents, and settings isolated.
- Private mode must have clearly defined storage behaviour.
- Local-only tasks should remain local when feasible.
- Before sending content to a cloud model, follow the user's privacy settings and disclose the transfer where appropriate.
- Never claim that an action succeeded unless the tool returns success.
- Provide undo for supported reversible actions.
- Voice recognition alone must not authorize sensitive actions.
- Respect Android background-execution and Windows security constraints.

## Initial tools
Start with low-risk tools:
- `create_note`
- `search_notes`
- `create_reminder`
- `search_authorized_files`
- `open_app` (platform-specific and allowlisted)
- `web_search`

Add messaging, file deletion, publishing, and financial actions only after robust confirmation and audit controls exist.
