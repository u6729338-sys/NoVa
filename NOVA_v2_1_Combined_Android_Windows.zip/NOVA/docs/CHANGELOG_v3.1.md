# NOVA v3.1 Advanced — change log

## Included in this source upgrade
- Fixed the two Dart compile errors identified in the prior GitHub Actions log: removed unsupported `Wrap.mainAxisSize` and reformatted the backup/restore `Row`.
- Added a Systems screen with a full-body NOVA concept illustration, companion selector, floating-character controls, God Eye scope/status, and ECC workflow/status.
- Added an Android `MethodChannel` bridge and generated native overlay service. The user must explicitly grant Android's “Display over other apps” permission. The draggable overlay shows the full-body concept image and a character label; tapping it returns to NOVA.
- Added `scripts/configure_android_overlay.py`, invoked by the Android build workflow after Flutter generates platform files. It registers permissions/service and writes native Kotlin files and the character asset.
- Reframed Global View as God Eye / authorized data view, explicitly distinguishing planned integrations from live ones.
- Updated version to `3.1.0+31`.

## Honest limitations
- This has not been built or tested with Flutter/Android SDK in this environment. GitHub Actions must confirm compilation.
- The character image is a static concept illustration, not a 3D animated avatar, and alternate characters still use icons.
- Android overlay is a basic draggable picture overlay; it is not a fully interactive animated companion. Android permission must be enabled by the user. It may behave differently across OEMs and Android versions.
- Windows always-on-top overlay is not implemented by this release.
- God Eye is currently a dashboard and privacy/authorization boundary. Live screen analysis, camera analysis, broad device telemetry, people tracking, and external feed integrations are not implemented.
- ECC is a documented planning/permission/execute/verify workflow and UI status panel, not a complete autonomous agent runtime or a collection of installed ECC hooks.
- Offline generative AI, wake-word listening, real scheduled notifications, multi-device cloud sync, speaker authentication, and document/video ingestion remain unimplemented.
