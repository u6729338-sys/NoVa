# Research references for later integrations

These links are starting points to inspect before adopting a dependency. Recheck maintenance activity, licensing, platform support, dependencies and security posture before integration.

- [OpenJarvis](https://github.com/open-jarvis/OpenJarvis) — local-first personal AI primitives, model engines, agent workflows, memory and evaluation.
- [PersonalJarvis](https://github.com/tbckdev/PersonalJarvis) — desktop agent/voice/automation patterns; study its architecture and licence before reuse.
- [LlamaDart](https://github.com/leehack/llamadart) — on-device LLM runtime options for Flutter/Dart; model size, runtime support and minimum SDK requirements must be verified for the target device.
- [Frigate](https://github.com/blakeblackshear/frigate) — local NVR/object detection for cameras the operator is authorized to manage.
- [Frigate authentication documentation](https://docs.frigate.video/configuration/authentication/) — important roles and proxy/security configuration considerations.

Do not copy whole repositories into NOVA blindly. Prefer stable APIs, small audited components and a testable adapter. Licences and security implications may differ between projects.
