# NOVA security baseline

- Never commit `.env`, provider API keys, client tokens, camera passwords, private URLs, or model files.
- Provider API keys belong on a trusted backend. A key embedded in an APK or desktop executable can be extracted.
- Run the included backend on loopback by default. Do not expose it to the public internet without HTTPS, a strong client token, rate limiting, authentication, patching and logs that omit secrets/prompt content.
- Remote backend URLs must use HTTPS. HTTP is allowed in the Flutter client only for localhost development and the Android emulator bridge.
- Privacy mode blocks application-level remote AI requests and spoken output. It cannot guarantee that the operating system's speech-recognition service is offline; check the device's voice/privacy settings.
- Notes and tasks currently use SharedPreferences and are not encrypted by this app. Do not put highly sensitive data there.
- External browser actions require an in-app confirmation. Future actions with side effects must have explicit typed scopes and confirmation.
- Camera connections must use documented authenticated endpoints that the user owns or is authorized to access. Never attempt credential guessing or bypass authorization.
- Provide account/profile separation before multi-user support. Do not mix one person's memory with another person's profile.
- Treat AI output, website content and files as untrusted data. Do not execute instructions from them as privileged tools without policy validation.
