# NOVA × ECC Integration Pack

This pack proposes a safe integration of ideas from [Everything Claude Code (ECC)](https://github.com/affaan-m/ECC) into the NOVA project.

**Important:** ECC is a developer workflow/toolkit, not a Flutter runtime library. This pack does not copy ECC source code into NOVA or claim that the app already implements these features. It separates:
- developer workflow improvements, used while building NOVA;
- NOVA runtime capabilities, implemented in the Android/Windows app.

## Files
- `docs/DEVELOPMENT_TOOLKIT.md` — how to use ECC-inspired workflows during development.
- `docs/NOVA_AGENT_ARCHITECTURE.md` — proposed in-app agent architecture and safety boundaries.
- `docs/IMPLEMENTATION_ROADMAP.md` — staged implementation plan.
- `.github/workflows/flutter-ci.yml` — starter CI workflow; review and adapt to the repository's actual Flutter layout before enabling.

## Official ECC source
Use the official repository and its current installation instructions only: https://github.com/affaan-m/ECC

Do not blindly copy hooks, scripts, permissions, MCP configurations, or agent instructions into the app repository. Review them first, pin versions where possible, and avoid exposing secrets.
