# NOVA v2.3

## Added
1. Simple local calculator for two operands.
2. Search saved notes by keyword.
3. Pending/completed task count.
4. Clear chat while preserving notes and tasks.
5. Gmail shortcut.
6. Calendar shortcut.
7. Drive shortcut.
8. Translate shortcut.
9. Spotify shortcut.
10. WhatsApp Web shortcut.
11. ChatGPT shortcut.
12. GitHub shortcut.
13. Google News shortcut.
14. Shopping search shortcut.

All external website launches ask for confirmation. These are shortcuts, not deep integrations or permission to send messages/purchases. The project remains an early-stage foundation and builds must be verified in CI.
