# NOVA v2.4 — Character AI + full personal-assistant vision

This document preserves the user's full product vision. A listed roadmap item is not automatically a working feature; see status labels below.

## Implemented in this source package (needs device/build verification)
- [Implemented, basic] Selectable original companion personas: NOVA Orb, Aiko, Kairo, Mira and Rex.
- [Implemented, basic] Companion selection persists locally and changes the system prompt sent to the configured backend.
- [Implemented, basic] User-approved memories can be added and deleted in Settings; up to 20 short memories are sent with an online request when Privacy Mode is off.
- [Existing foundation] Chat, speech input/output where supported, local notes/tasks, basic intent commands, backend connection settings, privacy mode, Android/Windows CI workflow.
- [Safety] Privacy mode prevents chat being sent to online AI and suppresses TTS; voice recognition can still rely on OS services when explicitly used.

## Character AI concept — original characters, not copies of existing copyrighted characters
Each companion should eventually have:
- a distinct original visual identity, optional 2D/3D avatar, selectable outfits/colours and accessibility options;
- personality, conversation style, values, boundaries and separate user-approved memory;
- a distinct supported TTS voice/voice settings; never promise a unique voice if the platform does not provide it;
- facial expressions, gestures, idle animation, listening/thinking/speaking states and lip-sync;
- conversational awareness of NOVA's current status and tasks, limited to explicitly exposed status data;
- an orb-only mode and reduced-motion/static-avatar mode;
- clear disclosure that characters are AI, not real people. No manipulative dependency or claims of human feelings.

The current version only implements a companion selector and persona instructions for online AI. Character art, advanced animation, lip-sync, voice matching and per-character isolated memories are future work.

## Full user vision and honest implementation status
- [Foundation exists] Voice chat; Android and Windows app shell.
- [Planned] Wake phrase “Hey NOVA”, background listening, battery/privacy controls and platform-specific permission handling.
- [Planned] Local model inference for genuine offline generative AI; local deterministic commands are not the same as offline generative AI.
- [Foundation exists / planned] Online provider gateway; add provider/model selection and explicit cost-aware routing. ChatGPT/Gemini-like capability requires configured providers, may cost money, and cannot be promised free or superior to those systems.
- [Planned] Automatic online/offline routing with visible status and no silent upload of local content.
- [Planned] Reminders and OS notifications with timezone, permission, reboot and missed-notification handling.
- [Planned] Document Study Studio: import PDF/text, extract content, summarise, explain, translate, make flashcards/quizzes, export notes. Must show extraction failures and source/page references.
- [Planned] File assistant limited to files the user explicitly selects or grants access to.
- [Planned] Android actions for flashlight, camera, battery, maps and supported app intents, each gated by platform capabilities/permissions.
- [Planned] Windows app launcher and separately permissioned automation service; no unrestricted control claim.
- [Planned] Calls, SMS and WhatsApp assistance. Preview and confirm before any external message/call; use only supported public APIs or user-facing intents.
- [Planned] Profiles with isolated notes, memory, character choice and settings; profile switching must not expose another user's data.
- [Planned] Memory review, edit, export, delete and age-based summarisation after 3–4 months. Never silently delete source memories; user approves summaries.
- [Planned] Optional TeraBox/cloud-storage integration only if an official supported API and permission model are available.
- [Planned] Translation with online and optional downloaded offline language models.
- [Planned] Research assistant that searches permitted sources, records URLs/dates, compares claims and labels uncertainty.
- [Planned] Voice verification as a convenience signal, not sole security for sensitive actions; use device authentication for high-risk actions.
- [Planned] NOVA Global View with public data feeds and only cameras the user owns or is explicitly authorised to access. No bypassing logins or indiscriminate surveillance.
- [Planned] Multi-agent workflow orchestration with user approval before sending, publishing, changing files, spending money or operating devices.

## Recommended implementation order
1. Build verification and command tests; fix Android and Windows CI.
2. Companion selector + backend persona + local memory controls (this package's first implementation).
3. Profile isolation and memory export/delete.
4. Document import/study tools and source-aware outputs.
5. Reliable reminders/notifications and supported Android utilities.
6. Offline model experiment with device compatibility and download size disclosed.
7. Windows launcher/approved actions.
8. Character art, animations, expression states, lip-sync and voice options.
9. Wake-word prototype after privacy, battery and foreground-service behavior are tested.
10. Research, optional cloud connectors and Global View only after permissions and data provenance are established.

## Definition of done
Do not label a feature complete until it has code, tests, visible status, permission handling, failure handling, privacy documentation and successful Android + Windows testing. CI passing is required but not a substitute for testing on real devices.
