# NOVA v3.3

- Added a Dockerfile for the Python AI gateway and a Render deployment blueprint.
- Removed a guessed model identifier from the environment template; model selection is explicit.
- Added integration and honest capability/validation documentation for online AI, offline AI, overlay, God's Eye, ECC, and downloaded repositories.
- No claim of successful device testing or live screen capture is made in this release.
