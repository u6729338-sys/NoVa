# NOVA v2.6 — Real productivity features

This release keeps the v2.5 utility commands and Character AI foundation, and adds five practical app capabilities:

1. **Persistent chat history** — saves the most recent 200 messages locally and restores them on startup. Clearing chat removes the stored conversation.
2. **Edit notes** — notes can be edited as well as deleted.
3. **Task priorities** — tasks created through the add-task dialog can be marked Low, Medium, or High priority.
4. **Task due dates** — optional calendar date selection is available when creating a task; dates appear in the task list. This is not a notification/reminder scheduler.
5. **Backup and restore** — creates a versioned JSON backup of notes, tasks, memories, chat history, companion selection, and voice/privacy preferences, copied to the clipboard. Restore validates the backup format before replacing data.

## Existing features retained

The v2.5 local utility commands, browser shortcuts with confirmation, character selection, local memories, backend chat connection, voice input/output where supported, notes, tasks, privacy mode, and Android/Windows build workflow remain in the project.

## Limits and verification

- Backup JSON contains personal content; store it privately.
- Chat history is stored in app preferences and is not encrypted by this app.
- Task due dates are displayed only; operating-system notifications are not implemented here.
- Flutter tests and Android/Windows builds have not been run in this environment. Run CI before installing.
