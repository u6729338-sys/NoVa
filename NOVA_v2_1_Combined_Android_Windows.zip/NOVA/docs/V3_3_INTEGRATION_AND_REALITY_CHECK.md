# NOVA v3.3 — Integration and Reality Check

## Changes in this package
- Adds a Docker image definition for the existing Python AI gateway.
- Adds a Render blueprint (`render.yaml`) to make deployment reproducible.
- Removes the unverified model-name default from `.env.example`; users must select a model actually enabled for their provider account.
- Adds explicit deployment and validation steps.
- Preserves privacy boundaries: provider secrets stay on the server; a hosted gateway should use HTTPS and a client token.

## What is not magically solved by packaging source
### Online AI
The gateway is deployable, not already hosted. Create a service from this repository on a host supporting Docker, set `NOVA_AI_API_KEY` and `NOVA_AI_MODEL` as secret/environment variables, choose the correct `NOVA_API_MODE`, deploy, and copy the service URL. Copy the generated/selected `NOVA_CLIENT_TOKEN` from the host dashboard into NOVA Settings. Never commit `.env` or put provider keys in the app. API calls can cost money independently of any consumer chat subscription.

### Offline AI
The local fallback is a command/status fallback, not a generative model. This release does not ship model weights or a mobile inference runtime. Before adding one, select a runtime compatible with Android/Flutter, model quantization and licence, RAM/storage needs, thermal performance, and the phone's architecture. Until then the UI must not claim offline general reasoning.

### Floating character
The existing build workflow generates Android platform files and applies the Kotlin overlay bridge. That code is still a candidate implementation until GitHub Actions passes and the resulting APK is installed and checked on the target phone. Test permission grant/revoke, start/stop, app switching, image visibility, and Android battery restrictions. This package does not claim that the original visibility bug is verified fixed.

### God's Eye / screen understanding
The dashboard is not a screen-reading system. A genuine Android screen-understanding feature requires a transparent, user-started Android MediaProjection capture flow, the system consent prompt, foreground lifecycle/notification handling, frame redaction/processing, and a clear stop control. Camera access needs a separate explicit permission and visible active state. No covert capture is included in this package. Do not describe it as live screen/camera analysis until that flow exists and is tested.

### ECC
`EccCoordinator` is an allowlisted coordinator foundation. It must only call individually registered, typed app actions; no arbitrary shell/command execution. Consequential operations must request confirmation and every success must be verified. Do not label a plan as an executed action.

### Downloaded repositories
The supplied bundle had invalid/incomplete nested archives and multiple unrelated projects. They are not all Flutter libraries. This release does not claim that every repository is merged. Review source, licence, dependencies, and threat model before porting selected features. Do not ship APK analysis/security tooling as a default assistant feature.

## Validation steps
1. Commit the **contents of the `NOVA/` folder** to the repository root, not the ZIP file itself.
2. Run the `Build NOVA Android + Windows` GitHub Actions workflow.
3. If it fails, open the first Dart/Kotlin/Gradle error in the log; the final Gradle summary is usually not the root cause.
4. After a successful APK build, install it and test the overlay on the actual Android phone.
5. Deploy the gateway and use NOVA Settings to save the HTTPS base URL and client token, then use the backend test button.
6. Verify `/api/health` says `ai_configured: true` before testing general chat. If false, check host environment variables and redeploy.
7. Test privacy mode by sending a general question while it is on; the app must not call the online backend.

## Important
A green CI result verifies only the jobs and checks actually run. It does not prove every UI feature works on a physical device, does not provision an AI provider account, and does not install a local LLM.
