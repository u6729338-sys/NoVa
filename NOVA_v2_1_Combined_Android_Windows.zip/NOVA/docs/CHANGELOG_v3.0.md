# NOVA v3.0 — ECC integration + v2.6 foundation

## Combined
- Retains the v2.6 app foundation: persistent recent chat, editable notes, task priorities and due dates, JSON backup/restore, character selection, local memories, speech features where supported, offline utilities, privacy controls, optional backend chat, and Android/Windows build workflow.
- Adds ECC-inspired developer workflow guidance in `docs/DEVELOPMENT_TOOLKIT.md`.
- Adds a proposed permission-aware in-app agent architecture in `docs/NOVA_AGENT_ARCHITECTURE.md`.
- Adds a staged implementation roadmap and feature acceptance definition in `docs/IMPLEMENTATION_ROADMAP.md`.
- Adds a manual quality-check workflow to run focused tests and Flutter analysis on demand.
- Updates app package version to `3.0.0+30` and the initial greeting to NOVA v3.0.

## Important distinction
ECC is treated as a developer-side toolkit and set of workflow ideas, not as an app runtime library. No ECC source code, hooks, agents, or scripts are installed automatically. The in-app agent components in the architecture document are proposed future design unless separately implemented and tested.

## Not newly implemented in v3.0
A full offline generative model, wake-word listener, autonomous unrestricted computer control, document ingestion, scheduled OS notifications, cloud storage integration, animated avatars, speaker authentication, and multi-user account isolation are not completed by this documentation/tooling merge.

## Verification
ZIP structure was checked after packaging. Flutter tests, static analysis, Android build, and Windows build were not executed in this environment.
