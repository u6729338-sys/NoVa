# NOVA roadmap

The goal is a reliable personal agent that can combine high-quality AI models with local tools, memory, voice and approved automations. No honest engineering plan can guarantee that the finished app will outperform ChatGPT or Gemini on every general benchmark. We can measure whether NOVA completes the user's end-to-end personal workflows better and more reliably.

## Phase 1 — Foundation (this package)

- [x] Source-first Flutter project rather than a ZIP-only repository.
- [x] Deterministic local command parser with unit tests.
- [x] Device-local notes and tasks.
- [x] Speech input and spoken replies, where supported by the device.
- [x] Privacy mode blocks remote AI requests and TTS output.
- [x] Server-side AI gateway with configurable provider and model.
- [x] Provider credentials are not stored in the mobile/desktop app.
- [x] Android and Windows build workflows.
- [ ] Run the CI workflows on a connected GitHub repository and resolve any platform-specific build failures.

## Phase 2 — Better reasoning and research

- Provider registry with multiple providers and capability/cost routing.
- Research tool with fetch/search, citations, source dates and contradiction checks.
- File/document ingestion with explicit file access and a local searchable index.
- Separate short-term chat state from long-term memory; user-managed per-profile data.
- Evaluation suite for factual accuracy, tool completion, privacy leakage, latency and cost.

## Phase 3 — Action system

- Typed tool interface with allowlists and permission scopes.
- Preview and user confirmation before sending messages, changing files, making purchases or controlling devices.
- Task journal with status, artifacts, retries and clear failure handling.
- Android-supported integrations only; never promise unrestricted cross-app access.
- Windows desktop automation in a separately permissioned service.

## Phase 4 — Local AI and voice

- Optional local inference using a compatible runtime/model for each device's memory and compute budget.
- Offline speech-to-text and text-to-speech options with model download sizes shown before download.
- Wake word after foreground voice and privacy controls are dependable.
- Automatic offline/online routing with explicit status and no silent upload of private content.

## Phase 5 — NOVA Global View / camera tools

- Public geospatial data sources with labels, timestamps and terms-of-use review.
- User-added authorized NVR/camera connections (for example, a locally administered Frigate setup).
- No credential guessing, unauthenticated private-feed discovery, access-control bypass or global surveillance claim.
- Local event detection and summaries only for permitted feeds, plus access logs and a clear disconnect/delete function.

## Definition of done for each feature

A feature is done only when it has: working implementation, explicit permission model, user-facing status, failure handling, tests, setup documentation and verified behavior on Android and Windows. Screenshots or roadmap checkboxes alone do not count as implemented capability.
