# NOVA v2.5 — Offline Utility Expansion

## 20 new local command capabilities

1. Random number generator (optional minimum and maximum)
2. Coin flip
3. Six-sided dice roll
4. Celsius to Fahrenheit conversion
5. Fahrenheit to Celsius conversion
6. Kilometres to miles conversion
7. Miles to kilometres conversion
8. Kilograms to pounds conversion
9. Pounds to kilograms conversion
10. Centimetres to inches conversion
11. Inches to centimetres conversion
12. Percentage calculator (`percentage 20 of 150`)
13. Word counter
14. Character counter
15. Uppercase text transformation
16. Lowercase text transformation
17. Reverse text
18. Guided one-minute breathing exercise
19. Basic study-plan generator
20. Quick overview of saved notes

All commands above run locally and do not require the online AI backend. They do not add a generative offline AI model, always-on wake word, native alarms, or deep device control. Character personalities and existing notes/tasks/privacy/backend settings remain from v2.4.

## Verification status

Parser unit tests were expanded. This environment did not have Flutter/Dart installed, so an actual Flutter test run and Android/Windows build could not be verified here. GitHub Actions should be used to confirm compilation before installation.
