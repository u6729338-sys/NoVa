# NOVA architecture (v2.0 foundation)

## Current request path

1. The Flutter client receives typed or speech-recognized text.
2. `LocalIntentParser` handles deterministic local commands (time/date, notes, tasks, browser shortcuts, privacy toggle).
3. Unknown requests go to `NovaApiClient` only when a backend URL is configured and Privacy Mode is off.
4. `backend/app/main.py` validates input, optionally authenticates the client, adds the server-owned system prompt, and calls the configured AI provider.
5. The provider key remains in the backend environment and is never compiled into the Flutter client.

## Planned subsystems

- **NOVA Core:** intent parsing, routing, permissions, and observable task states.
- **NOVA Brain:** provider abstraction and task-based model routing. A model response is not itself proof an action was carried out.
- **NOVA Memory:** profile-scoped records, explicit retention, search and deletion controls. Sensitive data should be minimized.
- **NOVA Actions:** allowlisted tools with typed parameters, permission checks, confirmation for consequential actions, audit trail and undo where practical.
- **NOVA Voice:** wake-word detection, speech recognition and TTS; offline support must be tested on each target device.
- **NOVA Research:** web retrieval with citations and freshness checks; no fabricated tool results.
- **NOVA Global View:** public data sources plus cameras explicitly owned or authorized by the user. Use documented camera/NVR APIs, per-feed permissions and secure authentication.

## AI provider modes

The backend supports the OpenAI Responses API by default (`NOVA_API_MODE=responses`) and OpenAI-compatible Chat Completions endpoints (`NOVA_API_MODE=chat_completions`) for compatible providers and local servers. Provider URL, model, and key are configured in the server's `.env` file. The Flutter app stores only its optional client access token using platform secure storage.

## Platform boundaries

Android and Windows share the Flutter UI and intent layer, but actions are platform-specific. Android app control is constrained by app sandboxing and OS permissions. Windows automation requires explicit local integration and user-granted access. Camera access requires a reachable authenticated endpoint; no universal credential grants access to all cameras.
