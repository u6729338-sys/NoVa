# NOVA v2.4 — Character AI and full vision foundation

- Added selectable original companion personas: NOVA Orb, Aiko, Kairo, Mira and Rex.
- Persisted the selected companion on device.
- Added companion persona context to backend requests using an allowlisted ID; backend chooses the actual persona prompt.
- Added explicit local memory add/list/delete controls; at most 20 short memories are included in online chat requests.
- Clear-data flow now removes local memories as well as notes/tasks.
- Added `CHARACTER_AI_AND_FULL_VISION.md` to preserve the full product vision and accurately distinguish implemented foundation from planned platform-dependent features.
- Did not claim that wake word, offline generative model, document ingestion, OS notifications, animations/lip-sync, cloud storage or camera integrations are complete.

Version: 2.4.0+4
Verification: Python syntax checked; full Flutter Android/Windows builds are not verified in this environment.
