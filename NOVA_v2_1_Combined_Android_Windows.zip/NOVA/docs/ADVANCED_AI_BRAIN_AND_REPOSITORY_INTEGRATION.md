# NOVA v3.2 — AI Brain and Repository Integration Plan

## What this release adds to source
- `lib/core/nova_brain.dart`: provider-independent brain contract and honest local fallback. The fallback is **not** a local LLM.
- `lib/core/ecc_coordinator.dart`: allowlisted typed-tool coordinator with risk levels, explicit confirmation for consequential tools, and result verification.
- Version bumped to 3.2.0+32.
- Existing online AI gateway remains configurable via a backend URL and server-side provider credentials.

## Uploaded `Nova skills.zip` review
The archive contains nested downloads for ECC, a deepagents repository, OpenJarvis, a Jarvis Android app, redamonitor, APKLab, LangGraph, skills, and Superpowers. Some `.pending-*` entries are not valid ZIP archives, so those projects cannot be fully inspected or integrated from this bundle. The valid ECC, Jarvis-for-Android, APKLab, LangGraph, skills and Superpowers archives are independent projects with different languages, licenses, dependencies and execution assumptions; they are not Flutter plugins.

### Integration decisions
- **ECC / skills / Superpowers:** use as development process references (plan, implement, test, review, verify); do not copy their agent hooks wholesale into the mobile runtime.
- **LangGraph / deepagents / OpenJarvis:** candidate backend architecture research. These are not automatically embedded into Flutter; evaluate a separate server-side integration with a pinned version, dependency and deployment tests.
- **Jarvis for Android:** reference implementation only. It is a separate native Android/Kotlin app, not code that can safely be pasted into the Flutter project. Port features selectively after license and permission review.
- **APKLab / redamonitor:** security/research tooling, not a user-facing AI brain. Do not ship APK analysis or monitoring tooling inside NOVA as a default assistant feature.

## Current capability truth table
| Area | Status |
|---|---|
| Online model | Existing backend gateway can call a configured OpenAI-compatible provider; server secrets must be configured separately. |
| Offline AI | Local command fallback only. A real local LLM runtime and model weights are not bundled. |
| ECC | Safe typed coordinator is added as a reusable foundation; no automatic arbitrary device actions. UI/task integration remains follow-up work. |
| God Eye | Privacy/authorized-source dashboard only. No covert screen, camera, microphone or people monitoring. |
| Character | Static full-body image and existing overlay path; overlay visibility still requires Android build and device validation. |
| Android overlay | Native overlay implementation needs GitHub Actions build and real-device permission/lifecycle testing. |
| Windows overlay | Not implemented. |
| Memory | Existing local user-managed memory/preferences; not encrypted end-to-end and not cloud multi-profile isolation. |
| Reminders, wake word, document ingestion, full animation | Not fully implemented. |

## Required next validation
1. Upload the **contents inside `NOVA/`** to the repository root (not the ZIP itself).
2. Run GitHub Actions; resolve compiler and analyzer failures from the first real error, not from the final Gradle summary.
3. Test on Android: grant overlay permission, start/stop service, switch apps, rotate screen, reboot, revoke permission, and check character image path.
4. Configure the backend on a trusted host and store model API keys in host secrets/environment variables.
5. Add a local LLM only after selecting a model/runtime that fits device RAM, storage, licensing, latency and thermal limits. Do not bundle model weights until size/license/performance are checked.
6. Integrate ECC coordinator with individually reviewed tools; never expose arbitrary shell execution to chat.

## Security constraints
- No API keys in Flutter code or Git.
- God Eye only consumes explicitly authorized sources and clear user-granted permissions.
- Consequential actions require confirmation.
- Privacy mode must prevent online requests.
- Report success only after the integration confirms success.
