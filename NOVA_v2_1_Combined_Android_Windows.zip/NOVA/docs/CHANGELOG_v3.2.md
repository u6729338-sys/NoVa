# NOVA v3.2.0+32

- Added a provider-independent AI brain contract and honest local command fallback.
- Added ECC typed-tool coordination foundation with allowlisting, risk classification, confirmation gates, and verified outcomes.
- Reviewed uploaded repository bundle and documented compatible integration boundaries and incomplete nested downloads.
- Preserved existing configurable online backend, character/overlay and God Eye status dashboard.
- This is a source foundation, not a fully implemented offline LLM, full autonomous agent, live God Eye or verified floating overlay.
- Flutter/Android build has not been run in this environment; CI and real-device validation are required.
