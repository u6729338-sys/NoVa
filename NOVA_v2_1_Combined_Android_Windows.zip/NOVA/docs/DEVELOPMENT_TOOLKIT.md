# NOVA Development Toolkit (ECC-inspired)

## Goal
Make NOVA development more consistent by adopting the useful workflow concepts from ECC while keeping developer tooling separate from app runtime code.

## Suggested workflow for every feature
1. **Research**: inspect the current code and requirements before changing files.
2. **Plan**: identify affected modules, permissions, failure cases, and acceptance criteria.
3. **Implement**: make the smallest coherent change; avoid unrelated rewrites.
4. **Test**: run formatting, static analysis, unit tests, and platform-specific checks where available.
5. **Review**: inspect the diff for regressions, secrets, unsafe permissions, and duplicate functionality.
6. **Verify**: report what actually passed and what was not run.
7. **Document**: update the README and feature status honestly.

## Specialist review roles
These are workflow roles, not deployed agents:
- Planner: breaks a feature into small, testable steps.
- Flutter reviewer: checks Dart/Flutter conventions and state handling.
- Android reviewer: checks permissions, lifecycle, background restrictions, and battery impact.
- Windows reviewer: checks desktop paths, permissions, and platform-specific behaviour.
- Security reviewer: checks secrets, data isolation, permissions, and destructive actions.
- Test reviewer: checks acceptance criteria and missing test cases.

## Repository safety rules
- Never commit API keys, passwords, tokens, private user data, or local configuration secrets.
- Use environment variables or a secure backend for secrets; do not embed privileged API keys in the mobile app.
- Do not add scripts or hooks from a third-party toolkit without reading and understanding them.
- Do not let an AI agent execute arbitrary shell commands or destructive file operations without guardrails.
- Use a separate branch and pull request for feature changes.
- Keep a record of tests actually run; never claim tests passed if they were not run.
- Pin third-party tool versions when practical and review updates before adopting them.

## ECC usage
Treat the official ECC repository as a developer-side optional toolkit. Follow its current README for supported installation paths. Do not install multiple overlapping methods into the same coding-agent environment.
