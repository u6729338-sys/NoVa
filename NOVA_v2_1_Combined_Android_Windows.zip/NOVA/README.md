# NOVA v3.0 — Personal Assistant Foundation (Android + Windows)

NOVA is an early-stage Flutter personal assistant project. Version 3.0 combines the v2.6 productivity foundation with the NOVA × ECC integration pack: development workflow guidance, a proposed permission-aware agent architecture, and a staged roadmap.

## Existing app capabilities carried forward
- Character selection for five original personas (NOVA Orb, Aiko, Kairo, Mira, Rex).
- Optional online AI backend configuration; provider credentials belong on the trusted backend, not inside the app.
- Speech input/output where supported.
- Local notes, task list, task priorities, and optional due dates.
- Persistent recent chat history (last 200 messages) in app preferences.
- User-managed local memories.
- Local utility commands and confirmed web/service shortcuts.
- Privacy-mode controls.
- JSON backup/restore via clipboard.
- Android and Windows build workflows.

## ECC integration: what it means
The included ECC-inspired pack is a **developer workflow and architecture guide**, not a Flutter runtime dependency. It adds a repeatable research → plan → implement → test → review → verify → document workflow, specialist review checklists, security rules, an agent architecture proposal, and a staged implementation roadmap. It does not copy or install third-party ECC hooks or scripts into the app.

Read:
- `docs/DEVELOPMENT_TOOLKIT.md`
- `docs/NOVA_AGENT_ARCHITECTURE.md`
- `docs/IMPLEMENTATION_ROADMAP.md`
- `docs/ECC_INTEGRATION_README.md`
- `docs/CHANGELOG_v3.0.md`

## Build
Upload the **contents inside `NOVA/`** to the root of your GitHub repository, preserving folders. Run `.github/workflows/build.yml` for Android APK and Windows artifacts. A separate manual workflow, `.github/workflows/flutter-ci.yml`, runs focused tests and static analysis when manually triggered.

## Honest feature status
This is not yet a fully autonomous JARVIS assistant. Offline command parsing is limited to supported intents; there is no bundled offline generative model, always-on wake word, general-purpose device control, full document-ingestion pipeline, real scheduled reminders, or finished avatar animation. Task due dates are currently displayed rather than generating notifications. Voice input is not authentication. Backup data contains personal information and must be stored securely.

## Security principles
- Keep API keys and provider secrets out of app binaries and Git.
- Use allowlisted, typed tools rather than unrestricted shell commands.
- Require confirmation for consequential actions.
- Keep memory and files user-controlled and separable by profile.
- Honour privacy settings before sending content to an online model.
- Report actions as successful only when the underlying operation confirms success.

## Version
App version: `3.0.0+30`. This version bump and documentation merge have not been verified by a Flutter build in this environment; run GitHub Actions before installing.
