# NOVA v2.1 — Combined Android + Windows project

This is the combined project made from `NOVA_v2_0_Core.zip` and `NOVA_Build_Fix_Android_Windows.zip`.

## What was combined
- Preserved the fuller v2.0 app and backend source.
- Integrated the Android/Windows GitHub Actions build-fix approach into one workflow at `.github/workflows/build.yml`.
- The workflow creates missing native platform folders, configures Android permissions/minimum SDK, runs Flutter tests, and attempts Android APK and Windows release builds.

The older `lib/main.dart` and reduced `pubspec.yaml` from the build-fix package were intentionally not copied over, because that would discard newer v2.0 features and the secure backend client.

## How to use it
1. Keep your old ZIPs as backups.
2. Extract this ZIP. Upload the **contents inside the extracted `NOVA` folder** to the root of your `NoVa` GitHub repository, preserving folder structure. Do not upload just the ZIP as a repository file.
3. Commit the files, then open the repository's **Actions** tab.
4. Open **Build NOVA Android + Windows** and inspect the run.
5. If successful, download `NOVA-Android-APK` from the Android job and `NOVA-Windows-Release` from the Windows job. Windows releases must be built on a Windows runner.

## Honest status
The combined ZIP has not been compiled with Flutter in this environment and GitHub Actions has not yet verified it. A successful upload is not proof of a successful build. Check the Actions result before treating it as working software.

NOVA is still an early foundation, not a finished JARVIS. Offline local AI, an always-on wake word, broad device control, and real camera/global-view integrations are not implemented yet. See `docs/MERGE_NOTES.md` and `docs/ROADMAP.md`.
