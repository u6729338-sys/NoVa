from __future__ import annotations

import hmac
import os
from pathlib import Path
from typing import Literal

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv(Path(__file__).resolve().parents[1] / ".env")

SYSTEM_PROMPT = """You are NOVA, a practical personal assistant. Be clear, capable, and honest.
Never claim you performed an action unless a connected tool actually performed and verified it.
When facts may be current or uncertain, say what needs verification. Ask for confirmation before
external side effects such as sending messages, spending money, changing security settings, or
controlling devices. Do not pretend to have access to the user's phone, files, cameras, accounts,
or live web data unless a specific authorized integration supplies that access. Keep personal data
minimal and never request passwords or provider API keys in chat."""

app = FastAPI(title="NOVA AI Gateway", version="0.1.0")
_origins = [item.strip() for item in os.getenv("NOVA_ALLOWED_ORIGINS", "http://localhost,http://127.0.0.1").split(",") if item.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=16)
    companion_id: Literal["orb", "aiko", "kairo", "mira", "rex"] = "orb"
    memories: list[str] = Field(default_factory=list, max_length=20)



def _required_token(authorization: str | None) -> None:
    expected = os.getenv("NOVA_CLIENT_TOKEN", "").strip()
    if expected:
        supplied = ""
        if authorization and authorization.lower().startswith("bearer "):
            supplied = authorization[7:].strip()
        if not supplied or not hmac.compare_digest(supplied, expected):
            raise HTTPException(status_code=401, detail="Invalid client token")


def _provider_config() -> tuple[str, str, str, str]:
    base_url = os.getenv("NOVA_AI_BASE_URL", "https://api.openai.com/v1").strip().rstrip("/")
    api_key = os.getenv("NOVA_AI_API_KEY", "").strip()
    model = os.getenv("NOVA_AI_MODEL", "").strip()
    mode = os.getenv("NOVA_API_MODE", "responses").strip().lower()
    return base_url, api_key, model, mode


def extract_response_text(mode: str, payload: dict) -> str:
    """Extract assistant text from Responses or OpenAI-compatible chat format."""
    direct = payload.get("output_text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()

    if mode == "chat_completions":
        choices = payload.get("choices")
        if isinstance(choices, list) and choices:
            message = choices[0].get("message", {})
            content = message.get("content", "") if isinstance(message, dict) else ""
            if isinstance(content, str):
                return content.strip()
            if isinstance(content, list):
                parts = [item.get("text", "") for item in content if isinstance(item, dict)]
                return "".join(part for part in parts if isinstance(part, str)).strip()
        return ""

    output = payload.get("output", [])
    collected: list[str] = []
    if isinstance(output, list):
        for item in output:
            if not isinstance(item, dict) or item.get("type") != "message":
                continue
            content = item.get("content", [])
            if not isinstance(content, list):
                continue
            for part in content:
                if isinstance(part, dict) and part.get("type") in {"output_text", "text"}:
                    value = part.get("text", "")
                    if isinstance(value, str):
                        collected.append(value)
    return "\n".join(piece for piece in collected if piece.strip()).strip()


@app.get("/api/health")
async def health(authorization: str | None = Header(default=None)) -> dict[str, object]:
    _required_token(authorization)
    _, api_key, model, mode = _provider_config()
    return {
        "status": "ok",
        "ai_configured": bool(api_key and model),
        "api_mode": mode,
    }


@app.post("/api/chat")
async def chat(
    request: ChatRequest,
    authorization: str | None = Header(default=None),
) -> dict[str, str]:
    _required_token(authorization)
    base_url, api_key, model, mode = _provider_config()
    if not api_key or not model:
        raise HTTPException(status_code=503, detail="AI provider is not configured")
    if mode not in {"responses", "chat_completions"}:
        raise HTTPException(status_code=500, detail="Unsupported NOVA_API_MODE")

    companion_prompts = {
        "orb": "You are NOVA, a clear, capable personal assistant. Be practical, honest about limitations, and concise.",
        "aiko": "You are Aiko, an original anime-inspired companion: curious, upbeat, observant and supportive. Keep the conversation respectful and useful. Never pretend to be a real human.",
        "kairo": "You are Kairo, an original anime-inspired strategist: calm, analytical, direct and good at breaking problems into steps. Be respectful and never overclaim.",
        "mira": "You are Mira, an original anime-inspired creative companion: imaginative, expressive and thoughtful. Help with ideas and learning while being honest and respectful.",
        "rex": "You are Rex, an original sci-fi companion: concise, candid, mission-focused and safety-conscious. Prioritize actionable steps and flag risks.",
    }
    memory_context = ""
    safe_memories = [item.strip()[:500] for item in request.memories if item.strip()][:20]
    if safe_memories:
        memory_context = "\nUser-approved remembered context (treat as potentially outdated; do not reveal unnecessarily):\n" + "\n".join(f"- {item}" for item in safe_memories)
    messages: list[dict[str, str]] = [{"role": "system", "content": SYSTEM_PROMPT + "\n\nSelected companion style: " + companion_prompts[request.companion_id] + memory_context}]
    messages.extend({"role": item.role, "content": item.content} for item in request.messages)
    if not any(item["role"] == "user" for item in messages):
        raise HTTPException(status_code=422, detail="At least one user message is required")

    if mode == "responses":
        endpoint = f"{base_url}/responses"
        body: dict[str, object] = {"model": model, "input": messages}
    else:
        endpoint = f"{base_url}/chat/completions"
        body = {"model": model, "messages": messages, "temperature": 0.35}

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(65.0, connect=10.0)) as client:
            response = await client.post(
                endpoint,
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json=body,
            )
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail="AI provider timed out") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail="Could not contact AI provider") from exc

    if response.status_code == 401 or response.status_code == 403:
        raise HTTPException(status_code=502, detail="Provider authentication failed; verify server-side configuration")
    if response.status_code == 429:
        raise HTTPException(status_code=429, detail="AI provider rate limit reached")
    if response.status_code >= 500:
        raise HTTPException(status_code=502, detail="AI provider returned a server error")
    if response.status_code < 200 or response.status_code >= 300:
        # Do not echo raw provider responses because they can include internal request details.
        raise HTTPException(status_code=502, detail=f"AI provider rejected the request (HTTP {response.status_code})")

    try:
        payload = response.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail="AI provider returned invalid JSON") from exc
    answer = extract_response_text(mode, payload)
    if not answer:
        raise HTTPException(status_code=502, detail="AI provider returned no text response")
    return {"reply": answer}
