# NOVA AI gateway

This small service keeps provider credentials off the Flutter app and offers two endpoints:

- `GET /api/health` — reports whether the provider is configured, without exposing secrets.
- `POST /api/chat` — accepts recent user/assistant turns and returns `{ "reply": "..." }`.

## Run locally

Python 3.11 or newer is recommended.

**Windows PowerShell** (from the repository root):

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
uvicorn app.main:app --host 127.0.0.1 --port 8765
```

**Linux/macOS:**

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
$EDITOR .env
uvicorn app.main:app --host 127.0.0.1 --port 8765
```

Set `NOVA_AI_API_KEY` and `NOVA_AI_MODEL` in `backend/.env`; default API mode is `responses`. For compatible services that use Chat Completions, set `NOVA_API_MODE=chat_completions` and configure `NOVA_AI_BASE_URL` to that provider's documented base URL. The model name and API key must be valid for the provider you select.

For local development, `NOVA_CLIENT_TOKEN` may be blank while the server binds only to `127.0.0.1`. If exposing the service over a private network, set a long random `NOVA_CLIENT_TOKEN`, use HTTPS through a trusted reverse proxy/VPN, restrict ingress, and enter the matching token in NOVA Settings. Do not port-forward this service directly to the internet.

Each request to a hosted model may incur separate API charges. The ChatGPT consumer subscription and API billing are separate products. The app itself does not include free provider usage.
