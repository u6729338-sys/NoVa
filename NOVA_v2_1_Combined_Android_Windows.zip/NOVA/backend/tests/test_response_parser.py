from app.main import extract_response_text


def test_responses_api_output_text_field():
    assert extract_response_text("responses", {"output_text": " hello "}) == "hello"


def test_responses_api_nested_output():
    payload = {
        "output": [
            {"type": "reasoning", "content": []},
            {"type": "message", "content": [{"type": "output_text", "text": "NOVA answer"}]},
        ]
    }
    assert extract_response_text("responses", payload) == "NOVA answer"


def test_chat_completions_string_content():
    payload = {"choices": [{"message": {"content": "Hello"}}]}
    assert extract_response_text("chat_completions", payload) == "Hello"


def test_chat_completions_content_blocks():
    payload = {"choices": [{"message": {"content": [{"type": "text", "text": "one"}, {"type": "text", "text": " two"}]}}]}
    assert extract_response_text("chat_completions", payload) == "one two"


def test_missing_output_is_empty():
    assert extract_response_text("responses", {}) == ""
