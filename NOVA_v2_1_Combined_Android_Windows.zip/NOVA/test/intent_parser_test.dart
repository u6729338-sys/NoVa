import 'package:flutter_test/flutter_test.dart';
import 'package:nova/core/intent_parser.dart';

void main() {
  group('LocalIntentParser', () {
    test('recognizes commands without case sensitivity', () {
      expect(LocalIntentParser.parse('HELP').type, NovaIntentType.help);
      expect(LocalIntentParser.parse('TIME NOW').type, NovaIntentType.time);
      expect(LocalIntentParser.parse('OPEN MAPS').type, NovaIntentType.openMaps);
    });

    test('preserves note and task text', () {
      expect(LocalIntentParser.parse('add note Call the bank').argument, 'Call the bank');
      expect(LocalIntentParser.parse('add task Finish chapter 3').argument, 'Finish chapter 3');
    });

    test('preserves web query text', () {
      final intent = LocalIntentParser.parse('search web for Goa economics syllabus');
      expect(intent.type, NovaIntentType.searchWeb);
      expect(intent.argument, 'Goa economics syllabus');
    });

    test('distinguishes opening Google from searching Google', () {
      expect(LocalIntentParser.parse('open Google').type, NovaIntentType.openGoogle);
      expect(LocalIntentParser.parse('google Goa weather').argument, 'Goa weather');
    });

    test('unknown messages are delegated rather than falsely handled locally', () {
      expect(LocalIntentParser.parse('Explain quantum computing simply').type, NovaIntentType.none);
    });

    test('privacy commands can explicitly enable or disable privacy', () {
      expect(LocalIntentParser.parse('enable privacy').argument, 'on');
      expect(LocalIntentParser.parse('disable privacy').argument, 'off');
    });
  });
}
