import 'package:flutter_test/flutter_test.dart';
import 'package:nova/core/intent_parser.dart';

void main() {
  group('LocalIntentParser', () {
    test('recognizes commands without case sensitivity', () {
      expect(LocalIntentParser.parse('HELP').type, NovaIntentType.help);
      expect(LocalIntentParser.parse('TIME NOW').type, NovaIntentType.time);
      expect(LocalIntentParser.parse('OPEN MAPS').type, NovaIntentType.openMaps);
    });

    test('preserves note and task text', () {
      expect(LocalIntentParser.parse('add note Call the bank').argument, 'Call the bank');
      expect(LocalIntentParser.parse('add task Finish chapter 3').argument, 'Finish chapter 3');
    });

    test('preserves web query text', () {
      final intent = LocalIntentParser.parse('search web for Goa economics syllabus');
      expect(intent.type, NovaIntentType.searchWeb);
      expect(intent.argument, 'Goa economics syllabus');
    });

    test('distinguishes opening Google from searching Google', () {
      expect(LocalIntentParser.parse('open Google').type, NovaIntentType.openGoogle);
      expect(LocalIntentParser.parse('google Goa weather').argument, 'Goa weather');
    });


    test('recognizes v2.3 shortcuts and utility commands', () {
      expect(LocalIntentParser.parse('open Gmail').type, NovaIntentType.openGmail);
      expect(LocalIntentParser.parse('open Calendar').type, NovaIntentType.openCalendar);
      expect(LocalIntentParser.parse('open Drive').type, NovaIntentType.openDrive);
      expect(LocalIntentParser.parse('open Translate').type, NovaIntentType.openTranslate);
      expect(LocalIntentParser.parse('open Spotify').type, NovaIntentType.openSpotify);
      expect(LocalIntentParser.parse('open WhatsApp').type, NovaIntentType.openWhatsApp);
      expect(LocalIntentParser.parse('open ChatGPT').type, NovaIntentType.openChatGPT);
      expect(LocalIntentParser.parse('open GitHub').type, NovaIntentType.openGitHub);
      expect(LocalIntentParser.parse('open News').type, NovaIntentType.openNews);
      expect(LocalIntentParser.parse('calculate 12 * 4').argument, '12 * 4');
      expect(LocalIntentParser.parse('count tasks').type, NovaIntentType.countTasks);
      expect(LocalIntentParser.parse('clear chat').type, NovaIntentType.clearChat);
      expect(LocalIntentParser.parse('search notes for class').argument, 'class');
      expect(LocalIntentParser.parse('shop for shoes').argument, 'shoes');
    });

    test('recognizes v2.5 offline utility commands', () {
      expect(LocalIntentParser.parse('flip a coin').type, NovaIntentType.coinFlip);
      expect(LocalIntentParser.parse('roll dice').type, NovaIntentType.rollDice);
      expect(LocalIntentParser.parse('random number 4 9').argument, '4 9');
      expect(LocalIntentParser.parse('c to f 25').argument, '25');
      expect(LocalIntentParser.parse('f to c 77').argument, '77');
      expect(LocalIntentParser.parse('km to miles 5').argument, '5');
      expect(LocalIntentParser.parse('percentage 20 of 150').argument, '20 of 150');
      expect(LocalIntentParser.parse('count words hello there').argument, 'hello there');
      expect(LocalIntentParser.parse('uppercase nova').argument, 'nova');
      expect(LocalIntentParser.parse('breathing exercise').type, NovaIntentType.breathingExercise);
      expect(LocalIntentParser.parse('study plan').type, NovaIntentType.studyPlan);
      expect(LocalIntentParser.parse('summarize my notes').type, NovaIntentType.summarizeNotes);
    });

    test('handles blank input and weather location', () {
      expect(LocalIntentParser.parse('   ').type, NovaIntentType.none);
      final weather = LocalIntentParser.parse('weather in Panaji');
      expect(weather.type, NovaIntentType.weather);
      expect(weather.argument, 'Panaji');
    });

    test('unknown messages are delegated rather than falsely handled locally', () {
      expect(LocalIntentParser.parse('Explain quantum computing simply').type, NovaIntentType.none);
    });

    test('privacy commands can explicitly enable or disable privacy', () {
      expect(LocalIntentParser.parse('enable privacy').argument, 'on');
      expect(LocalIntentParser.parse('disable privacy').argument, 'off');
    });
  });
}
