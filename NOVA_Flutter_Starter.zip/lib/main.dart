import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const NovaApp());

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NOVA',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: const Color(0xFF090D16),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF58C7FF), brightness: Brightness.dark),
    ),
    home: const NovaHome(),
  );
}

class ChatMessage {
  ChatMessage(this.text, this.fromNova);
  final String text;
  final bool fromNova;
}

class NovaHome extends StatefulWidget {
  const NovaHome({super.key});
  @override
  State<NovaHome> createState() => _NovaHomeState();
}

class _NovaHomeState extends State<NovaHome> {
  final _input = TextEditingController();
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  final List<ChatMessage> _messages = [
    ChatMessage('Hello, I’m NOVA. How can I help you?', true),
  ];
  bool _listening = false;

  @override
  void dispose() {
    _input.dispose();
    _tts.stop();
    super.dispose();
  }

  Future<void> _speak(String text) async {
    await _tts.setLanguage('en-IN');
    await _tts.setSpeechRate(0.48);
    await _tts.speak(text);
  }

  Future<void> _listen() async {
    if (_listening) {
      await _speech.stop();
      setState(() => _listening = false);
      return;
    }
    final available = await _speech.initialize(
      onStatus: (status) { if (status == 'done' || status == 'notListening') { if (mounted) setState(() => _listening = false); } },
      onError: (_) { if (mounted) setState(() => _listening = false); },
    );
    if (!available) {
      _reply('Voice recognition is not available. Please check microphone permission and your phone’s speech service.');
      return;
    }
    setState(() => _listening = true);
    await _speech.listen(
      localeId: 'en_IN',
      onResult: (result) {
        _input.text = result.recognizedWords;
        if (result.finalResult) {
          final text = result.recognizedWords.trim();
          setState(() => _listening = false);
          if (text.isNotEmpty) _send(text);
        }
      },
    );
  }

  void _reply(String text) {
    setState(() => _messages.add(ChatMessage(text, true)));
    _speak(text);
  }

  String _answer(String input) {
    final q = input.toLowerCase();
    if (q.contains('time')) {
      final now = DateTime.now();
      final h = now.hour % 12 == 0 ? 12 : now.hour % 12;
      final m = now.minute.toString().padLeft(2, '0');
      return 'It is $h:$m ${now.hour >= 12 ? 'PM' : 'AM'}.';
    }
    if (q.contains('date') || q.contains('today')) {
      final n = DateTime.now();
      return 'Today is ${n.day}/${n.month}/${n.year}.';
    }
    if (q.contains('hello') || q.contains('hi nova') || q == 'hi') {
      return 'Hello! I’m here. What would you like to do?';
    }
    if (q.contains('who are you')) {
      return 'I’m NOVA, your personal assistant. This starter version supports voice input, spoken replies, and a few basic commands.';
    }
    if (q.contains('help')) {
      return 'Try asking me the time, today’s date, or say hello. Online AI and device actions can be added in later versions.';
    }
    return 'I heard: “$input”. I’m currently a starter version, so I can answer basic commands only. More features can be connected in future versions.';
  }

  void _send([String? spoken]) {
    final text = (spoken ?? _input.text).trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add(ChatMessage(text, false));
      _input.clear();
    });
    _reply(_answer(text));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: const Color(0xFF0D1422),
      title: const Row(children: [
        Icon(Icons.auto_awesome, color: Color(0xFF58C7FF)),
        SizedBox(width: 10),
        Text('NOVA', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
      ]),
      actions: [IconButton(tooltip: 'About NOVA', onPressed: () => showAboutDialog(context: context, applicationName: 'NOVA', applicationVersion: '1.0.0', children: const [Text('A voice-enabled personal assistant starter app.')]), icon: const Icon(Icons.info_outline))],
    ),
    body: SafeArea(
      child: Column(children: [
        Container(
          margin: const EdgeInsets.fromLTRB(16, 18, 16, 12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF142D47), Color(0xFF101827)]),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFF2C6384)),
          ),
          child: const Row(children: [
            CircleAvatar(radius: 27, backgroundColor: Color(0xFF153A54), child: Icon(Icons.graphic_eq, size: 30, color: Color(0xFF58C7FF))),
            SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Your assistant', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text('Voice input • Spoken replies • Basic commands', style: TextStyle(fontSize: 12, color: Colors.white70)),
            ])),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: _messages.length,
            itemBuilder: (context, i) {
              final m = _messages[i];
              return Align(
                alignment: m.fromNova ? Alignment.centerLeft : Alignment.centerRight,
                child: Container(
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .82),
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                  decoration: BoxDecoration(
                    color: m.fromNova ? const Color(0xFF172538) : const Color(0xFF164B67),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: m.fromNova ? const Color(0xFF263D55) : const Color(0xFF23789D)),
                  ),
                  child: Text(m.text, style: const TextStyle(fontSize: 15, height: 1.35)),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Row(children: [
            IconButton.filled(
              onPressed: _listen,
              style: IconButton.styleFrom(backgroundColor: _listening ? Colors.redAccent : const Color(0xFF164B67), foregroundColor: Colors.white),
              icon: Icon(_listening ? Icons.stop : Icons.mic),
              tooltip: _listening ? 'Stop listening' : 'Speak',
            ),
            const SizedBox(width: 8),
            Expanded(child: TextField(
              controller: _input,
              onSubmitted: (_) => _send(),
              textInputAction: TextInputAction.send,
              decoration: InputDecoration(
                hintText: 'Message NOVA…',
                filled: true,
                fillColor: const Color(0xFF111A29),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
              ),
            )),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _send, icon: const Icon(Icons.arrow_upward), tooltip: 'Send'),
          ]),
        ),
      ]),
    ),
  );
}
