import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

import 'core/intent_parser.dart';
import 'services/nova_api_client.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NovaApp());
}

const novaCyan = Color(0xFF58C7FF);
const novaBackground = Color(0xFF090D16);
const _secureStorage = FlutterSecureStorage();
const MethodChannel _overlayChannel = MethodChannel('nova/overlay');

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NOVA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: novaBackground,
          colorScheme: ColorScheme.fromSeed(
            seedColor: novaCyan,
            brightness: Brightness.dark,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF0D1422),
            foregroundColor: Colors.white,
          ),
        ),
        home: const NovaHome(),
      );
}

class NovaCompanion {
  const NovaCompanion({required this.id, required this.name, required this.tagline, required this.emoji, required this.color, required this.personality, required this.voiceStyle});
  final String id, name, tagline, emoji, personality, voiceStyle;
  final Color color;
}

const novaCompanions = <NovaCompanion>[
  NovaCompanion(id: 'orb', name: 'NOVA Orb', tagline: 'Focused AI assistant', emoji: '🔮', color: Color(0xFF58C7FF), personality: 'You are NOVA, a clear, capable personal assistant. Be practical, honest about limitations, and concise.', voiceStyle: 'neutral'),
  NovaCompanion(id: 'aiko', name: 'Aiko', tagline: 'Curious anime-inspired companion', emoji: '🌸', color: Color(0xFFFF91C8), personality: 'You are Aiko, an original anime-inspired companion: curious, upbeat, observant and supportive. Keep the conversation respectful and useful. Never pretend to be a real human.', voiceStyle: 'bright'),
  NovaCompanion(id: 'kairo', name: 'Kairo', tagline: 'Calm strategist', emoji: '⚡', color: Color(0xFFFFC857), personality: 'You are Kairo, an original anime-inspired strategist: calm, analytical, direct and good at breaking problems into steps. Be respectful and never overclaim.', voiceStyle: 'calm'),
  NovaCompanion(id: 'mira', name: 'Mira', tagline: 'Creative storyteller', emoji: '🌙', color: Color(0xFFB6A0FF), personality: 'You are Mira, an original anime-inspired creative companion: imaginative, expressive and thoughtful. Help with ideas and learning while being honest and respectful.', voiceStyle: 'expressive'),
  NovaCompanion(id: 'rex', name: 'Rex', tagline: 'Direct mission partner', emoji: '🛡️', color: Color(0xFF70E0B5), personality: 'You are Rex, an original sci-fi companion: concise, candid, mission-focused and safety-conscious. Prioritize actionable steps and flag risks.', voiceStyle: 'firm'),
];

class NovaMessage {
  const NovaMessage({required this.text, required this.fromNova, required this.time});
  final String text;
  final bool fromNova;
  final DateTime time;

  Map<String, String> toApiMap() => <String, String>{
        'role': fromNova ? 'assistant' : 'user',
        'content': text,
      };
}

class NovaHome extends StatefulWidget {
  const NovaHome({super.key});

  @override
  State<NovaHome> createState() => _NovaHomeState();
}

class _NovaHomeState extends State<NovaHome> {
  final _input = TextEditingController();
  final _noteInput = TextEditingController();
  final _taskInput = TextEditingController();
  final _backendInput = TextEditingController();
  final _tokenInput = TextEditingController();
  final _memoryInput = TextEditingController();
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  final _scroll = ScrollController();
  final _api = NovaApiClient();

  final List<NovaMessage> _messages = <NovaMessage>[
    NovaMessage(
      text: 'Hello, I’m NOVA v3.4. I can manage local notes and tasks, use character personalities, perform offline utilities and conversions, and connect to an online AI gateway when configured. Say “help” to see commands.',
      fromNova: true,
      time: DateTime.now(),
    ),
  ];
  final List<String> _notes = <String>[];
  final List<Map<String, dynamic>> _tasks = <Map<String, dynamic>>[];
  final List<String> _memories = <String>[];
  String _selectedCompanionId = 'orb';
  String _activeProfile = 'Me';

  String _backendUrl = '';
  String _clientToken = '';
  String _status = 'LOCAL READY';
  int _tab = 0;
  bool _listening = false;
  bool _thinking = false;
  bool _voiceInputEnabled = true;
  bool _voiceReplies = true;
  bool _privateMode = false;
  bool _savingConnection = false;
  bool _overlayEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadSaved();
    _configureSpeechOutput();
  }

  @override
  void dispose() {
    _input.dispose();
    _noteInput.dispose();
    _taskInput.dispose();
    _backendInput.dispose();
    _tokenInput.dispose();
    _memoryInput.dispose();
    _scroll.dispose();
    _tts.stop();
    _api.close();
    super.dispose();
  }

  Future<void> _toggleFloatingCompanion() async {
    if (!mounted) return;
    try {
      final granted = await _overlayChannel.invokeMethod<bool>('isOverlayPermissionGranted') ?? false;
      if (!granted) {
        await _overlayChannel.invokeMethod<void>('requestOverlayPermission');
        if (mounted) _showSnack('Allow “Display over other apps” for NOVA, then tap Floating Character again.');
        return;
      }
      if (_overlayEnabled) {
        await _overlayChannel.invokeMethod<void>('stopOverlay');
        if (mounted) setState(() => _overlayEnabled = false);
        _showSnack('Floating character stopped.');
      } else {
        await _overlayChannel.invokeMethod<void>('startOverlay', <String, String>{'name': _companion.name, 'emoji': _companion.emoji});
        if (mounted) setState(() => _overlayEnabled = true);
        _showSnack('Floating character started. Drag it to move; tap it to return to NOVA.');
      }
    } on PlatformException catch (e) {
      _showSnack('Floating character unavailable: ${e.message ?? 'platform error'}');
    } on MissingPluginException {
      _showSnack('Floating overlay is available on Android only. Windows always-on-top mode is not implemented yet.');
    }
  }

  Future<void> _configureSpeechOutput() async {
    try {
      await _tts.setLanguage('en-IN');
      await _tts.setSpeechRate(0.47);
    } catch (_) {}
  }

  Future<void> _loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final token = await _secureStorage.read(key: 'nova_backend_client_token');
    if (!mounted) return;
    setState(() {
      _notes.addAll(prefs.getStringList('nova_notes_v2') ?? <String>[]);
      final rawMessages = prefs.getString('nova_chat_history_v1');
      if (rawMessages != null) {
        try {
          final decoded = jsonDecode(rawMessages) as List<dynamic>;
          _messages
            ..clear()
            ..addAll(decoded.map((item) {
              final map = Map<String, dynamic>.from(item as Map);
              return NovaMessage(
                text: map['text'] as String? ?? '',
                fromNova: map['fromNova'] == true,
                time: DateTime.tryParse(map['time'] as String? ?? '') ?? DateTime.now(),
              );
            }));
        } catch (_) { /* Ignore invalid legacy chat data. */ }
      }
      _memories.addAll(prefs.getStringList('nova_memories_v1') ?? <String>[]);
      _selectedCompanionId = prefs.getString('nova_companion_id') ?? 'orb';
      _activeProfile = prefs.getString('nova_profile_name') ?? 'Me';
      final rawTasks = prefs.getString('nova_tasks_v2');
      if (rawTasks != null) {
        try {
          final decoded = jsonDecode(rawTasks) as List<dynamic>;
          _tasks.addAll(decoded.map((e) => Map<String, dynamic>.from(e as Map)));
        } catch (_) {
          // Ignore damaged older task state; it must not prevent startup.
        }
      }
      _backendUrl = prefs.getString('nova_backend_url') ?? '';
      _clientToken = token ?? '';
      _backendInput.text = _backendUrl;
      _tokenInput.text = _clientToken;
      _voiceReplies = prefs.getBool('nova_voice_replies') ?? true;
      _voiceInputEnabled = prefs.getBool('nova_voice_input_enabled') ?? true;
      _privateMode = prefs.getBool('nova_private_mode') ?? false;
      _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
    });
  }

  Future<void> _saveChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final recent = _messages.length > 200 ? _messages.sublist(_messages.length - 200) : _messages;
    await prefs.setString('nova_chat_history_v1', jsonEncode(recent.map((m) => <String, dynamic>{
      'text': m.text, 'fromNova': m.fromNova, 'time': m.time.toIso8601String(),
    }).toList()));
  }

  Future<void> _saveNotes() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('nova_notes_v2', _notes);
  }

  Future<void> _saveMemories() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('nova_memories_v1', _memories);
  }

  Future<void> _saveCompanion() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('nova_companion_id', _selectedCompanionId);
  }

  NovaCompanion get _companion => novaCompanions.firstWhere(
        (item) => item.id == _selectedCompanionId,
        orElse: () => novaCompanions.first,
      );

  Future<void> _chooseCompanion() async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF101827),
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            const Text('Choose your NOVA companion', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Original companion concepts. Personality affects online AI instructions; voices and advanced animations are still device-dependent and not fully implemented.'),
            const SizedBox(height: 12),
            ...novaCompanions.map((item) => Card(
              child: ListTile(
                leading: CircleAvatar(backgroundColor: item.color.withOpacity(.18), child: Text(item.emoji, style: const TextStyle(fontSize: 23))),
                title: Text(item.name),
                subtitle: Text(item.tagline),
                trailing: item.id == _selectedCompanionId ? const Icon(Icons.check_circle, color: novaCyan) : null,
                onTap: () => Navigator.pop(context, item.id),
              ),
            )),
          ],
        ),
      ),
    );
    if (chosen == null || !mounted) return;
    setState(() => _selectedCompanionId = chosen);
    await _saveCompanion();
    _reply('Companion changed to ${_companion.name}. ${_companion.tagline}.');
  }

  Future<void> _addMemory() async {
    final value = _memoryInput.text.trim();
    if (value.isEmpty) return;
    setState(() { if (!_memories.contains(value)) _memories.add(value); _memoryInput.clear(); });
    await _saveMemories();
    if (mounted) _showSnack('Memory saved on this device.');
  }

  Future<void> _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('nova_tasks_v2', jsonEncode(_tasks));
  }

  Future<void> _saveVoiceSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('nova_voice_replies', _voiceReplies);
    await prefs.setBool('nova_voice_input_enabled', _voiceInputEnabled);
    await prefs.setBool('nova_private_mode', _privateMode);
  }

  Future<void> _speak(String text) async {
    if (!_voiceReplies || _privateMode) return;
    try {
      await _tts.speak(text);
    } catch (_) {
      // Some desktop and Android installations do not have a working TTS voice.
    }
  }

  void _reply(String text) {
    if (!mounted) return;
    setState(() {
      _messages.add(NovaMessage(text: text, fromNova: true, time: DateTime.now()));
      _thinking = false;
      _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
    });
    _jumpToBottom();
    _saveChatHistory();
    _speak(text);
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _listen() async {
    if (!_voiceInputEnabled) {
      _reply('Voice input is disabled. Turn it on in Settings to use the microphone.');
      return;
    }
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() { _listening = false; _status = _privateMode ? 'PRIVATE' : 'LOCAL READY'; });
      return;
    }

    bool available;
    try {
      available = await _speech.initialize(
        onStatus: (value) {
          if ((value == 'done' || value == 'notListening') && mounted) {
            setState(() {
              _listening = false;
              if (!_thinking) _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
            });
          }
        },
        onError: (_) {
          if (mounted) setState(() { _listening = false; _status = 'VOICE ERROR'; });
        },
      );
    } catch (_) {
      available = false;
    }

    if (!available) {
      _reply('Speech recognition is unavailable. Check microphone permission and the speech service on this device. Speech recognition may use your operating system’s own service.');
      return;
    }
    if (mounted) setState(() { _listening = true; _status = 'LISTENING'; });
    try {
      await _speech.listen(
        localeId: 'en_IN',
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 3),
        onResult: (result) {
          _input.text = result.recognizedWords;
          if (result.finalResult) {
            final recognized = result.recognizedWords.trim();
            if (mounted) setState(() { _listening = false; });
            if (recognized.isNotEmpty) _sendText(recognized);
          }
        },
      );
    } catch (_) {
      if (mounted) setState(() { _listening = false; _status = 'VOICE ERROR'; });
    }
  }

  void _send() => _sendText(_input.text);

  Future<void> _sendText(String value) async {
    final text = value.trim();
    if (text.isEmpty || _thinking) return;
    setState(() {
      _messages.add(NovaMessage(text: text, fromNova: false, time: DateTime.now()));
      _input.clear();
      _thinking = true;
      _status = _privateMode ? 'PRIVATE' : 'THINKING';
    });
    _jumpToBottom();
    await _saveChatHistory();
    await _process(text);
  }

  Future<void> _process(String text) async {
    final intent = LocalIntentParser.parse(text);
    if (intent.type != NovaIntentType.none) {
      await _runLocalIntent(intent);
      return;
    }

    if (_privateMode) {
      _reply('Privacy mode is on. I did not send this message to online AI. Turn privacy mode off to use your configured backend.');
      return;
    }
    if (_backendUrl.trim().isEmpty) {
      _reply('This request needs an AI brain that is not configured yet. Local notes, tasks, time/date, and browser shortcuts work now. In Settings, connect a NOVA backend. Provider API keys belong on the backend—not inside this app.');
      return;
    }

    final history = _messages
        .where((message) => message.text.trim().isNotEmpty)
        .toList(growable: false);
    final apiMessages = history.length > 16 ? history.sublist(history.length - 16) : history;

    try {
      final answer = await _api.chat(
        baseUrl: _backendUrl,
        clientToken: _clientToken,
        messages: apiMessages.map((message) => message.toApiMap()).toList(),
        companionId: _companion.id,
        memories: _memories,
      );
      _reply(answer);
    } on NovaApiException catch (error) {
      _reply(error.message);
    } catch (_) {
      _reply('The online AI request failed. Check your backend and provider settings. Local commands remain available.');
    }
  }

  Future<void> _runLocalIntent(NovaIntent intent) async {
    switch (intent.type) {
      case NovaIntentType.help:
        _reply('Commands: notes/tasks, time/date, calculate 12 * 4, random number 1 100, flip a coin, roll dice, c to f 25, f to c 77, km to miles 5, miles to km 3, kg to pounds 10, pounds to kg 22, cm to inches 30, inches to cm 12, percentage 20 of 150, count words hello there, count characters hello, uppercase hello, lowercase HELLO, reverse text hello, breathing exercise, study plan, summarize my notes, web search, weather, privacy mode, and confirmed website shortcuts.');
        return;
      case NovaIntentType.time:
        final now = DateTime.now();
        final hour = now.hour % 12 == 0 ? 12 : now.hour % 12;
        final minute = now.minute.toString().padLeft(2, '0');
        _reply('It is $hour:$minute ${now.hour >= 12 ? 'PM' : 'AM'}.');
        return;
      case NovaIntentType.date:
        final now = DateTime.now();
        const days = <String>['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        _reply('Today is ${days[now.weekday - 1]}, ${now.day}/${now.month}/${now.year}.');
        return;
      case NovaIntentType.addNote:
        if (intent.argument.isEmpty) {
          _reply('Tell me what note to save. You can say “add note buy groceries”.');
          return;
        }
        setState(() => _notes.add(intent.argument));
        await _saveNotes();
        _reply('Saved your note on this device.');
        return;
      case NovaIntentType.showNotes:
        _reply(_notes.isEmpty
            ? 'You have no saved notes yet. Say “add note” followed by your note.'
            : 'Your saved notes: ${_notes.asMap().entries.map((entry) => '${entry.key + 1}. ${entry.value}').join('. ')}');
        return;
      case NovaIntentType.addTask:
        if (intent.argument.isEmpty) {
          _reply('Tell me what task to add. You can say “add task finish my assignment”.');
          return;
        }
        setState(() => _tasks.add(<String, dynamic>{'text': intent.argument, 'done': false, 'priority': 'Medium', 'dueDate': null}));
        await _saveTasks();
        _reply('Task added. You can mark it complete in the Tasks tab.');
        return;
      case NovaIntentType.showTasks:
        final pending = _tasks.where((task) => task['done'] != true).toList();
        _reply(pending.isEmpty
            ? 'No pending tasks. Say “add task” followed by a task.'
            : 'Pending tasks: ${pending.asMap().entries.map((entry) => '${entry.key + 1}. ${entry.value['text']}').join('. ')}');
        return;
      case NovaIntentType.searchWeb:
        if (intent.argument.isEmpty) {
          _reply('Tell me what you want to search for.');
          return;
        }
        await _openUrlConfirmed(
          Uri.https('www.google.com', '/search', <String, String>{'q': intent.argument}),
          'search for: ${intent.argument}',
        );
        return;
      case NovaIntentType.weather:
        final place = intent.argument.trim();
        final query = place.isEmpty ? 'weather today' : 'weather in $place';
        await _openUrlConfirmed(
          Uri.https('www.google.com', '/search', <String, String>{'q': query}),
          query,
        );
        return;
      case NovaIntentType.togglePrivacy:
        final turnOn = intent.argument == 'on' ? true : intent.argument == 'off' ? false : !_privateMode;
        await _setPrivateMode(turnOn);
        _reply(_privateMode
            ? 'Privacy mode is on. Online AI requests and spoken replies are blocked.'
            : 'Privacy mode is off. Online AI is available when your backend is configured.');
        return;
      case NovaIntentType.openGoogle:
        await _openUrlConfirmed(Uri.https('www.google.com', '/'), 'Google');
        return;
      case NovaIntentType.openYouTube:
        await _openUrlConfirmed(Uri.https('www.youtube.com', '/'), 'YouTube');
        return;
      case NovaIntentType.openMaps:
        await _openUrlConfirmed(Uri.https('maps.google.com', '/'), 'Google Maps');
        return;
      case NovaIntentType.openGmail:
        await _openUrlConfirmed(Uri.https('mail.google.com', '/'), 'Gmail');
        return;
      case NovaIntentType.openCalendar:
        await _openUrlConfirmed(Uri.https('calendar.google.com', '/'), 'Google Calendar');
        return;
      case NovaIntentType.openDrive:
        await _openUrlConfirmed(Uri.https('drive.google.com', '/'), 'Google Drive');
        return;
      case NovaIntentType.openTranslate:
        await _openUrlConfirmed(Uri.https('translate.google.com', '/'), 'Google Translate');
        return;
      case NovaIntentType.openSpotify:
        await _openUrlConfirmed(Uri.https('open.spotify.com', '/'), 'Spotify');
        return;
      case NovaIntentType.openWhatsApp:
        await _openUrlConfirmed(Uri.https('web.whatsapp.com', '/'), 'WhatsApp Web');
        return;
      case NovaIntentType.openChatGPT:
        await _openUrlConfirmed(Uri.https('chatgpt.com', '/'), 'ChatGPT');
        return;
      case NovaIntentType.openGitHub:
        await _openUrlConfirmed(Uri.https('github.com', '/'), 'GitHub');
        return;
      case NovaIntentType.openNews:
        await _openUrlConfirmed(Uri.https('news.google.com', '/'), 'Google News');
        return;
      case NovaIntentType.searchShopping:
        final query = intent.argument.isEmpty ? 'online shopping' : intent.argument;
        await _openUrlConfirmed(Uri.https('www.google.com', '/search', <String, String>{'q': '$query shopping'}), 'shopping search for $query');
        return;
      case NovaIntentType.calculate:
        final result = _calculateSimple(intent.argument);
        _reply(result ?? 'I can calculate simple expressions like “calculate 12 * 4”. Use +, -, *, or / with two numbers.');
        return;
      case NovaIntentType.countTasks:
        final pending = _tasks.where((task) => task['done'] != true).length;
        _reply('You have $pending pending task${pending == 1 ? '' : 's'} and ${_tasks.length - pending} completed task${_tasks.length - pending == 1 ? '' : 's'}.');
        return;
      case NovaIntentType.clearChat:
        setState(() {
          _messages.clear();
          _messages.add(NovaMessage(text: 'Chat cleared on this device. Saved notes and tasks were not deleted.', fromNova: true, time: DateTime.now()));
          _thinking = false;
          _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
        });
        await (SharedPreferences.getInstance()).then((prefs) => prefs.remove('nova_chat_history_v1'));
        _jumpToBottom();
        _speak('Chat cleared. Notes and tasks are unchanged.');
        return;
      case NovaIntentType.searchNotes:
        final query = intent.argument.toLowerCase();
        final matches = _notes.where((note) => note.toLowerCase().contains(query)).toList();
        _reply(matches.isEmpty ? 'No saved notes matched “${intent.argument}”.' : 'Matching notes: ${matches.asMap().entries.map((e) => '${e.key + 1}. ${e.value}').join('. ')}');
        return;
      case NovaIntentType.randomNumber:
        final parts = intent.argument.split(RegExp(r'\s+'));
        final min = parts.isNotEmpty ? int.tryParse(parts[0]) ?? 1 : 1;
        final max = parts.length > 1 ? int.tryParse(parts[1]) ?? 100 : 100;
        if (max < min) { _reply('Use a maximum that is greater than or equal to the minimum.'); return; }
        _reply('Random number: ${min + math.Random.secure().nextInt(max - min + 1)}');
        return;
      case NovaIntentType.coinFlip:
        _reply(math.Random.secure().nextBool() ? 'Heads.' : 'Tails.');
        return;
      case NovaIntentType.rollDice:
        _reply('You rolled ${math.Random.secure().nextInt(6) + 1}.');
        return;
      case NovaIntentType.celsiusToFahrenheit:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “c to f 25”.' : '${n.toStringAsFixed(1)}°C = ${(n * 9 / 5 + 32).toStringAsFixed(1)}°F.'); return;
      case NovaIntentType.fahrenheitToCelsius:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “f to c 77”.' : '${n.toStringAsFixed(1)}°F = ${((n - 32) * 5 / 9).toStringAsFixed(1)}°C.'); return;
      case NovaIntentType.kmToMiles:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “km to miles 5”.' : '$n km = ${(n * 0.621371).toStringAsFixed(2)} miles.'); return;
      case NovaIntentType.milesToKm:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “miles to km 3”.' : '$n miles = ${(n * 1.60934).toStringAsFixed(2)} km.'); return;
      case NovaIntentType.kgToPounds:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “kg to pounds 10”.' : '$n kg = ${(n * 2.20462).toStringAsFixed(2)} lb.'); return;
      case NovaIntentType.poundsToKg:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “pounds to kg 22”.' : '$n lb = ${(n / 2.20462).toStringAsFixed(2)} kg.'); return;
      case NovaIntentType.cmToInches:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “cm to inches 30”.' : '$n cm = ${(n / 2.54).toStringAsFixed(2)} inches.'); return;
      case NovaIntentType.inchesToCm:
        final n = double.tryParse(intent.argument); _reply(n == null ? 'Try “inches to cm 12”.' : '$n inches = ${(n * 2.54).toStringAsFixed(2)} cm.'); return;
      case NovaIntentType.percentage:
        final match = RegExp(r'^(-?\d+(?:\.\d+)?)\s+of\s+(-?\d+(?:\.\d+)?)$', caseSensitive: false).firstMatch(intent.argument);
        if (match == null) { _reply('Try “percentage 20 of 150”.'); return; }
        final percent = double.parse(match.group(1)!); final total = double.parse(match.group(2)!);
        _reply('$percent% of $total = ${(percent * total / 100).toStringAsFixed(2)}.'); return;
      case NovaIntentType.countWords:
        final words = intent.argument.trim().isEmpty ? 0 : intent.argument.trim().split(RegExp(r'\s+')).length;
        _reply('Word count: $words.'); return;
      case NovaIntentType.countCharacters:
        _reply('Character count: ${intent.argument.length}.'); return;
      case NovaIntentType.uppercaseText:
        _reply(intent.argument.toUpperCase()); return;
      case NovaIntentType.lowercaseText:
        _reply(intent.argument.toLowerCase()); return;
      case NovaIntentType.reverseText:
        _reply(String.fromCharCodes(intent.argument.runes.toList().reversed)); return;
      case NovaIntentType.breathingExercise:
        _reply('Try this gentle breathing reset: breathe in comfortably for 4 seconds, breathe out slowly for 6 seconds, and repeat for one minute. Stop if you feel uncomfortable.'); return;
      case NovaIntentType.studyPlan:
        _reply('Quick study plan: 1) Pick one topic. 2) Study for 25 minutes. 3) Take a 5-minute break. 4) Write 5 key points from memory. 5) Test yourself with 5 questions. Repeat if useful.'); return;
      case NovaIntentType.summarizeNotes:
        if (_notes.isEmpty) { _reply('No notes saved yet. Add notes first.'); } else { _reply('Your notes at a glance: ${_notes.take(12).join(' • ')}${_notes.length > 12 ? ' • …' : ''}'); } return;
      case NovaIntentType.none:
        return;
    }
  }

  String? _calculateSimple(String expression) {
    // Intentionally supports only two numeric operands and one operator.
    final match = RegExp(r'^\s*(-?\d+(?:\.\d+)?)\s*([+\-*/x])\s*(-?\d+(?:\.\d+)?)\s*$').firstMatch(expression);
    if (match == null) return null;
    final a = double.tryParse(match.group(1)!);
    final op = match.group(2)!;
    final b = double.tryParse(match.group(3)!);
    if (a == null || b == null || ((op == '/' ) && b == 0)) return 'That calculation is not valid (division by zero is not allowed).';
    final double result;
    switch (op) {
      case '+': result = a + b; break;
      case '-': result = a - b; break;
      case '*': case 'x': result = a * b; break;
      case '/': result = a / b; break;
      default: return null;
    }
    final value = result.isFinite ? (result == result.roundToDouble() ? result.toInt().toString() : result.toString()) : 'not finite';
    return '$expression = $value';
  }

  Future<void> _openUrlConfirmed(Uri uri, String description) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Open external website?'),
        content: Text('NOVA wants to open your browser to $description.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Open')),
        ],
      ),
    );
    if (!mounted) return;
    if (approved != true) {
      _reply('Cancelled.');
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      _reply(opened ? 'Opening $description.' : 'I could not open that website.');
    } catch (_) {
      _reply('I could not open that website.');
    }
  }

  Future<void> _setPrivateMode(bool enabled) async {
    if (!mounted) return;
    setState(() {
      _privateMode = enabled;
      if (enabled) _status = 'PRIVATE';
    });
    if (enabled) await _tts.stop();
    await _saveVoiceSettings();
  }

  Future<void> _saveConnection() async {
    if (_savingConnection) return;
    final url = _backendInput.text.trim().replaceFirst(RegExp(r'/+$'), '');
    if (url.isNotEmpty && Uri.tryParse(url) == null) {
      _showSnack('That backend URL is not valid.');
      return;
    }
    setState(() => _savingConnection = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('nova_backend_url', url);
      await _secureStorage.write(key: 'nova_backend_client_token', value: _tokenInput.text.trim());
      if (!mounted) return;
      setState(() {
        _backendUrl = url;
        _clientToken = _tokenInput.text.trim();
        _status = _privateMode ? 'PRIVATE' : (_backendUrl.isEmpty ? 'LOCAL READY' : 'AI CONFIGURED');
      });
      _showSnack(url.isEmpty ? 'Backend disconnected. Local features still work.' : 'Backend connection settings saved.');
    } catch (_) {
      _showSnack('Could not securely save your connection settings.');
    } finally {
      if (mounted) setState(() => _savingConnection = false);
    }
  }

  Future<void> _testConnection() async {
    final url = _backendInput.text.trim();
    final token = _tokenInput.text.trim();
    if (url.isEmpty) {
      _showSnack('Enter your backend URL first.');
      return;
    }
    _showSnack('Testing NOVA backend…');
    try {
      final health = await _api.health(baseUrl: url, clientToken: token);
      final ready = health['ai_configured'] == true;
      _showSnack(ready
          ? 'Backend reachable; AI provider configured.'
          : 'Backend reachable, but the AI provider is not configured yet.');
    } on NovaApiException catch (error) {
      _showSnack(error.message);
    } catch (_) {
      _showSnack('Connection test failed. Verify the URL and server.');
    }
  }

  void _showSnack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _editNote(int index) async {
    final controller = TextEditingController(text: _notes[index]);
    final edited = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Edit note'),
        content: TextField(controller: controller, autofocus: true, minLines: 2, maxLines: 6, decoration: const InputDecoration(border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    controller.dispose();
    if (edited == null || edited.isEmpty) return;
    setState(() => _notes[index] = edited);
    await _saveNotes();
  }

  Future<void> _createBackup() async {
    final backup = <String, dynamic>{
      'format': 'nova-backup-v1',
      'createdAt': DateTime.now().toIso8601String(),
      'notes': _notes,
      'tasks': _tasks,
      'memories': _memories,
      'chatHistory': _messages.map((m) => {'text': m.text, 'fromNova': m.fromNova, 'time': m.time.toIso8601String()}).toList(),
      'companionId': _selectedCompanionId,
      'profileName': _activeProfile,
      'voiceReplies': _voiceReplies,
      'voiceInputEnabled': _voiceInputEnabled,
      'privateMode': _privateMode,
    };
    await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(backup)));
    if (mounted) _showSnack('Backup JSON copied to clipboard. Paste it into a file and keep it somewhere safe.');
  }

  Future<void> _restoreBackup() async {
    final controller = TextEditingController();
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Restore NOVA backup'),
        content: SizedBox(width: 500, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Paste a NOVA backup JSON. Restoring replaces current notes, tasks, memories, and chat history.'),
          const SizedBox(height: 12),
          TextField(controller: controller, minLines: 5, maxLines: 10, decoration: const InputDecoration(hintText: 'Paste backup JSON here', border: OutlineInputBorder())),
        ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Restore')),
        ],
      ),
    );
    if (approved != true) { controller.dispose(); return; }
    try {
      final decoded = jsonDecode(controller.text) as Map<String, dynamic>;
      if (decoded['format'] != 'nova-backup-v1') throw const FormatException('Unsupported backup format');
      final restoredNotes = (decoded['notes'] as List<dynamic>? ?? []).map((e) => e.toString()).toList();
      final restoredTasks = (decoded['tasks'] as List<dynamic>? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      final restoredMemories = (decoded['memories'] as List<dynamic>? ?? []).map((e) => e.toString()).toList();
      final restoredMessages = (decoded['chatHistory'] as List<dynamic>? ?? []).map((e) {
        final map = Map<String, dynamic>.from(e as Map);
        return NovaMessage(text: map['text'] as String? ?? '', fromNova: map['fromNova'] == true, time: DateTime.tryParse(map['time'] as String? ?? '') ?? DateTime.now());
      }).toList();
      setState(() {
        _notes..clear()..addAll(restoredNotes);
        _tasks..clear()..addAll(restoredTasks);
        _memories..clear()..addAll(restoredMemories);
        _messages..clear()..addAll(restoredMessages);
        _selectedCompanionId = decoded['companionId'] as String? ?? 'orb';
        _activeProfile = decoded['profileName'] as String? ?? 'Me';
      });
      final prefs = await SharedPreferences.getInstance();
      await _saveNotes(); await _saveTasks(); await _saveMemories(); await _saveChatHistory(); await _saveCompanion();
      await prefs.setString('nova_profile_name', _activeProfile);
      controller.dispose();
      if (mounted) _showSnack('Backup restored successfully.');
    } catch (_) {
      controller.dispose();
      if (mounted) _showSnack('Restore failed: this is not a valid NOVA backup JSON. Current data was not changed.');
    }
  }

  Future<void> _addTaskWithDetails() async {
    final titleController = TextEditingController(text: _taskInput.text.trim());
    String priority = 'Medium';
    DateTime? dueDate;
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
        title: const Text('New task'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleController, autofocus: true, decoration: const InputDecoration(labelText: 'Task', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Priority'), items: const [DropdownMenuItem(value: 'Low', child: Text('Low')), DropdownMenuItem(value: 'Medium', child: Text('Medium')), DropdownMenuItem(value: 'High', child: Text('High'))], onChanged: (v) => setDialogState(() => priority = v ?? 'Medium')),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: () async { final picked = await showDatePicker(context: context, initialDate: dueDate ?? DateTime.now(), firstDate: DateTime.now().subtract(const Duration(days: 365)), lastDate: DateTime.now().add(const Duration(days: 3650))); if (picked != null) setDialogState(() => dueDate = picked); }, icon: const Icon(Icons.event), label: Text(dueDate == null ? 'Add due date (optional)' : 'Due ${dueDate!.day}/${dueDate!.month}/${dueDate!.year}')),
          if (dueDate != null) TextButton(onPressed: () => setDialogState(() => dueDate = null), child: const Text('Remove due date')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(dialogContext, {'text': titleController.text.trim(), 'priority': priority, 'dueDate': dueDate?.toIso8601String()}), child: const Text('Add task'))],
      )),
    );
    titleController.dispose();
    if (result == null || (result['text'] as String).isEmpty) return;
    setState(() { _tasks.add({'text': result['text'], 'done': false, 'priority': result['priority'], 'dueDate': result['dueDate']}); _taskInput.clear(); });
    await _saveTasks();
  }

  Future<void> _addNoteFromField() async {
    final text = _noteInput.text.trim();
    if (text.isEmpty) return;
    setState(() { _notes.add(text); _noteInput.clear(); });
    await _saveNotes();
  }

  Future<void> _addTaskFromField() async {
    final text = _taskInput.text.trim();
    if (text.isEmpty) return;
    setState(() { _tasks.add(<String, dynamic>{'text': text, 'done': false, 'priority': 'Medium', 'dueDate': null}); _taskInput.clear(); });
    await _saveTasks();
  }

  String _formatDueDate(dynamic value) { final date = DateTime.tryParse(value.toString()); return date == null ? value.toString() : '${date.day}/${date.month}/${date.year}'; }

  String get _modeLabel => _privateMode
      ? 'PRIVATE'
      : (_thinking ? 'THINKING' : (_backendUrl.isEmpty ? 'LOCAL MODE' : 'AI BACKEND SET'));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Row(
            children: <Widget>[
              Icon(Icons.auto_awesome, color: novaCyan),
              SizedBox(width: 10),
              Text('NOVA', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
            ],
          ),
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: Center(child: Text(_status, style: const TextStyle(fontSize: 10, color: novaCyan))),
            ),
          ],
        ),
        body: IndexedStack(
          index: _tab,
          children: <Widget>[_chatPage(), _notesPage(), _tasksPage(), _systemsPage(), _globalViewPage(), _settingsPage()],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (index) => setState(() => _tab = index),
          destinations: const <NavigationDestination>[
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat), label: 'Chat'),
            NavigationDestination(icon: Icon(Icons.note_alt_outlined), selectedIcon: Icon(Icons.note_alt), label: 'Notes'),
            NavigationDestination(icon: Icon(Icons.check_circle_outline), selectedIcon: Icon(Icons.check_circle), label: 'Tasks'),
            NavigationDestination(icon: Icon(Icons.memory), selectedIcon: Icon(Icons.memory), label: 'Systems'),
            NavigationDestination(icon: Icon(Icons.public), selectedIcon: Icon(Icons.public), label: 'God Eye'),
            NavigationDestination(icon: Icon(Icons.tune), selectedIcon: Icon(Icons.tune), label: 'Settings'),
          ],
        ),
      );

  Widget _chatPage() => SafeArea(
        child: Column(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.fromLTRB(14, 12, 14, 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: <Color>[Color(0xFF142D47), Color(0xFF101827)]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF2C6384)),
              ),
              child: Row(
                children: <Widget>[
                  const CircleAvatar(backgroundColor: Color(0xFF153A54), child: Icon(Icons.graphic_eq, color: novaCyan)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                      const Text('Personal assistant', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 3),
                      Text('$_modeLabel • Local notes • Tasks', style: const TextStyle(fontSize: 11, color: Colors.white70)),
                    ]),
                  ),
                  IconButton(onPressed: () => _reply('Say “help” for supported local commands. Configure a private backend in Settings for general AI chat.'), icon: const Icon(Icons.help_outline)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: _chooseCompanion,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                  decoration: BoxDecoration(color: const Color(0xFF111A29), borderRadius: BorderRadius.circular(14), border: Border.all(color: _companion.color.withOpacity(.65))),
                  child: Row(children: <Widget>[
                    CircleAvatar(radius: 18, backgroundColor: _companion.color.withOpacity(.15), child: Text(_companion.emoji)),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                      Text(_companion.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(_companion.tagline, style: const TextStyle(fontSize: 11, color: Colors.white70)),
                    ])),
                    const Icon(Icons.expand_more),
                  ]),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                itemCount: _messages.length + (_thinking ? 1 : 0),
                itemBuilder: (context, index) {
                  if (_thinking && index == _messages.length) {
                    return const Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(padding: EdgeInsets.all(12), child: Text('NOVA is working…', style: TextStyle(color: novaCyan))),
                    );
                  }
                  final message = _messages[index];
                  return Align(
                    alignment: message.fromNova ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .84),
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                      decoration: BoxDecoration(
                        color: message.fromNova ? const Color(0xFF172538) : const Color(0xFF164B67),
                        borderRadius: BorderRadius.circular(17),
                        border: Border.all(color: message.fromNova ? const Color(0xFF263D55) : const Color(0xFF23789D)),
                      ),
                      child: Text(message.text, style: const TextStyle(fontSize: 14, height: 1.38)),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
              child: Row(
                children: <Widget>[
                  IconButton.filled(
                    onPressed: _listen,
                    style: IconButton.styleFrom(backgroundColor: _listening ? Colors.redAccent : const Color(0xFF164B67)),
                    icon: Icon(_listening ? Icons.stop : (_voiceInputEnabled ? Icons.mic : Icons.mic_off)),
                    tooltip: _voiceInputEnabled ? 'Voice input' : 'Voice input disabled',
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      onSubmitted: (_) => _send(),
                      textInputAction: TextInputAction.send,
                      minLines: 1,
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: 'Message NOVA…',
                        filled: true,
                        fillColor: const Color(0xFF111A29),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(onPressed: _thinking ? null : _send, icon: const Icon(Icons.arrow_upward), tooltip: 'Send'),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _notesPage() => SafeArea(
        child: Column(
          children: <Widget>[
            const ListTile(
              title: Text('Your notes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Stored locally on this device'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _noteInput,
                    decoration: const InputDecoration(hintText: 'Write a note…', border: OutlineInputBorder()),
                    onSubmitted: (_) => _addNoteFromField(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _addNoteFromField, icon: const Icon(Icons.add)),
              ]),
            ),
            Expanded(
              child: _notes.isEmpty
                  ? const Center(child: Text('No notes yet.'))
                  : ListView.builder(
                      itemCount: _notes.length,
                      itemBuilder: (context, index) => ListTile(
                        leading: const Icon(Icons.sticky_note_2_outlined, color: novaCyan),
                        title: Text(_notes[index]),
                        trailing: Wrap(children: [
                          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'Edit note', onPressed: () => _editNote(index)),
                          IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'Delete note', onPressed: () async { setState(() => _notes.removeAt(index)); await _saveNotes(); }),
                        ]),
                      ),
                    ),
            ),
          ],
        ),
      );

  Widget _tasksPage() => SafeArea(
        child: Column(
          children: <Widget>[
            const ListTile(
              title: Text('Tasks', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Add a task, then tick it off when complete'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _taskInput,
                    decoration: const InputDecoration(hintText: 'New task…', border: OutlineInputBorder()),
                    onSubmitted: (_) => _addTaskFromField(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _addTaskWithDetails, icon: const Icon(Icons.add)),
              ]),
            ),
            Expanded(
              child: _tasks.isEmpty
                  ? const Center(child: Text('No tasks yet.'))
                  : ListView.builder(
                      itemCount: _tasks.length,
                      itemBuilder: (context, index) {
                        final task = _tasks[index];
                        final done = task['done'] == true;
                        return CheckboxListTile(
                          value: done,
                          title: Text(
                            '${task['text']}',
                            style: TextStyle(decoration: done ? TextDecoration.lineThrough : null),
                          ),
                          subtitle: Text([if ((task['priority'] ?? 'Medium').toString().isNotEmpty) 'Priority: ${task['priority'] ?? 'Medium'}', if (task['dueDate'] != null) 'Due: ${_formatDueDate(task['dueDate'])}'].join(' • ')),
                          onChanged: (value) async {
                            setState(() => task['done'] = value ?? false);
                            await _saveTasks();
                          },
                          secondary: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async { setState(() => _tasks.removeAt(index)); await _saveTasks(); },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      );

  Widget _systemsPage() => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            const Text('NOVA Advanced Systems', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            const Text('Character, God Eye awareness, and ECC task coordination. Live integrations are clearly marked.', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 14),
            Card(
              color: const Color(0xFF111A29),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Row(children: <Widget>[
                    Container(width: 112, height: 190, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: const Color(0xFF0A101B), border: Border.all(color: _companion.color)),
                      child: _companion.id == 'orb'
                        ? Image.asset('assets/characters/nova_full_body.png', fit: BoxFit.cover, alignment: Alignment.topCenter)
                        : Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                            Text(_companion.emoji, style: const TextStyle(fontSize: 36)),
                            Icon(Icons.accessibility_new, size: 72, color: _companion.color),
                            Text(_companion.name, textAlign: TextAlign.center, style: TextStyle(color: _companion.color, fontWeight: FontWeight.bold, fontSize: 12)),
                          ])),
                    const SizedBox(width: 14),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                      const Text('Full-body companion preview', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                      const SizedBox(height: 7),
                      Text(_companion.tagline, style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 9),
                      const Text('NOVA uses a full-body concept illustration; alternate personas currently use stylized icons. 3D animation and lip-sync are not included.', style: TextStyle(fontSize: 11, color: Colors.white54)),
                      const SizedBox(height: 9),
                      OutlinedButton.icon(onPressed: _chooseCompanion, icon: const Icon(Icons.person_search), label: const Text('Change character')),
                    ])),
                  ]),
                  const SizedBox(height: 12),
                  SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _toggleFloatingCompanion, icon: Icon(_overlayEnabled ? Icons.stop_circle_outlined : Icons.picture_in_picture_alt), label: Text(_overlayEnabled ? 'Stop floating character' : 'Show over other apps (Android)'))),
                  const SizedBox(height: 5),
                  const Text('Android asks you to grant “Display over other apps”. The floating mini-character is draggable and returns to NOVA when tapped. This is a basic overlay, not a full-screen screen-reading agent.', style: TextStyle(fontSize: 11, color: Colors.white54)),
                ]),
              ),
            ),
            _featureCard(icon: Icons.remove_red_eye_outlined, title: 'GOD EYE • Privacy-controlled awareness', body: 'Current build: system dashboard and safe integration boundary. It does not secretly monitor the screen, scan cameras, track people, or connect to feeds. Screen capture, live camera analysis, public-source ingestion, and device telemetry connectors are not implemented yet.'),
            const SizedBox(height: 10),
            _featureCard(icon: Icons.psychology_outlined, title: 'ECC • Enhanced Coordination Core', body: 'ECC workflow: understand request → plan → check permissions → ask for confirmation when needed → execute an allowlisted tool → verify result → log outcome. This release documents the workflow and exposes system status; autonomous multi-tool execution is not fully implemented.'),
            const SizedBox(height: 10),
            _featureCard(icon: Icons.shield_outlined, title: 'Safety and permissions', body: 'No arbitrary shell execution, hidden surveillance, or unconfirmed consequential actions. Future connectors must be explicitly enabled, permission-limited, and report success only after confirmation.'),
          ],
        ),
      );

  Widget _globalViewPage() => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            const Text('GOD EYE • Authorized Data View', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Privacy-controlled view for sources you choose and are authorized to access. No hidden surveillance.'),
            const SizedBox(height: 18),
            _featureCard(
              icon: Icons.public,
              title: 'Public information sources',
              body: 'Not connected in this build. A future connector can show selected public data with source labels and timestamps.',
            ),
            const SizedBox(height: 12),
            _featureCard(
              icon: Icons.videocam_outlined,
              title: 'Authorized camera connections',
              body: 'No cameras are scanned or connected by this build. The planned CCTV connector will use your own NVR/camera credentials and explicit permissions.',
            ),
            const SizedBox(height: 12),
            _featureCard(
              icon: Icons.verified_user_outlined,
              title: 'Privacy and audit trail',
              body: 'Camera access must be authenticated, limited to permitted feeds, and logged. NOVA will not bypass passwords or search for private camera streams.',
            ),
          ],
        ),
      );

  Widget _featureCard({required IconData icon, required String title, required String body}) => Card(
        color: const Color(0xFF111A29),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Icon(icon, color: novaCyan, size: 28),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 6),
              Text(body, style: const TextStyle(height: 1.4, color: Colors.white70)),
            ])),
          ]),
        ),
      );

  Widget _settingsPage() => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            const Text('Settings & privacy', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.mic, color: novaCyan),
              title: const Text('Voice input'),
              subtitle: const Text('Use the device speech recognition service'),
              value: _voiceInputEnabled,
              onChanged: (enabled) async {
                if (!enabled && _listening) await _speech.stop();
                setState(() { _voiceInputEnabled = enabled; _listening = false; });
                await _saveVoiceSettings();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.volume_up, color: novaCyan),
              title: const Text('Spoken replies'),
              subtitle: const Text('Speak NOVA responses aloud'),
              value: _voiceReplies,
              onChanged: (enabled) async {
                setState(() => _voiceReplies = enabled);
                if (!enabled) await _tts.stop();
                await _saveVoiceSettings();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.shield_outlined, color: novaCyan),
              title: const Text('Privacy mode'),
              subtitle: const Text('Blocks online AI requests and spoken replies'),
              value: _privateMode,
              onChanged: _setPrivateMode,
            ),
            const Divider(height: 30),
            const Text('Connect an AI backend', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'NOVA sends chat to your own backend. Keep provider API keys on the server, never in the Android app or GitHub.',
              style: TextStyle(color: Colors.white70, height: 1.35),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _backendInput,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'Backend URL',
                hintText: 'https://your-private-server.example',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.cloud_outlined),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _tokenInput,
              obscureText: true,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'NOVA backend client token (optional for local-only use)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.key_outlined),
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'This is the token for your NOVA server—not your OpenAI/Gemini provider API key. Remote servers should use HTTPS.',
              style: TextStyle(fontSize: 12, color: Colors.white60, height: 1.35),
            ),
            const SizedBox(height: 12),
            Row(children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  onPressed: _savingConnection ? null : _saveConnection,
                  icon: const Icon(Icons.save_outlined),
                  label: Text(_savingConnection ? 'Saving…' : 'Save connection'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _testConnection,
                  icon: const Icon(Icons.network_check),
                  label: const Text('Test backend'),
                ),
              ),
            ]),
            const Divider(height: 30),
            const Text('Personal memory', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('Add facts you explicitly want NOVA to remember. Memories stay on this device and can be deleted individually. Do not save passwords or secrets.' , style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 10),
            Row(children: <Widget>[
              Expanded(child: TextField(controller: _memoryInput, decoration: const InputDecoration(labelText: 'Remember this…', border: OutlineInputBorder()), onSubmitted: (_) => _addMemory())),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _addMemory, icon: const Icon(Icons.add)),
            ]),
            if (_memories.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Text('No saved memories yet.', style: TextStyle(color: Colors.white54)))
            else ..._memories.asMap().entries.map((entry) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.bookmark_outline, color: novaCyan),
              title: Text(entry.value),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { setState(() => _memories.removeAt(entry.key)); await _saveMemories(); }),
            )),
            const SizedBox(height: 22),
            const Divider(height: 30),
            const Text('Backup & restore', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Export a JSON backup by copying it to your clipboard, then paste it into a text file. Restore by pasting that JSON here. Keep backups private because they contain your personal data.', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _createBackup,
                    icon: const Icon(Icons.content_copy),
                    label: const Text('Copy backup'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _restoreBackup,
                    icon: const Icon(Icons.restore),
                    label: const Text('Restore backup'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.storage_outlined, color: novaCyan),
              title: Text('Local storage'),
              subtitle: Text('Notes and tasks are stored with app preferences. They are not encrypted by this app. Do not save passwords or highly sensitive information.'),
            ),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.policy_outlined, color: novaCyan),
              title: Text('Online AI and privacy'),
              subtitle: Text('When privacy mode is off, recent chat messages may be sent to your configured backend. Your backend provider may process them. Device speech recognition may also use OS services.'),
            ),
            OutlinedButton.icon(
              onPressed: _confirmClearData,
              icon: const Icon(Icons.delete_forever_outlined),
              label: const Text('Delete all local notes, tasks, and memories'),
            ),
            const SizedBox(height: 12),
            const Text(
              'Build status: source foundation. Chat history now persists locally (up to 200 messages); notes can be edited; tasks support priority and optional due dates; JSON backup/restore is available through clipboard. Full local-model inference, wake-word listening, OS notifications, file import, advanced character animation/lip-sync, voice identity, cloud storage, and camera integrations still need implementation and platform testing.',
              style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
            ),
          ],
        ),
      );

  Future<void> _confirmClearData() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete local data?'),
        content: const Text('This permanently deletes NOVA notes and tasks saved on this device. Chat history will also be cleared.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete all')),
        ],
      ),
    );
    if (approved != true) return;
    setState(() { _notes.clear(); _tasks.clear(); _messages.clear(); });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('nova_notes_v2');
    await prefs.remove('nova_memories_v1');
    await prefs.remove('nova_tasks_v2');
    await prefs.remove('nova_chat_history_v1');
    if (mounted) _showSnack('Local notes, tasks, and memories deleted.');
  }
}
