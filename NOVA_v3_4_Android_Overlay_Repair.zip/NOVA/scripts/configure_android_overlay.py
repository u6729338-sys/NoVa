"""Adds the optional, user-authorized Android floating companion bridge after flutter create."""
from pathlib import Path
import re

root = Path('.')
manifest = root / 'android/app/src/main/AndroidManifest.xml'
if not manifest.exists():
    raise SystemExit('AndroidManifest.xml missing; run flutter create first.')
text = manifest.read_text(encoding='utf-8')
permission = ('    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />\n'
              '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n'
              '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />\n'
              '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />')
if 'android.permission.SYSTEM_ALERT_WINDOW' not in text:
    text = re.sub(r'(<application\b)', lambda match: permission + '\n' + match.group(1), text, count=1)
service = '        <service android:name=".NovaOverlayService" android:exported="false" android:foregroundServiceType="specialUse">\n            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="User-enabled floating assistant character overlay" />\n        </service>'
if 'NovaOverlayService' not in text:
    text = text.replace('</application>', service + '\n    </application>')
manifest.write_text(text, encoding='utf-8')

activity = root / 'android/app/src/main/kotlin/com/example/nova/MainActivity.kt'
activity.parent.mkdir(parents=True, exist_ok=True)
activity.write_text('''package com.example.nova

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "nova/overlay"
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "isOverlayPermissionGranted" -> result.success(Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))
                "requestOverlayPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        startActivity(intent)
                    }
                    result.success(null)
                }
                "startOverlay" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                        result.error("NO_OVERLAY_PERMISSION", "Display over other apps permission is not granted", null)
                    } else {
                        val intent = Intent(this, NovaOverlayService::class.java)
                        intent.putExtra("name", call.argument<String>("name") ?: "NOVA")
                        intent.putExtra("emoji", call.argument<String>("emoji") ?: "🤖")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                        result.success(null)
                    }
                }
                "stopOverlay" -> { stopService(Intent(this, NovaOverlayService::class.java)); result.success(null) }
                else -> result.notImplemented()
            }
        }
    }
}
''', encoding='utf-8')

assets_dir = root / 'android/app/src/main/assets'
assets_dir.mkdir(parents=True, exist_ok=True)
character_asset = root / 'assets/characters/nova_full_body.png'
if character_asset.exists():
    (assets_dir / 'nova_full_body.png').write_bytes(character_asset.read_bytes())

service_file = root / 'android/app/src/main/kotlin/com/example/nova/NovaOverlayService.kt'
service_file.write_text('''package com.example.nova

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.BitmapFactory
import android.widget.ImageView
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class NovaOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("nova_overlay", "NOVA floating character", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            val notification: Notification = Notification.Builder(this, "nova_overlay")
                .setContentTitle("NOVA floating character is active")
                .setContentText("Tap the character to return to NOVA. Stop it from the NOVA app.")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build()
            startForeground(4107, notification)
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) { windowManager.removeView(bubble); bubble = null }
        val name = intent?.getStringExtra("name") ?: "NOVA"
        val emoji = intent?.getStringExtra("emoji") ?: "🤖"
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(12, 31, 49))
            val avatar = try { assets.open("nova_full_body.png").use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
            if (avatar != null) addView(ImageView(this@NovaOverlayService).apply { setImageBitmap(avatar); scaleType = ImageView.ScaleType.FIT_CENTER; layoutParams = LinearLayout.LayoutParams(150, 310) })
            else addView(TextView(this@NovaOverlayService).apply { text = emoji; textSize = 36f; gravity = Gravity.CENTER })
            addView(TextView(this@NovaOverlayService).apply { text = name; textSize = 12f; setTextColor(Color.CYAN); gravity = Gravity.CENTER })
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 30; lp.y = 180
        box.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0; private var downY = 0; private var touchX = 0f; private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = lp.x; downY = lp.y; touchX = event.rawX; touchY = event.rawY; return true }
                    MotionEvent.ACTION_MOVE -> { lp.x = downX + (event.rawX - touchX).toInt(); lp.y = downY + (event.rawY - touchY).toInt(); windowManager.updateViewLayout(box, lp); return true }
                    MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawX - touchX) < 8 && kotlin.math.abs(event.rawY - touchY) < 8) { val launch = packageManager.getLaunchIntentForPackage(packageName); launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); if (launch != null) startActivity(launch) }; return true }
                }
                return false
            }
        })
        windowManager.addView(box, lp); bubble = box; params = lp
        return START_NOT_STICKY
    }
    override fun onDestroy() { bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }; bubble = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
''', encoding='utf-8')
print('Configured Android overlay permission, MethodChannel bridge, full-body floating companion service, and copied the character asset.')
