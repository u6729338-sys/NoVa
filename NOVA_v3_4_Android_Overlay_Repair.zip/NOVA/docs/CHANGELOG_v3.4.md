# NOVA v3.4 — Android overlay integration repair

- Aligns the displayed app version with the source package version.
- Adds the Android 13 notification permission declaration used by the user-visible floating-companion foreground service.
- Preserves explicit overlay permission, foreground-service declaration, and a draggable character overlay.
- The overlay is a basic static companion window, not a 3D animated agent or screen reader.
- This package still requires GitHub Actions build and physical-device validation.

Not included: offline generative LLM weights/runtime, scheduled reminder notifications, live MediaProjection screen understanding, live camera analysis, Windows always-on-top companion, full 3D animation/lip-sync, or a fully autonomous agent.
